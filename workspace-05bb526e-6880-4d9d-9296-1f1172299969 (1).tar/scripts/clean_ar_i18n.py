#!/usr/bin/env python3
"""Remove Free/Pro plan keys from ar.ts and rewrite plan-related copy."""
import re

PATH = "/home/z/my-project/src/lib/studykit/i18n/ar.ts"

with open(PATH, encoding="utf-8") as f:
    lines = f.read().split("\n")

# Whole top-level sections to drop entirely.
SECTIONS_TO_DROP = {"pricing", "billing"}

# section -> set of key prefixes to delete.
DELETE_KEYS = {
    "common": {"free:", "pro:", "perMonth:"},
    "nav": {"pricing:", "upgrade:"},
    "landing": {"navPricing:", "plansTitle:", "plansSubtitle:", "plansNote:", "plansCompareCta:"},
    "shell": {"planBadgeFree:", "planBadgePro:", "manageSubscription:"},
    "dashboard": {"qaAiPlanPro:"},
    "planner": {"freeLimitTitle:", "freeLimitDesc:", "maxSubjectsFree:", "freeUsage:"},
    "exams": {"freeLimitTitle:", "freeLimitDesc:"},
    "progress": {"tabAdvancedPro:", "advancedGateTitle:", "advancedGateDesc:", "advancedGateCta:"},
    "assistant": {"badgePro:", "gateTitle:", "gateDesc:", "gateCta:"},
    "settings": {
        "accentLocked:", "accentLockedHint:", "subscription:", "plan:", "status:",
        "statusActive:", "renews:", "started:", "manageOnPricing:", "cancelSub:",
        "cancelSubTitle:", "cancelSubDesc:", "resub:", "demoBadge:",
    },
}

# section -> key -> new full line (replacement without deleting).
REWRITE = {
    "landing": {
        "heroStat3:": '    heroStat3: "درهم — كل المزايا مشمولة للجميع",',
        "faq1Q:": '    faq1Q: "هل يكلّف ستادي كِت شيئًا؟",',
        "faq1A:": '    faq1A: "لا. كل المزايا مشمولة لكل حساب — المخطط والمهام وعدّادات الاختبارات وخطط الذكاء الاصطناعي والتحليلات المتقدمة. بدون بطاقة وبدون خطط.",',
        "faq2Q:": '    faq2Q: "ماذا يتضمن ستادي كِت؟",',
        "faq2A:": '    faq2A: "مخطط مذاكرة أسبوعي، ومدير مهام بالأولويات، وعدّادات حية للاختبارات، وتحليلات تقدم مع تقارير، ومساعد ذكي يولّد خطط مذاكرة وجداول مراجعة.",',
        "faq3Q:": '    faq3Q: "هل أحتاج إلى حساب؟",',
        "faq3A:": '    faq3A: "يمكنك الاستكشاف كضيف، لكن إنشاء حساب مجاني يحفظ بياناتك على خادم ستادي كِت ويزامنها مع كل جهاز تسجل منه الدخول.",',
        "faq5A:": '    faq5A: "بياناتك محفوظة على خادم ستادي كِت ضمن حسابك وتتزامن بين الأجهزة، وتبقى نسخة دون اتصال في متصفحك ليعمل التطبيق حتى عند انقطاع الشبكة.",',
        "ctaSubtitle:": '    ctaSubtitle: "انضم إلى طلاب يخططون ويتتبعون ويراجعون مع ستادي كِت — كل المزايا مشمولة مجانًا لكل طالب.",',
        "footerDisclaimer:": '    footerDisclaimer: "كل المزايا مشمولة لكل حساب. نسخة تطويرية — قد تتغير المزايا والتصميم قبل الإطلاق.",',
    },
    "auth": {
        "registerSubtitle:": '    registerSubtitle: "كل المزايا مشمولة — بدون بطاقة ائتمان.",',
    },
    "assistant": {
        "badgeAI:": '    badgeAI: "ذكاء اصطناعي مباشر",',
    },
    "settings": {
        "accentLocked:": '    accentHint: "يُطبَّق لون التمييز على التطبيق كله.",',
        "dataDesc:": '    dataDesc: "بياناتك محفوظة على حسابك في خادم ستادي كِت وتتزامن مع كل جهاز تسجل منه الدخول. تبقى أيضًا نسخة دون اتصال في هذا المتصفح.",',
    },
}

# section -> after key -> lines to insert.
INSERT_AFTER = {
    "assistant": {
        "tabRevision:": ['    pastSkipped: "كل الجلسات المخططة في الماضي — لم تُضف أي جلسة.",'],
    },
}

section_re = re.compile(r"^  ([A-Za-z]+): \{")
key_re = re.compile(r"^    ([A-Za-z0-9_]+):")

out = []
section = None
skipping_section = None

for line in lines:
    if skipping_section is not None:
        # inside a dropped section: wait for its closing "  },"
        if re.match(r"^  \},?$", line):
            skipping_section = None
        continue

    m = section_re.match(line)
    if m:
        if m.group(1) in SECTIONS_TO_DROP:
            skipping_section = m.group(1)
            continue
        section = m.group(1)

    if section and line.startswith("    "):
        km = key_re.match(line)
        if km:
            key = km.group(1) + ":"
            if key in DELETE_KEYS.get(section, set()):
                continue
            if key in REWRITE.get(section, {}):
                out.append(REWRITE[section][key])
                continue
            if key in INSERT_AFTER.get(section, {}):
                out.append(line)
                out.extend(INSERT_AFTER[section][key])
                continue
    out.append(line)

with open(PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(out))

print("done")
