/**
 * StudyKit — local study-plan engine.
 *
 * This deterministic engine powers the clearly-marked DEMO mode of the AI
 * assistant (when no live model is reachable) and normalizes/validates the
 * output of the server-side model in live mode. It uses real scheduling
 * heuristics — spacing, load balancing, spaced revision — so demo output is
 * a genuine, usable plan rather than fake filler.
 */

import type { PlannedSession } from "./types";
import { addDaysISO, daysBetween, fromISODate, todayISO, toISODate } from "./utils";

export interface PlanRequest {
  examTitle: string;
  examDate: string; // yyyy-mm-dd
  subjects: string[];
  hoursPerDay: number;
  startFrom?: string; // yyyy-mm-dd (defaults to today)
  locale?: "en" | "ar";
}

export interface PlanResponse {
  summary: string;
  sessions: PlannedSession[];
  tips: string[];
}

const LEARN_TITLES: Record<"en" | "ar", Record<string, string[]>> = {
  en: {
    learn: ["Deep study — {s}", "Core concepts — {s}", "First pass — {s}", "Lecture notes review — {s}"],
    revise: ["Revision — {s}", "Key points recall — {s}", "Summary sheets — {s}"],
    practice: ["Problem set — {s}", "Past paper practice — {s}", "Exercises — {s}"],
    mock: ["Timed mock exam", "Full mock under exam conditions"],
  },
  ar: {
    learn: ["مذاكرة عميقة — {s}", "المفاهيم الأساسية — {s}", "التمريرة الأولى — {s}", "مراجعة المحاضرات — {s}"],
    revise: ["مراجعة — {s}", "استرجاع النقاط الرئيسية — {s}", "أوراق ملخصات — {s}"],
    practice: ["حل تمارين — {s}", "نماذج أسئلة سابقة — {s}", "تدريبات — {s}"],
    mock: ["اختبار تجريبي موقوت", "اختبار محاكاة كامل"],
  },
};

const TIPS: Record<"en" | "ar", string[]> = {
  en: [
    "Study the hardest subject first while your focus is freshest.",
    "Use 25–50 minute focused blocks with short breaks in between.",
    "Test yourself with past papers instead of re-reading notes.",
    "Review each session's notes for 10 minutes the next morning.",
    "Sleep 7–8 hours — memory consolidation happens during sleep.",
    "Keep your phone in another room during practice sessions.",
  ],
  ar: [
    "ابدأ بالمادة الأصعب بينما تركيزك في أفضل حالاته.",
    "استخدم فترات تركيز 25–50 دقيقة مع فترات راحة قصيرة بينها.",
    "اختبر نفسك بنماذج الأسئلة السابقة بدل إعادة قراءة الملاحظات.",
    "راجع ملاحظات كل جلسة 10 دقائق صباح اليوم التالي.",
    "نم 7–8 ساعات — تثبيت الذاكرة يحدث أثناء النوم.",
    "أبقِ هاتفك في غرفة أخرى أثناء جلسات التدريب.",
  ],
};

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}

/**
 * Builds a balanced plan: learn-heavy early, shifting to practice and mocks
 * as the exam approaches, with sessions distributed across subjects and days.
 */
export function buildStudyPlan(req: PlanRequest): PlanResponse {
  const locale: "en" | "ar" = req.locale ?? "en";
  const start = req.startFrom ?? todayISO();
  const totalDays = Math.max(1, daysBetween(start, req.examDate));
  const subjects = req.subjects.length ? req.subjects : ["General"];
  const sessions: PlannedSession[] = [];
  const labels = LEARN_TITLES[locale];

  // Load profile: how many blocks per day, which days get practice/mock.
  const dailyBlocks = Math.max(1, Math.min(4, Math.round((req.hoursPerDay * 60) / 50)));
  const blockMin = Math.max(30, Math.min(90, Math.round((req.hoursPerDay * 60) / dailyBlocks)));

  for (let d = 0; d < totalDays; d++) {
    const date = addDaysISO(start, d);
    const daysLeft = totalDays - d;
    const isMockDay = daysLeft === 1 && totalDays >= 3;
    const practicePhase = daysLeft <= Math.ceil(totalDays / 3);

    const count = isMockDay ? Math.min(2, dailyBlocks) : dailyBlocks;
    for (let b = 0; b < count; b++) {
      const subject = subjects[(d + b) % subjects.length];
      const seed = d * 31 + b * 7 + subjects.indexOf(subject);
      // Rotate start times through the day: 16:00, 17:10, 19:00, 20:10 …
      const slotHours = [16, 17, 19, 20];
      const hh = slotHours[(b + (d % 2)) % slotHours.length];
      const startTime = `${String(hh).padStart(2, "0")}:${b % 2 === 0 ? "00" : "10"}`;

      let kind: PlannedSession["kind"];
      let title: string;
      if (isMockDay) {
        kind = "mock";
        title = pick(labels.mock, seed);
      } else if (practicePhase && b >= count - 2) {
        kind = "practice";
        title = pick(labels.practice, seed).replace("{s}", subject);
      } else if (practicePhase && b < count - 2) {
        kind = "revise";
        title = pick(labels.revise, seed).replace("{s}", subject);
      } else if (d > 0 && b === 0) {
        kind = "revise"; // start each day with a short recall of yesterday
        title = pick(labels.revise, seed).replace("{s}", subjects[(d - 1) % subjects.length]);
      } else {
        kind = "learn";
        title = pick(labels.learn, seed).replace("{s}", subject);
      }
      sessions.push({ date, startTime, durationMin: blockMin, subject, title, kind });
    }
  }

  const summary =
    locale === "ar"
      ? `خطة ${totalDays} يومًا لـ «${req.examTitle}»: ${subjects.join("، ")}. تتحول تدريجيًا من المذاكرة العميقة إلى التدريب والاختبارات التجريبية مع اقتراب الاختبار، بمعدل ${req.hoursPerDay} ساعة يوميًا.`
      : `A ${totalDays}-day plan for “${req.examTitle}” covering ${subjects.join(", ")}. It shifts from deep learning to practice and mock exams as the date approaches, at ${req.hoursPerDay}h/day.`;

  const tips = [pick(TIPS[locale], totalDays), pick(TIPS[locale], totalDays * 3 + 1), pick(TIPS[locale], totalDays * 5 + 2)];

  return { summary, sessions, tips };
}

/** Revision checkpoints: day-14 / day-7 / day-3 / day-1 (clamped to range). */
export function buildRevisionSchedule(
  examTitle: string,
  examDate: string,
  subject: string,
  hoursPerDay: number,
  locale: "en" | "ar" = "en"
): { date: string; title: string; durationMin: number }[] {
  const daysLeft = daysBetween(todayISO(), examDate);
  const offsets = [14, 7, 3, 1].filter((o) => o <= Math.max(1, daysLeft - 1));
  const labels =
    locale === "ar"
      ? ["التمريرة الأولى — المادة كاملة", "مراجعة ١ — المواضيع الضعيفة", "مراجعة ٢ — نماذج أسئلة سابقة", "مراجعة أخيرة — استرجاع سريع"]
      : ["First pass — full material", "Review 1 — weak topics", "Review 2 — past papers", "Final review — quick recall"];
  const dur = Math.max(45, Math.min(120, Math.round(hoursPerDay * 60)));
  return offsets.map((o, i) => ({
    date: addDaysISO(examDate, -o),
    title: `${subject} — ${labels[locale === "ar" ? 0 : i] ?? labels[i]}`,
    durationMin: dur,
  })).map((s, i) => ({ ...s, title: `${subject} — ${labels[i]}` }));
}

/** Ensures model output (live AI mode) is complete and type-safe. */
export function normalizePlanSessions(raw: unknown, req: PlanRequest): PlannedSession[] {
  if (!Array.isArray(raw)) return [];
  const out: PlannedSession[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const r = item as Record<string, unknown>;
    const date = typeof r.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(r.date) ? r.date : null;
    if (!date) continue;
    const subject = typeof r.subject === "string" && r.subject.trim() ? r.subject.trim() : req.subjects[0] ?? "General";
    const title = typeof r.title === "string" && r.title.trim() ? r.title.trim() : `${subject} study`;
    const durationMin = typeof r.durationMin === "number" && r.durationMin >= 15 && r.durationMin <= 240 ? Math.round(r.durationMin) : 50;
    const startTime = typeof r.startTime === "string" && /^\d{2}:\d{2}$/.test(r.startTime) ? r.startTime : "17:00";
    const kind = (["learn", "revise", "practice", "mock"] as const).includes(r.kind as never)
      ? (r.kind as PlannedSession["kind"])
      : "learn";
    out.push({ date, startTime, durationMin, subject, title, kind });
  }
  return out.slice(0, 120); // hard cap for safety
}

/** Groups sessions per day for display. */
export function groupByDate(sessions: PlannedSession[]): Map<string, PlannedSession[]> {
  const map = new Map<string, PlannedSession[]>();
  for (const s of sessions) {
    const list = map.get(s.date) ?? [];
    list.push(s);
    map.set(s.date, list);
  }
  for (const list of map.values()) list.sort((a, b) => a.startTime.localeCompare(b.startTime));
  return map;
}

export function planTotalMinutes(sessions: PlannedSession[]): number {
  return sessions.reduce((acc, s) => acc + s.durationMin, 0);
}

export function isoOf(d: Date): string {
  return toISODate(fromISODate(toISODate(d)));
}
