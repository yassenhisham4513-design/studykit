/**
 * StudyKit — core domain types.
 *
 * These types are storage-agnostic: the app currently persists them to
 * localStorage (see lib/studykit/store.ts), but the same shapes map 1:1 onto
 * the Prisma schema that will be introduced when a real database and
 * authentication layer are connected.
 */

export type Locale = "en" | "ar";

export type TaskPriority = "low" | "medium" | "high";

export type TaskStatus = "todo" | "in_progress" | "done";

export type AccentTheme = "emerald" | "violet" | "rose" | "amber" | "teal";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  university?: string;
  level?: string;
  createdAt: string; // ISO
}

export interface Subject {
  id: string;
  name: string;
  color: string; // hex
  /** Optional weekly target hours used by the AI planner & progress goals. */
  weeklyTargetHours?: number;
  createdAt: string;
}

export interface StudySession {
  id: string;
  subjectId: string;
  title: string;
  /** ISO date `yyyy-mm-dd` */
  date: string;
  /** `HH:mm` 24h */
  startTime: string;
  durationMin: number;
  notes?: string;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  source?: "manual" | "ai";
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  subjectId?: string;
  /** ISO date `yyyy-mm-dd`, optional */
  dueDate?: string;
  priority: TaskPriority;
  status: TaskStatus;
  createdAt: string;
  completedAt?: string;
}

export interface Exam {
  id: string;
  title: string;
  subjectId: string;
  /** ISO date `yyyy-mm-dd` */
  date: string;
  /** `HH:mm` */
  time: string;
  location?: string;
  notes?: string;
  createdAt: string;
}

export interface AppSettings {
  locale: Locale;
  accent: AccentTheme;
  /** Default session duration offered in the planner dialog. */
  defaultSessionMin: number;
  onboardingDone: boolean;
}

/** A single session inside a generated AI study plan (not yet committed). */
export interface PlannedSession {
  date: string;
  startTime: string;
  durationMin: number;
  subject: string;
  title: string;
  kind: "learn" | "revise" | "practice" | "mock";
}

export interface GeneratedPlan {
  id: string;
  createdAt: string;
  examId?: string;
  examTitle: string;
  examDate: string;
  mode: "ai" | "demo";
  summary: string;
  subjects: string[];
  sessions: PlannedSession[];
  tips: string[];
}
