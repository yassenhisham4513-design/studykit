"use client";

/**
 * StudyKit i18n — lightweight typed dictionary system.
 * Provides `t()`, locale state and document direction management.
 * The locale lives in the persisted zustand store (single source of truth)
 * and is mirrored to `studykit-locale` for the no-flash inline script.
 */

import { createContext, useCallback, useContext, useEffect, useMemo } from "react";
import { en } from "./en";
import { ar } from "./ar";
import type { Dict, TKey } from "./en";
import type { Locale } from "../types";
import { INTL_LOCALES } from "../utils";

export const DICTS: Record<Locale, Dict> = { en, ar };

export type TranslateFn = (key: TKey, params?: Record<string, string | number>) => string;

interface I18nContextValue {
  locale: Locale;
  dir: "ltr" | "rtl";
  setLocale: (l: Locale) => void;
  toggleLocale: () => void;
  t: TranslateFn;
  /** Intl locale tag with forced latin digits for ar. */
  intlLocale: string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

function resolve(dict: Dict, key: string): string {
  const value = key.split(".").reduce<unknown>((acc, part) => {
    if (acc && typeof acc === "object") return (acc as Record<string, unknown>)[part];
    return undefined;
  }, dict);
  return typeof value === "string" ? value : key;
}

export function I18nProvider({
  locale,
  setLocale,
  children,
}: {
  locale: Locale;
  setLocale: (l: Locale) => void;
  children: React.ReactNode;
}) {
  const dir: "ltr" | "rtl" = locale === "ar" ? "rtl" : "ltr";

  // Keep <html> in sync with the active locale (direction, lang, mirror key).
  useEffect(() => {
    const root = document.documentElement;
    root.dir = dir;
    root.lang = locale;
    try {
      localStorage.setItem("studykit-locale", locale);
    } catch {
      /* storage unavailable — ignore */
    }
  }, [dir, locale]);

  const t = useCallback<TranslateFn>(
    (key, params) => {
      let out = resolve(DICTS[locale], key);
      if (params) {
        for (const [k, v] of Object.entries(params)) {
          out = out.replaceAll(`{${k}}`, String(v));
        }
      }
      return out;
    },
    [locale]
  );

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      dir,
      setLocale,
      toggleLocale: () => setLocale(locale === "ar" ? "en" : "ar"),
      t,
      intlLocale: INTL_LOCALES[locale],
    }),
    [locale, dir, setLocale, t]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside <I18nProvider>");
  return ctx;
}
