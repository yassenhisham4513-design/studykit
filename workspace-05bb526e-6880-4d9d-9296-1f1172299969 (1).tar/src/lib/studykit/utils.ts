/**
 * StudyKit — date & formatting helpers.
 * All helpers are locale-aware (en / ar) and timezone-safe by working on
 * `yyyy-mm-dd` strings for calendar math and ISO datetimes for countdowns.
 */

import type { Locale } from "./types";

export const INTL_LOCALES: Record<Locale, string> = {
  en: "en",
  ar: "ar-AE-u-nu-latn",
};

/** `yyyy-mm-dd` for a Date, in local time. */
export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Parse `yyyy-mm-dd` as a local Date (avoids UTC shift). */
export function fromISODate(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function addDaysISO(iso: string, days: number): string {
  const d = fromISODate(iso);
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

export function daysBetween(fromISO: string, toISOStr: string): number {
  const a = fromISODate(fromISO).getTime();
  const b = fromISODate(toISOStr).getTime();
  return Math.round((b - a) / 86_400_000);
}

/** Monday-based start of the week containing `iso`. */
export function startOfWeekISO(iso: string): string {
  const d = fromISODate(iso);
  const day = d.getDay(); // 0 = Sun … 6 = Sat
  const diff = (day + 6) % 7; // days since Monday
  d.setDate(d.getDate() - diff);
  return toISODate(d);
}

export function weekDatesISO(startISO: string): string[] {
  return Array.from({ length: 7 }, (_, i) => addDaysISO(startISO, i));
}

/** `yyyy-mm` for a Date or ISO date string. */
export function monthKey(iso: string): string {
  return iso.slice(0, 7);
}

export function startOfMonthISO(iso: string): string {
  return `${iso.slice(0, 7)}-01`;
}

export function endOfMonthISO(iso: string): string {
  const d = fromISODate(iso);
  const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  return toISODate(end);
}

/** "2025-03-04T14:30:00" style datetime for an exam. */
export function examDateTimeISO(date: string, time: string): Date {
  const [y, m, d] = date.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1, hh ?? 0, mm ?? 0);
}

export function minutesToLabel(min: number, locale: Locale): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (locale === "ar") {
    const hp = h > 0 ? `${h} س` : null;
    const mp = m > 0 ? `${m} د` : null;
    return [hp, mp].filter(Boolean).join(" ") || "0 د";
  }
  const hp = h > 0 ? `${h}h` : null;
  const mp = m > 0 ? `${m}m` : null;
  return [hp, mp].filter(Boolean).join(" ") || "0m";
}

const WEEKDAY_FORMATS: Record<Locale, Intl.DateTimeFormatOptions> = {
  en: { weekday: "short" },
  ar: { weekday: "short" },
};

export function formatDayShort(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], WEEKDAY_FORMATS[locale]).format(
    fromISODate(iso)
  );
}

export function formatDayNumber(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], { day: "numeric" }).format(
    fromISODate(iso)
  );
}

export function formatDateMedium(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(fromISODate(iso));
}

export function formatDateLong(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(fromISODate(iso));
}

export function formatMonthLabel(year: number, monthIndex: number, locale: Locale): string {
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], { month: "long", year: "numeric" }).format(
    new Date(year, monthIndex, 1)
  );
}

/** `HH:mm` → locale time, e.g. "2:30 PM" / "٢:٣٠ م" (latin digits here). */
export function formatTime(hhmm: string, locale: Locale): string {
  const [h, m] = hhmm.split(":").map(Number);
  const d = new Date(2000, 0, 1, h ?? 0, m ?? 0);
  return new Intl.DateTimeFormat(INTL_LOCALES[locale], {
    hour: "numeric",
    minute: "2-digit",
  }).format(d);
}

export function formatNumber(n: number, locale: Locale): string {
  return new Intl.NumberFormat(INTL_LOCALES[locale]).format(n);
}

export function isSameDay(isoA: string, isoB: string): boolean {
  return isoA === isoB;
}

/** Human-friendly relative label: Today / Tomorrow / in X days. */
export function relativeDayLabel(iso: string, todayIso: string, locale: Locale): string {
  const diff = daysBetween(todayIso, iso);
  if (diff === 0) return locale === "ar" ? "اليوم" : "Today";
  if (diff === 1) return locale === "ar" ? "غدًا" : "Tomorrow";
  if (diff === -1) return locale === "ar" ? "أمس" : "Yesterday";
  return formatDateMedium(iso, locale);
}

/** Deterministic id generator (uuid may not be needed — keep deps light). */
let idCounter = 0;
export function uid(prefix = "id"): string {
  idCounter += 1;
  return `${prefix}_${Date.now().toString(36)}${idCounter.toString(36)}${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

export const SUBJECT_COLORS = [
  "#059669", // emerald-600
  "#0d9488", // teal-600
  "#d97706", // amber-600
  "#dc2626", // red-600
  "#7c3aed", // violet-600
  "#db2777", // pink-600
  "#65a30d", // lime-600
  "#ea580c", // orange-600
] as const;

export function pickSubjectColor(index: number): string {
  return SUBJECT_COLORS[index % SUBJECT_COLORS.length];
}
