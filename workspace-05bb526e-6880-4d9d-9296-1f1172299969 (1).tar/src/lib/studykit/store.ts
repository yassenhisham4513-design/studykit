"use client";

/**
 * StudyKit — application store (zustand).
 *
 * Architecture:
 *  - Real accounts: register/login/logout talk to /api/auth/* which stores
 *    users (scrypt-hashed passwords) in the server database and issues an
 *    HTTP-only session cookie.
 *  - Cross-device data sync: the study workspace (subjects, sessions, tasks,
 *    exams, settings) lives on the server, keyed by account. Every mutation
 *    schedules a debounced push (PUT /api/user/data); signing in pulls the
 *    latest server state. Signed-out/guest usage stays local-only and is
 *    clearly labelled.
 *
 * localStorage remains only as an offline cache so the UI keeps working
 * across refreshes and brief network failures.
 */

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  AccentTheme,
  AppSettings,
  Exam,
  Locale,
  PlannedSession,
  Subject,
  StudySession,
  Task,
  TaskStatus,
  UserProfile,
} from "./types";
import { pickSubjectColor, todayISO, uid } from "./utils";
import { buildSeedData } from "./seed";

/* ── Server sync payload ───────────────────────────────────────────────── */

interface SyncPayload {
  subjects: Subject[];
  sessions: StudySession[];
  tasks: Task[];
  exams: Exam[];
  settings: AppSettings;
}

export type SyncState = "idle" | "saving" | "saved" | "error";

export interface AuthResult {
  ok: boolean;
  error?: "invalidCredentials" | "emailTaken" | "networkError";
  user?: UserProfile;
}

/* ── Defaults ──────────────────────────────────────────────────────────── */

const defaultSettings: AppSettings = {
  locale: "en",
  accent: "emerald",
  defaultSessionMin: 60,
  onboardingDone: false,
};

/* ── State shape ───────────────────────────────────────────────────────── */

export interface StudyKitState {
  _hydrated: boolean;
  setHydrated(): void;

  /** "guest" when using the local-only demo mode, server user id otherwise. */
  user: UserProfile | null;
  subjects: Subject[];
  sessions: StudySession[];
  tasks: Task[];
  exams: Exam[];
  settings: AppSettings;

  /** Server sync bookkeeping (not persisted). */
  _syncState: SyncState;
  _lastSyncAt: string | null;

  /* auth */
  register(input: { name: string; email: string; password: string; university?: string; level?: string; withSampleData?: boolean }): Promise<AuthResult>;
  login(input: { email: string; password: string }): Promise<AuthResult>;
  loginGuest(): UserProfile;
  logout(): Promise<void>;
  updateProfile(patch: Partial<Pick<UserProfile, "name" | "university" | "level">>): void;

  /* subjects */
  upsertSubject(input: { id?: string; name: string; color: string; weeklyTargetHours?: number }): { ok: boolean; reason?: "duplicate" };
  deleteSubject(id: string): { ok: boolean; reason?: "inUse" };

  /* sessions */
  addSession(input: Omit<StudySession, "id" | "createdAt" | "completed" | "source"> & { source?: "manual" | "ai" }): void;
  updateSession(id: string, patch: Partial<Omit<StudySession, "id" | "createdAt">>): void;
  deleteSession(id: string): void;
  toggleSessionComplete(id: string): void;
  addPlanSessions(planned: PlannedSession[]): { added: number; skipped: number };

  /* tasks */
  addTask(input: Pick<Task, "title"> & Partial<Omit<Task, "id" | "title" | "createdAt">>): void;
  updateTask(id: string, patch: Partial<Omit<Task, "id" | "createdAt">>): void;
  deleteTask(id: string): void;
  setTaskStatus(id: string, status: TaskStatus): void;

  /* exams */
  addExam(input: Omit<Exam, "id" | "createdAt">): void;
  updateExam(id: string, patch: Partial<Omit<Exam, "id" | "createdAt">>): void;
  deleteExam(id: string): void;

  /* settings */
  setLocale(locale: Locale): void;
  setAccent(accent: AccentTheme): void;
  setDefaultSessionMin(min: number): void;

  /* data */
  exportData(): string;
  importData(json: string): { ok: boolean };
  loadSampleData(): void;
  clearAllData(): void;
}

type StoreSet = (partial: Partial<StudyKitState> | ((s: StudyKitState) => Partial<StudyKitState>)) => void;

/* ── Helpers ───────────────────────────────────────────────────────────── */

function nowISO() {
  return new Date().toISOString();
}

/* ── Server sync engine (module scope, one per tab) ────────────────────── */

let pushTimer: ReturnType<typeof setTimeout> | null = null;
let lastPushedJson = "";

function snapshot(s: StudyKitState): SyncPayload {
  return {
    subjects: s.subjects,
    sessions: s.sessions,
    tasks: s.tasks,
    exams: s.exams,
    settings: s.settings,
  };
}

function isSyncable(s: StudyKitState): boolean {
  return Boolean(s.user && s.user.id !== "guest");
}

function pushNow(): void {
  const s = useStudyKitStore.getState();
  if (!isSyncable(s)) return;
  const payload = JSON.stringify(snapshot(s));
  if (payload === lastPushedJson) return; // nothing new since last push

  useStudyKitStore.setState({ _syncState: "saving" });
  const setLocal: StoreSet = (partial) => useStudyKitStore.setState(partial);
  void (async () => {
    try {
      const res = await fetch("/api/user/data", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: payload,
      });
      if (res.status === 401) {
        // Session expired — drop the local session marker; the guard will
        // redirect to /auth on the next navigation.
        setLocal({ user: null, _syncState: "idle" });
        return;
      }
      if (!res.ok) throw new Error(String(res.status));
      lastPushedJson = payload;
      setLocal({ _syncState: "saved", _lastSyncAt: nowISO() });
    } catch {
      setLocal({ _syncState: "error" });
      // Retry once after a short backoff — data stays in localStorage meanwhile.
      setTimeout(() => {
        if (useStudyKitStore.getState()._syncState === "error") pushNow();
      }, 4000);
    }
  })();
}

function schedulePush(): void {
  if (!isSyncable(useStudyKitStore.getState())) return;
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => pushNow(), 700);
}

const SYNCED_KEYS = ["subjects", "sessions", "tasks", "exams", "settings"] as const;

let syncWatcherAttached = false;

/**
 * Attaches the cross-device sync watcher. MUST be called after module init
 * (persist runs onRehydrateStorage synchronously during `create()`, when
 * `useStudyKitStore` is still uninitialized — referencing it there throws
 * in the temporal dead zone).
 */
function attachSyncWatcher(): void {
  if (syncWatcherAttached) return;
  syncWatcherAttached = true;
  useStudyKitStore.subscribe((state, prev) => {
    if (!isSyncable(state)) return;
    if (SYNCED_KEYS.some((k) => state[k] !== prev[k])) {
      schedulePush();
    }
  });
}

/* ── Server session helpers ────────────────────────────────────────────── */

/** Server public user = profile fields. */
type ServerUser = UserProfile;

async function fetchSessionUser(): Promise<ServerUser | null> {
  try {
    const res = await fetch("/api/auth/me", { cache: "no-store" });
    if (!res.ok) return null;
    const data = (await res.json()) as { user: ServerUser | null };
    return data.user;
  } catch {
    return null;
  }
}

async function pullServerData(): Promise<{ hadData: boolean }> {
  try {
    const res = await fetch("/api/user/data", { cache: "no-store" });
    if (!res.ok) return { hadData: false };
    const body = (await res.json()) as { data: SyncPayload | null };
    if (!body.data) return { hadData: false };
    useStudyKitStore.setState((s) => ({
      subjects: Array.isArray(body.data!.subjects) ? body.data!.subjects : s.subjects,
      sessions: Array.isArray(body.data!.sessions) ? body.data!.sessions : s.sessions,
      tasks: Array.isArray(body.data!.tasks) ? body.data!.tasks : s.tasks,
      exams: Array.isArray(body.data!.exams) ? body.data!.exams : s.exams,
      settings: { ...s.settings, ...(body.data!.settings ?? {}) },
    }));
    lastPushedJson = JSON.stringify(snapshot(useStudyKitStore.getState()));
    useStudyKitStore.setState({ _syncState: "saved", _lastSyncAt: nowISO() });
    return { hadData: true };
  } catch {
    return { hadData: false };
  }
}

/* ── Store ─────────────────────────────────────────────────────────────── */

export const useStudyKitStore = create<StudyKitState>()(
  persist(
    (set, get, api) => {
      const applyAccent = (accent: AccentTheme) => {
        if (typeof document !== "undefined") {
          document.documentElement.dataset.accent = accent;
        }
      };

      // Server data must win over whatever localStorage cached from another
      // account/guest session — clear slices when starting a fresh session.
      const resetDataSlices = () =>
        set({ subjects: [], sessions: [], tasks: [], exams: [] });

      return {
        _hydrated: false,

        setHydrated: () => {
          // NOTE: use `api.setState`, not the `useStudyKitStore` const here.
          // Persist runs initial hydration synchronously during module init,
          // while the store const is still uninitialized (TDZ).
          // Session validation + sync watcher attach happen in the boot
          // block after module evaluation (see bottom of this file).
          api.setState({ _hydrated: true });
          applyAccent(get().settings.accent);
        },

        user: null,
        subjects: [],
        sessions: [],
        tasks: [],
        exams: [],
        settings: defaultSettings,

        _syncState: "idle",
        _lastSyncAt: null,

        /* ── auth ─────────────────────────────────────────────────── */
        register: async ({ name, email, password, university, level, withSampleData }) => {
          // Snapshot local (guest/demo) data so it can be migrated up.
          const localSnapshot = snapshot(get());
          const hasLocalData =
            localSnapshot.subjects.length + localSnapshot.sessions.length + localSnapshot.tasks.length + localSnapshot.exams.length > 0;

          try {
            const res = await fetch("/api/auth/register", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ name, email, password, university, level }),
            });
            if (res.status === 409) return { ok: false, error: "emailTaken" };
            if (!res.ok) return { ok: false, error: "networkError" };
            const data = (await res.json()) as { user: ServerUser };

            resetDataSlices();
            set((s) => ({
              user: data.user,
              settings: { ...s.settings, onboardingDone: true },
              ...(withSampleData ? buildSeedData() : {}),
            }));
            applyAccent(get().settings.accent);

            // Migrate pre-existing local data to the new account (server empty).
            if (!withSampleData && hasLocalData) {
              const server = await fetch("/api/user/data", { cache: "no-store" });
              if (server.ok) {
                const body = (await server.json()) as { data: SyncPayload | null };
                if (!body.data) {
                  await fetch("/api/user/data", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(localSnapshot),
                  });
                  lastPushedJson = JSON.stringify(localSnapshot);
                  set({ _syncState: "saved", _lastSyncAt: nowISO() });
                }
              }
            }
            return { ok: true, user: data.user };
          } catch {
            return { ok: false, error: "networkError" };
          }
        },

        login: async ({ email, password }) => {
          try {
            const res = await fetch("/api/auth/login", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ email, password }),
            });
            if (res.status === 401) return { ok: false, error: "invalidCredentials" };
            if (!res.ok) return { ok: false, error: "networkError" };
            const data = (await res.json()) as { user: ServerUser };

            resetDataSlices();
            set((s) => ({
              user: data.user,
              settings: { ...s.settings, onboardingDone: true },
            }));
            applyAccent(get().settings.accent);
            await pullServerData();
            return { ok: true, user: data.user };
          } catch {
            return { ok: false, error: "networkError" };
          }
        },

        loginGuest: () => {
          const profile: UserProfile = {
            id: "guest",
            name: "Guest",
            email: "guest@studykit.local",
            createdAt: nowISO(),
          };
          set((s) => ({ user: profile, settings: { ...s.settings, onboardingDone: true } }));
          return profile;
        },

        logout: async () => {
          try {
            await fetch("/api/auth/logout", { method: "POST" });
          } catch {
            /* network hiccup — clear locally anyway */
          }
          set({ user: null, _syncState: "idle", _lastSyncAt: null });
          resetDataSlices();
        },

        updateProfile: (patch) => {
          set((s) => (s.user ? { user: { ...s.user, ...patch } } : {}));
          void fetch("/api/auth/me", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          }).catch(() => undefined);
        },

        /* ── subjects ─────────────────────────────────────────────── */
        upsertSubject: ({ id, name, color, weeklyTargetHours }) => {
          const { subjects } = get();
          const trimmed = name.trim();
          if (!trimmed) return { ok: false, reason: "duplicate" };
          const duplicate = subjects.some((s) => s.name.toLowerCase() === trimmed.toLowerCase() && s.id !== id);
          if (duplicate) return { ok: false, reason: "duplicate" };

          if (id) {
            set((s) => ({
              subjects: s.subjects.map((sub) => (sub.id === id ? { ...sub, name: trimmed, color, weeklyTargetHours } : sub)),
            }));
            return { ok: true };
          }
          const subject: Subject = {
            id: uid("sub"),
            name: trimmed,
            color,
            weeklyTargetHours,
            createdAt: nowISO(),
          };
          set((s) => ({ subjects: [...s.subjects, subject] }));
          return { ok: true };
        },

        deleteSubject: (id) => {
          const { sessions, tasks, exams, subjects } = get();
          if (subjects.length <= 1 && (sessions.length || exams.length)) return { ok: false, reason: "inUse" };
          set((s) => ({
            subjects: s.subjects.filter((sub) => sub.id !== id),
            sessions: s.sessions.map((ses) => (ses.subjectId === id ? { ...ses, subjectId: "" } : ses)),
            tasks: s.tasks.map((t) => (t.subjectId === id ? { ...t, subjectId: undefined } : t)),
            exams: s.exams.map((ex) => (ex.subjectId === id ? { ...ex, subjectId: "" } : ex)),
          }));
          return { ok: true };
        },

        /* ── sessions ─────────────────────────────────────────────── */
        addSession: (input) => {
          const session: StudySession = {
            ...input,
            id: uid("ses"),
            completed: false,
            source: input.source ?? "manual",
            createdAt: nowISO(),
          };
          set((s) => ({ sessions: [...s.sessions, session] }));
        },

        updateSession: (id, patch) =>
          set((s) => ({
            sessions: s.sessions.map((ses) => (ses.id === id ? { ...ses, ...patch } : ses)),
          })),

        deleteSession: (id) => set((s) => ({ sessions: s.sessions.filter((ses) => ses.id !== id) })),

        toggleSessionComplete: (id) =>
          set((s) => ({
            sessions: s.sessions.map((ses) =>
              ses.id === id
                ? { ...ses, completed: !ses.completed, completedAt: !ses.completed ? nowISO() : undefined }
                : ses
            ),
          })),

        addPlanSessions: (planned) => {
          const { sessions, subjects } = get();
          const today = todayISO();

          // Map subject names → subject ids, creating new subjects when needed.
          const nameToSubject = new Map(subjects.map((s) => [s.name.toLowerCase(), s]));
          const newSubjects: Subject[] = [];
          const ensureSubject = (name: string): Subject => {
            const key = name.toLowerCase();
            const existing = nameToSubject.get(key);
            if (existing) return existing;
            const created: Subject = {
              id: uid("sub"),
              name,
              color: pickSubjectColor(subjects.length + newSubjects.length),
              createdAt: nowISO(),
            };
            nameToSubject.set(key, created);
            newSubjects.push(created);
            return created;
          };

          let added = 0;
          let skipped = 0;
          const newSessions: StudySession[] = [];
          for (const p of planned) {
            if (p.date < today) {
              skipped += 1;
              continue;
            }
            const subject = ensureSubject(p.subject);
            newSessions.push({
              id: uid("ses"),
              subjectId: subject.id,
              title: p.title,
              date: p.date,
              startTime: p.startTime,
              durationMin: p.durationMin,
              completed: false,
              source: "ai",
              createdAt: nowISO(),
            });
            added += 1;
          }
          set((s) => ({ subjects: [...s.subjects, ...newSubjects], sessions: [...s.sessions, ...newSessions] }));
          return { added, skipped };
        },

        /* ── tasks ────────────────────────────────────────────────── */
        addTask: (input) => {
          const task: Task = {
            id: uid("tsk"),
            title: input.title.trim(),
            description: input.description,
            subjectId: input.subjectId,
            dueDate: input.dueDate,
            priority: input.priority ?? "medium",
            status: input.status ?? "todo",
            createdAt: nowISO(),
          };
          set((s) => ({ tasks: [task, ...s.tasks] }));
        },

        updateTask: (id, patch) =>
          set((s) => ({
            tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
          })),

        deleteTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),

        setTaskStatus: (id, status) =>
          set((s) => ({
            tasks: s.tasks.map((t) =>
              t.id === id
                ? { ...t, status, completedAt: status === "done" ? nowISO() : undefined }
                : t
            ),
          })),

        /* ── exams ────────────────────────────────────────────────── */
        addExam: (input) => {
          const exam: Exam = { ...input, id: uid("exm"), createdAt: nowISO() };
          set((s) => ({ exams: [...s.exams, exam] }));
        },

        updateExam: (id, patch) =>
          set((s) => ({ exams: s.exams.map((ex) => (ex.id === id ? { ...ex, ...patch } : ex)) })),

        deleteExam: (id) => set((s) => ({ exams: s.exams.filter((ex) => ex.id !== id) })),

        /* ── settings ─────────────────────────────────────────────── */
        setLocale: (locale) => set((s) => ({ settings: { ...s.settings, locale } })),

        setAccent: (accent) => {
          set((s) => ({ settings: { ...s.settings, accent } }));
          applyAccent(accent);
        },

        setDefaultSessionMin: (min) => set((s) => ({ settings: { ...s.settings, defaultSessionMin: min } })),

        /* ── data ─────────────────────────────────────────────────── */
        exportData: () => {
          const { subjects, sessions, tasks, exams, settings, user } = get();
          return JSON.stringify(
            { app: "studykit", version: 1, exportedAt: nowISO(), subjects, sessions, tasks, exams, settings, user },
            null,
            2
          );
        },

        importData: (json) => {
          try {
            const parsed = JSON.parse(json) as Record<string, unknown>;
            if (parsed.app !== "studykit" || !Array.isArray(parsed.subjects) || !Array.isArray(parsed.sessions)) {
              return { ok: false };
            }
            set((s) => ({
              subjects: parsed.subjects as Subject[],
              sessions: parsed.sessions as StudySession[],
              tasks: (Array.isArray(parsed.tasks) ? parsed.tasks : s.tasks) as Task[],
              exams: (Array.isArray(parsed.exams) ? parsed.exams : s.exams) as Exam[],
              settings: (parsed.settings as AppSettings) ?? s.settings,
            }));
            const acc = get().settings.accent;
            applyAccent(acc);
            return { ok: true };
          } catch {
            return { ok: false };
          }
        },

        loadSampleData: () => {
          const seed = buildSeedData();
          set((s) => ({ ...seed, settings: { ...s.settings, onboardingDone: true } }));
        },

        clearAllData: () =>
          set((s) => ({ subjects: [], sessions: [], tasks: [], exams: [] })),
      };
    },
    {
      name: "studykit-store",
      version: 3,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        user: s.user,
        subjects: s.subjects,
        sessions: s.sessions,
        tasks: s.tasks,
        exams: s.exams,
        settings: s.settings,
      }),
      migrate: (persisted) => {
        // v1 → v2: local demo accounts are obsolete (real server accounts now).
        // v2 → v3: the Free/Pro plans feature was removed — drop subscription.
        const p = persisted as Partial<StudyKitState> & { accounts?: unknown; subscription?: unknown };
        if ("accounts" in p) delete p.accounts;
        if ("subscription" in p) delete p.subscription;
        return p as StudyKitState;
      },
      onRehydrateStorage: () => (state) => {
        // Runs after rehydration on the client; applies persisted accent.
        state?.setHydrated?.();
      },
    }
  )
);

/**
 * Robust boot: runs once after the module is fully evaluated.
 * - Attaches the sync watcher (safe here — `useStudyKitStore` exists).
 * - Calls setHydrated explicitly (persist skips its callback on first visit).
 * - Validates the session against the server on every boot:
 *     · a valid cookie session always wins (it may be another device of the
 *       same account) and server data is pulled in;
 *     · a cached non-guest user without a valid session (stale demo account
 *       or expired cookie) is signed out locally.
 */
if (typeof window !== "undefined") {
  queueMicrotask(() => {
    attachSyncWatcher();
    useStudyKitStore.getState().setHydrated();
    void (async () => {
      const serverUser = await fetchSessionUser();
      if (serverUser) {
        useStudyKitStore.setState((s) => ({
          user: serverUser,
          settings: { ...s.settings, onboardingDone: true },
        }));
        await pullServerData();
      } else if (useStudyKitStore.getState().user && useStudyKitStore.getState().user!.id !== "guest") {
        useStudyKitStore.setState({
          user: null,
          _syncState: "idle",
          _lastSyncAt: null,
        });
      }
    })();
  });
}

/* Selector helpers (cheap derived reads) */
export const useUser = () => useStudyKitStore((s) => s.user);
export const useSettings = () => useStudyKitStore((s) => s.settings);
export const useSyncState = () => useStudyKitStore((s) => s._syncState);

/* Debug handle (harmless in production). */
if (typeof window !== "undefined") {
  (window as unknown as { __sk: typeof useStudyKitStore }).__sk = useStudyKitStore;
}
