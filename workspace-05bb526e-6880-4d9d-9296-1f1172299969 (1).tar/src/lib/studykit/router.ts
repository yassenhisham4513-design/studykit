"use client";

/**
 * Tiny hash-based router. Keeps everything on the single `/` route while
 * giving real navigation semantics: shareable URLs, working back/forward.
 * When the app moves to real Next.js routes, swap `navigate()` for
 * `router.push()` — call sites don't change.
 */

import { useCallback, useEffect, useState } from "react";

export const ROUTES = {
  landing: "/",
  auth: "/auth",
  dashboard: "/app/dashboard",
  planner: "/app/planner",
  tasks: "/app/tasks",
  exams: "/app/exams",
  progress: "/app/progress",
  assistant: "/app/assistant",
  settings: "/app/settings",
} as const;

export type RoutePath = (typeof ROUTES)[keyof typeof ROUTES];

export function currentPath(): string {
  if (typeof window === "undefined") return ROUTES.landing;
  const raw = window.location.hash.replace(/^#/, "");
  return raw || ROUTES.landing;
}

export function navigate(to: string, opts?: { replace?: boolean }) {
  const target = `#${to}`;
  if (opts?.replace) {
    window.history.replaceState(null, "", target);
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = target;
  }
}

export function useHashRoute(): string {
  const [path, setPath] = useState<string>(() => currentPath());

  useEffect(() => {
    const onChange = () => setPath(currentPath());
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  return path;
}

/** Query params of the current hash route (e.g. #/app/tasks?add=1). */
export function useRouteQuery(): URLSearchParams {
  const path = useHashRoute();
  const qi = path.indexOf("?");
  return new URLSearchParams(qi >= 0 ? path.slice(qi + 1) : "");
}

export function stripQuery(path: string): string {
  const qi = path.indexOf("?");
  return qi >= 0 ? path.slice(0, qi) : path;
}

/** Scroll to top on route change. */
export function useScrollTopOnRoute(path: string) {
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [path]);
}

export function useNavigate() {
  return useCallback((to: string, opts?: { replace?: boolean }) => navigate(to, opts), []);
}
