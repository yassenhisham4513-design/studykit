/**
 * StudyKit — realistic sample data generator.
 * Dates are computed relative to "today" so charts, countdowns and streaks
 * always look alive. Used by onboarding ("start with sample data") and
 * Settings → "Load sample data".
 */

import type { Subject, StudySession, Task, Exam } from "./types";
import { addDaysISO, startOfWeekISO, todayISO, uid, pickSubjectColor } from "./utils";

export interface SeedPayload {
  subjects: Subject[];
  sessions: StudySession[];
  tasks: Task[];
  exams: Exam[];
}

/** Simple deterministic PRNG so the sample dataset is stable per install. */
function mulberry(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildSeedData(): SeedPayload {
  const rand = mulberry(20260101);
  const today = todayISO();

  const subjectDefs: { name: string; target: number }[] = [
    { name: "Mathematics", target: 6 },
    { name: "Physics", target: 5 },
    { name: "Chemistry", target: 4 },
    { name: "Computer Science", target: 5 },
    { name: "English", target: 3 },
  ];
  const subjects: Subject[] = subjectDefs.map((s, i) => ({
    id: uid("sub"),
    name: s.name,
    color: pickSubjectColor(i),
    weeklyTargetHours: s.target,
    createdAt: new Date().toISOString(),
  }));
  const [math, phys, chem, cs, eng] = subjects;

  const sessionTopics: Record<string, string[]> = {
    [math.id]: ["Calculus — integration techniques", "Sequences & series practice", "Vectors revision", "Past paper drill"],
    [phys.id]: ["Electromagnetism — Faraday's law", "Mechanics problem set", "Waves & optics summary", "Lab report review"],
    [chem.id]: ["Organic reactions map", "Mole calculations practice", "Periodicity revision", "Titration lab prep"],
    [cs.id]: ["Data structures — trees", "Algorithms: sorting practice", "SQL exercises", "Project: build feature"],
    [eng.id]: ["Essay structure practice", "Reading comprehension", "Vocabulary review"],
  };

  const sessions: StudySession[] = [];

  // Past 5 weeks of history (completed) — gives charts & streaks real data.
  for (let d = 35; d >= 1; d--) {
    const date = addDaysISO(today, -d);
    const day = new Date(date).getDay();
    if (day === 6) continue; // Saturday off in the sample
    const count = 1 + Math.floor(rand() * 3); // 1–3 sessions
    const used = new Set<string>();
    for (let i = 0; i < count; i++) {
      const subject = subjects[Math.floor(rand() * subjects.length)];
      if (used.has(subject.id)) continue;
      used.add(subject.id);
      const startHour = 15 + Math.floor(rand() * 4);
      const topics = sessionTopics[subject.id];
      sessions.push({
        id: uid("ses"),
        subjectId: subject.id,
        title: topics[Math.floor(rand() * topics.length)],
        date,
        startTime: `${String(startHour).padStart(2, "0")}:${rand() > 0.5 ? "00" : "30"}`,
        durationMin: [40, 50, 60, 90][Math.floor(rand() * 4)],
        completed: true,
        completedAt: new Date(`${date}T21:00:00`).toISOString(),
        createdAt: new Date().toISOString(),
        source: "manual",
      });
    }
  }

  // This week: Monday–today, mixed completed/planned. Today's session is
  // completed so "study time today" shows real data.
  const weekStart = startOfWeekISO(today);
  for (let i = 0; i < 7; i++) {
    const date = addDaysISO(weekStart, i);
    if (date > today || date < weekStart) continue;
    const subject = subjects[i % subjects.length];
    const topics = sessionTopics[subject.id];
    const isPast = date < today;
    sessions.push({
      id: uid("ses"),
      subjectId: subject.id,
      title: topics[i % topics.length],
      date,
      startTime: "16:00",
      durationMin: 60,
      completed: isPast ? i % 4 !== 3 : true,
      completedAt: isPast && i % 4 !== 3 ? new Date(`${date}T21:00:00`).toISOString() : date === today ? new Date().toISOString() : undefined,
      createdAt: new Date().toISOString(),
      source: "manual",
    });
  }

  // Next 7 days: planned upcoming sessions.
  for (let d = 1; d <= 7; d++) {
    const date = addDaysISO(today, d);
    const count = d <= 3 ? 2 : 1;
    for (let i = 0; i < count; i++) {
      const subject = subjects[(d + i) % subjects.length];
      const topics = sessionTopics[subject.id];
      sessions.push({
        id: uid("ses"),
        subjectId: subject.id,
        title: topics[(d + i) % topics.length],
        date,
        startTime: i === 0 ? "16:00" : "18:00",
        durationMin: 60,
        completed: false,
        createdAt: new Date().toISOString(),
        source: "manual",
      });
    }
  }

  const tasks: Task[] = [
    { id: uid("tsk"), title: "Physics problem set 5", description: "Chapter 8, problems 1–18. Submit on the portal.", subjectId: phys.id, dueDate: addDaysISO(today, 1), priority: "high", status: "in_progress", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Chemistry lab report — titration", description: "Include error analysis and graphs.", subjectId: chem.id, dueDate: addDaysISO(today, 3), priority: "high", status: "todo", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Math worksheet — series", subjectId: math.id, dueDate: addDaysISO(today, 2), priority: "medium", status: "todo", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "CS project: finish search feature", description: "Implement + write tests.", subjectId: cs.id, dueDate: addDaysISO(today, 5), priority: "medium", status: "in_progress", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "English essay draft", subjectId: eng.id, dueDate: addDaysISO(today, 6), priority: "low", status: "todo", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Review lecture 7 notes", subjectId: phys.id, dueDate: addDaysISO(today, -1), priority: "medium", status: "todo", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Print past papers for Chemistry", subjectId: chem.id, dueDate: addDaysISO(today, 4), priority: "low", status: "todo", createdAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Submit scholarship form", dueDate: addDaysISO(today, -3), priority: "high", status: "done", createdAt: new Date().toISOString(), completedAt: new Date().toISOString() },
    { id: uid("tsk"), title: "Math quiz corrections", subjectId: math.id, dueDate: addDaysISO(today, -2), priority: "medium", status: "done", createdAt: new Date().toISOString(), completedAt: new Date().toISOString() },
  ];

  const exams: Exam[] = [
    { id: uid("exm"), title: "Chemistry quiz — Chapter 4", subjectId: chem.id, date: addDaysISO(today, 4), time: "10:00", location: "Room 214", notes: "Covers acids & bases, pH calculations.", createdAt: new Date().toISOString() },
    { id: uid("exm"), title: "Mathematics midterm", subjectId: math.id, date: addDaysISO(today, 9), time: "09:00", location: "Exam hall A", notes: "Integration, series, vectors.", createdAt: new Date().toISOString() },
    { id: uid("exm"), title: "Physics final", subjectId: phys.id, date: addDaysISO(today, 21), time: "13:00", location: "Science building", notes: "Full syllabus. Formula sheet allowed.", createdAt: new Date().toISOString() },
  ];

  return { subjects, sessions, tasks, exams };
}
