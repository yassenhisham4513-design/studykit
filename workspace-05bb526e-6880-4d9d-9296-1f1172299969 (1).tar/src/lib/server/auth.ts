import "server-only";

/**
 * StudyKit — server-side authentication core.
 *
 * - Passwords: scrypt (Node crypto) with per-user random salt; verification
 *   uses timing-safe comparison. Plain passwords are never stored or logged.
 * - Sessions: stateless signed tokens (HMAC-SHA256) delivered in an
 *   HTTP-only, SameSite=Lax cookie. No token ever reaches client JS.
 * - AUTH_SECRET comes from the environment; a dev fallback keeps local
 *   development working but production must set a real secret.
 */

import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "sk_session";
const SESSION_TTL_DAYS = 30;
const SCRYPT_KEYLEN = 64;

function authSecret(): string {
  return process.env.AUTH_SECRET || "studykit-dev-secret-do-not-use-in-production";
}

/* ── Passwords ─────────────────────────────────────────────────────────── */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, SCRYPT_KEYLEN).toString("hex");
  return `s2:${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(":");
  if (parts.length !== 3 || parts[0] !== "s2") return false;
  const [, salt, expectedHex] = parts;
  const actual = scryptSync(password, salt, SCRYPT_KEYLEN);
  const expected = Buffer.from(expectedHex, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

/* ── Session tokens ────────────────────────────────────────────────────── */

interface SessionPayload {
  uid: string;
  exp: number; // epoch ms
}

function sign(data: string): string {
  return createHmac("sha256", authSecret()).update(data).digest("base64url");
}

export function createSessionToken(userId: string): string {
  const payload: SessionPayload = {
    uid: userId,
    exp: Date.now() + SESSION_TTL_DAYS * 86_400_000,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return null;
  const body = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expected = sign(body);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as SessionPayload;
    if (typeof payload.uid !== "string" || typeof payload.exp !== "number") return null;
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/* ── Cookie helpers ────────────────────────────────────────────────────── */

export async function setSessionCookie(userId: string): Promise<void> {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, createSessionToken(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_DAYS * 86_400,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/* ── Current user ──────────────────────────────────────────────────────── */

const userSelect = {
  id: true,
  email: true,
  name: true,
  university: true,
  level: true,
  createdAt: true,
} as const;

export async function getSessionUser() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = verifySessionToken(token);
  if (!payload) return null;
  return db.user.findUnique({ where: { id: payload.uid }, select: userSelect });
}

/** Shape returned to the client — never includes the password hash. */
export function publicUser(u: {
  id: string;
  email: string;
  name: string;
  university: string | null;
  level: string | null;
  createdAt: Date;
}) {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    university: u.university ?? undefined,
    level: u.level ?? undefined,
    createdAt: u.createdAt.toISOString(),
  };
}

export type PublicUser = ReturnType<typeof publicUser>;
