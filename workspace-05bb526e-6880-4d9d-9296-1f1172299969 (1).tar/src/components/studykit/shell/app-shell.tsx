"use client";

/**
 * App shell — desktop sidebar + mobile drawer/bottom nav + topbar.
 * Fully RTL-aware via logical Tailwind utilities; direction comes from the
 * root element that the i18n provider controls.
 */

import { useState } from "react";
import { motion } from "framer-motion";
import {
  CalendarRange,
  ChartColumn,
  ChevronsDownUp,
  ClipboardList,
  Compass,
  Globe,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Menu,
  Monitor,
  Moon,
  Settings as SettingsIcon,
  Sparkles,
  Sun,
  Timer,
  UserRound,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, useHashRoute, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore, useUser } from "@/lib/studykit/store";
import { Logo } from "@/components/studykit/shared/ui";

interface NavItem {
  route: string;
  labelKey: string;
  icon: LucideIcon;
}

const MAIN_NAV: NavItem[] = [
  { route: ROUTES.dashboard, labelKey: "nav.dashboard", icon: LayoutDashboard },
  { route: ROUTES.planner, labelKey: "nav.planner", icon: CalendarRange },
  { route: ROUTES.tasks, labelKey: "nav.tasks", icon: ListChecks },
  { route: ROUTES.exams, labelKey: "nav.exams", icon: Timer },
  { route: ROUTES.progress, labelKey: "nav.progress", icon: ChartColumn },
  { route: ROUTES.assistant, labelKey: "nav.assistant", icon: Sparkles },
];

const ACCOUNT_NAV: NavItem[] = [
  { route: ROUTES.settings, labelKey: "nav.settings", icon: SettingsIcon },
];

/* ── Nav buttons ───────────────────────────────────────────────────────── */

function NavLink({ item, active, onSelect, showLabel = true }: { item: NavItem; active: boolean; onSelect: () => void; showLabel?: boolean }) {
  const { t } = useI18n();
  return (
    <button
      onClick={onSelect}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
        active
          ? "bg-primary/10 text-primary"
          : "text-muted-foreground hover:bg-muted hover:text-foreground",
        !showLabel && "justify-center px-0"
      )}
    >
      {active && (
        <motion.span
          layoutId="nav-active"
          className="absolute inset-y-1 start-0 w-1 rounded-full bg-primary"
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
        />
      )}
      <item.icon className={cn("size-[18px] shrink-0", active && "text-primary")} />
      {showLabel && <span className="truncate">{t(item.labelKey as never)}</span>}
    </button>
  );
}

/* ── Sidebar ───────────────────────────────────────────────────────────── */

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const path = useHashRoute();
  const { t } = useI18n();

  const go = (route: string) => {
    navigate(route);
    onNavigate?.();
  };

  return (
    <div className="flex h-full flex-col">
      <div className="px-4 pt-5">
        <button onClick={() => go(ROUTES.dashboard)} className="inline-flex" aria-label="StudyKit">
          <Logo />
        </button>
      </div>

      <nav className="mt-6 flex-1 space-y-6 overflow-y-auto px-3 pb-4 scrollbar-slim" aria-label={t("nav.menu")}>
        <div className="space-y-1">
          <p className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            {t("nav.mainMenu")}
          </p>
          {MAIN_NAV.map((item) => (
            <NavLink key={item.route} item={item} active={path === item.route} onSelect={() => go(item.route)} />
          ))}
        </div>
        <div className="space-y-1">
          <p className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            {t("nav.accountMenu")}
          </p>
          {ACCOUNT_NAV.map((item) => (
            <NavLink key={item.route} item={item} active={path === item.route} onSelect={() => go(item.route)} />
          ))}
        </div>
      </nav>

      <div className="space-y-3 px-3 pb-4">
        <UserCard />
      </div>
    </div>
  );
}

function UserCard() {
  const user = useUser();
  const { t } = useI18n();
  const store = useStudyKitStore;
  if (!user) return null;

  const initials = user.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex w-full items-center gap-3 rounded-xl border bg-card p-2.5 text-start transition-colors hover:bg-muted">
          <Avatar className="size-8">
            <AvatarFallback className="bg-primary/10 text-xs font-bold text-primary">{initials || "?"}</AvatarFallback>
          </Avatar>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-semibold">{user.name}</span>
            <span className="block truncate text-[11px] text-muted-foreground" dir="ltr">
              {user.email}
            </span>
          </span>
          <ChevronsDownUp className="size-3.5 shrink-0 text-muted-foreground" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" side="top" className="w-60">
        <DropdownMenuLabel>
          <span>{user.name}</span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => navigate(ROUTES.settings)}>
          <UserRound className="size-4" />
          {t("shell.profile")}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          variant="destructive"
          onClick={() => {
            store.getState().logout();
            toast.success(t("auth.loggedOut"));
            navigate(ROUTES.landing);
          }}
        >
          <LogOut className="size-4" />
          {t("nav.logout")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

/* ── Topbar ────────────────────────────────────────────────────────────── */

function ThemeMenu() {
  const { theme, setTheme } = useTheme();
  const { t } = useI18n();
  const options = [
    { value: "light", icon: Sun, label: t("common.themeLight") },
    { value: "dark", icon: Moon, label: t("common.themeDark") },
    { value: "system", icon: Monitor, label: t("common.themeSystem") },
  ] as const;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={t("shell.toggleTheme")}>
          <Sun className="size-[18px] dark:hidden" />
          <Moon className="hidden size-[18px] dark:block" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {options.map((o) => (
          <DropdownMenuItem key={o.value} onClick={() => setTheme(o.value)} className={cn(theme === o.value && "bg-muted")}>
            <o.icon className="size-4" />
            {o.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function LangToggle() {
  const { t, toggleLocale, locale } = useI18n();
  return (
    <TooltipProvider delayDuration={200}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost" size="icon" aria-label={t("shell.toggleLanguage")} onClick={toggleLocale}>
            <span className="flex items-center gap-1 text-xs font-bold">
              <Globe className="size-4" />
              {locale === "en" ? "ع" : "EN"}
            </span>
          </Button>
        </TooltipTrigger>
        <TooltipContent>{t("shell.toggleLanguage")}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function Topbar() {
  const { t, dir } = useI18n();
  const path = useHashRoute();
  const current = [...MAIN_NAV, ...ACCOUNT_NAV].find((i) => i.route === path);
  const [navOpen, setNavOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b bg-background/80 px-4 backdrop-blur sm:px-6">
      <div className="flex items-center gap-2 min-w-0">
        {/* Mobile: drawer trigger */}
        <Sheet open={navOpen} onOpenChange={setNavOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="lg:hidden" aria-label={t("nav.openMenu")}>
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side={dir === "rtl" ? "right" : "left"} className="w-72 p-0">
            <SheetHeader className="sr-only">
              <SheetTitle>{t("nav.menu")}</SheetTitle>
            </SheetHeader>
            <SidebarContent onNavigate={() => setNavOpen(false)} />
          </SheetContent>
        </Sheet>
        <span className="lg:hidden">
          <Logo compact />
        </span>
        <h2 className="hidden truncate font-display text-lg font-bold lg:block">
          {current ? t(current.labelKey as never) : t("nav.dashboard")}
        </h2>
      </div>
      <div className="flex items-center gap-1">
        <LangToggle />
        <ThemeMenu />
      </div>
    </header>
  );
}

/* ── Mobile bottom nav ─────────────────────────────────────────────────── */

function BottomNav() {
  const path = useHashRoute();
  const { t } = useI18n();
  const items = MAIN_NAV.slice(0, 5);
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t bg-background/90 backdrop-blur lg:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label={t("nav.menu")}
    >
      <div className="mx-auto grid max-w-lg grid-cols-5">
        {items.map((item) => {
          const active = path === item.route;
          return (
            <button
              key={item.route}
              onClick={() => navigate(item.route)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex min-h-[3.25rem] flex-col items-center justify-center gap-1 py-1.5 text-[10px] font-medium transition-colors",
                active ? "text-primary" : "text-muted-foreground"
              )}
            >
              <item.icon className="size-5" />
              <span className="truncate px-0.5">{t(item.labelKey as never)}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

/* ── Shell ─────────────────────────────────────────────────────────────── */

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-e bg-sidebar text-sidebar-foreground lg:flex lg:flex-col">
        <SidebarContent />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main className="flex-1 px-4 py-6 pb-24 sm:px-6 lg:pb-10">
          <div className="mx-auto w-full max-w-6xl">{children}</div>
        </main>
        <BottomNav />
      </div>
    </div>
  );
}
