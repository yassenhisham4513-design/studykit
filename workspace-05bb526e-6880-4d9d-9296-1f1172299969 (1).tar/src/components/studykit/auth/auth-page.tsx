"use client";

/**
 * Auth surface — demo authentication (localStorage accounts, SHA-256 hashed
 * passwords, never transmitted). The `localAuthProvider` calls here mirror
 * the NextAuth credentials flow, so swapping to real auth later means
 * replacing the store calls with a provider call only.
 */

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { ArrowLeft, DatabaseZap, GraduationCap, Info, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import { Logo } from "@/components/studykit/shared/ui";

/* ── Schemas ───────────────────────────────────────────────────────────── */

function useSchemas() {
  const { t } = useI18n();
  const loginSchema = z.object({
    email: z.string().min(1, t("validation.emailRequired")).email(t("validation.emailInvalid")),
    password: z.string().min(1, t("validation.passwordRequired")),
  });
  const registerSchema = z
    .object({
      name: z.string().min(2, t("validation.nameShort")),
      email: z.string().min(1, t("validation.emailRequired")).email(t("validation.emailInvalid")),
      password: z.string().min(6, t("validation.passwordShort")),
      confirmPassword: z.string(),
      university: z.string().optional(),
      level: z.string().optional(),
    })
    .refine((v) => v.password === v.confirmPassword, {
      message: t("validation.passwordMismatch"),
      path: ["confirmPassword"],
    });
  return { loginSchema, registerSchema };
}

type LoginValues = z.infer<ReturnType<typeof useSchemas>["loginSchema"]>;
type RegisterValues = z.infer<ReturnType<typeof useSchemas>["registerSchema"]>;

/* ── Field ─────────────────────────────────────────────────────────────── */

function Field({
  id,
  label,
  error,
  optional,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  optional?: boolean;
  children: React.ReactNode;
}) {
  const { t } = useI18n();
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-sm">
        {label}
        {optional && <span className="ms-1.5 text-xs font-normal text-muted-foreground">({t("common.optional")})</span>}
      </Label>
      {children}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );
}

/* ── Page ──────────────────────────────────────────────────────────────── */

export function AuthPage() {
  const { t } = useI18n();
  const { loginSchema, registerSchema } = useSchemas();
  const store = useStudyKitStore;
  const [pending, setPending] = useState<"login" | "register" | "guest" | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { name: "", email: "", password: "", confirmPassword: "", university: "", level: "" },
  });

  const errorKeys: Record<string, string> = {
    invalidCredentials: t("auth.invalidCredentials"),
    emailTaken: t("auth.emailTaken"),
    networkError: t("auth.networkError"),
  };

  const onLogin = loginForm.handleSubmit(async (values) => {
    setPending("login");
    setAuthError(null);
    const res = await store.getState().login(values);
    setPending(null);
    if (res.ok) {
      toast.success(t("auth.welcomeBack"));
      navigate(ROUTES.dashboard);
    } else {
      setAuthError(res.error ? errorKeys[res.error] : t("common.error"));
    }
  });

  const onRegister = async (withSampleData: boolean) => {
    const valid = await registerForm.trigger();
    if (!valid) return;
    setPending("register");
    setAuthError(null);
    const values = registerForm.getValues();
    const res = await store.getState().register({ ...values, withSampleData });
    setPending(null);
    if (res.ok) {
      toast.success(t("auth.accountCreated"));
      navigate(ROUTES.dashboard);
    } else {
      setAuthError(res.error ? errorKeys[res.error] : t("common.error"));
    }
  };

  const onGuest = () => {
    setPending("guest");
    store.getState().loginGuest();
    toast.success(t("auth.welcomeBack"));
    navigate(ROUTES.dashboard);
  };

  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      <div className="absolute inset-0 bg-grid" aria-hidden />
      <div className="absolute -top-20 start-1/3 size-72 rounded-full bg-primary/10 blur-3xl" aria-hidden />

      <header className="relative z-10 mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
        <button onClick={() => navigate(ROUTES.landing)} aria-label={t("nav.home")}>
          <Logo />
        </button>
        <Button variant="ghost" size="sm" onClick={() => navigate(ROUTES.landing)}>
          <ArrowLeft className="size-4 rtl:rotate-180" />
          {t("nav.home")}
        </Button>
      </header>

      <main className="relative z-10 flex flex-1 items-center justify-center px-4 py-8 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className="w-full max-w-md"
        >
          <div className="mb-6 text-center">
            <span className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-primary/10">
              <GraduationCap className="size-6 text-primary" />
            </span>
          </div>

          <Tabs defaultValue="register" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="register">{t("nav.register")}</TabsTrigger>
              <TabsTrigger value="login">{t("nav.login")}</TabsTrigger>
            </TabsList>

            {/* ── Register ── */}
            <TabsContent value="register">
              <div className="rounded-2xl border bg-card p-6 shadow-sm">
                <h1 className="font-display text-xl font-bold">{t("auth.registerTitle")}</h1>
                <p className="mt-1 text-sm text-muted-foreground">{t("auth.registerSubtitle")}</p>

                <form
                  className="mt-5 space-y-4"
                  onSubmit={(e) => {
                    e.preventDefault();
                    onRegister(false);
                  }}
                  noValidate
                >
                  <Field id="reg-name" label={t("auth.name")} error={registerForm.formState.errors.name?.message}>
                    <Input id="reg-name" placeholder={t("auth.namePlaceholder")} autoComplete="name" {...registerForm.register("name")} />
                  </Field>
                  <Field id="reg-email" label={t("auth.email")} error={registerForm.formState.errors.email?.message}>
                    <Input
                      id="reg-email"
                      type="email"
                      dir="ltr"
                      placeholder={t("auth.emailPlaceholder")}
                      autoComplete="email"
                      {...registerForm.register("email")}
                    />
                  </Field>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field id="reg-uni" label={t("auth.university")} optional error={registerForm.formState.errors.university?.message}>
                      <Input id="reg-uni" placeholder={t("auth.universityPlaceholder")} {...registerForm.register("university")} />
                    </Field>
                    <Field id="reg-level" label={t("auth.level")} optional error={registerForm.formState.errors.level?.message}>
                      <Input id="reg-level" placeholder={t("auth.levelPlaceholder")} {...registerForm.register("level")} />
                    </Field>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field id="reg-pass" label={t("auth.password")} error={registerForm.formState.errors.password?.message}>
                      <Input
                        id="reg-pass"
                        type="password"
                        dir="ltr"
                        placeholder={t("auth.passwordPlaceholder")}
                        autoComplete="new-password"
                        {...registerForm.register("password")}
                      />
                    </Field>
                    <Field id="reg-pass2" label={t("auth.confirmPassword")} error={registerForm.formState.errors.confirmPassword?.message}>
                      <Input
                        id="reg-pass2"
                        type="password"
                        dir="ltr"
                        autoComplete="new-password"
                        {...registerForm.register("confirmPassword")}
                      />
                    </Field>
                  </div>

                  {authError && (
                    <p className="rounded-lg bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">{authError}</p>
                  )}

                  <Button type="submit" className="w-full" disabled={pending !== null}>
                    {pending === "register" ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                    {t("auth.registerCta")}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    disabled={pending !== null}
                    onClick={() => onRegister(true)}
                  >
                    <DatabaseZap className="size-4" />
                    {t("auth.withSampleData")}
                  </Button>
                </form>

                <div className="mt-4 flex items-center gap-3">
                  <Separator className="flex-1" />
                  <span className="text-xs text-muted-foreground">{t("auth.or")}</span>
                  <Separator className="flex-1" />
                </div>

                <Button variant="ghost" className="mt-4 w-full" onClick={onGuest} disabled={pending !== null}>
                  {pending === "guest" ? <Loader2 className="size-4 animate-spin" /> : null}
                  {t("auth.guestCta")}
                </Button>
              </div>
            </TabsContent>

            {/* ── Login ── */}
            <TabsContent value="login">
              <div className="rounded-2xl border bg-card p-6 shadow-sm">
                <h1 className="font-display text-xl font-bold">{t("auth.loginTitle")}</h1>
                <p className="mt-1 text-sm text-muted-foreground">{t("auth.loginSubtitle")}</p>

                <form className="mt-5 space-y-4" onSubmit={onLogin} noValidate>
                  <Field id="log-email" label={t("auth.email")} error={loginForm.formState.errors.email?.message}>
                    <Input
                      id="log-email"
                      type="email"
                      dir="ltr"
                      placeholder={t("auth.emailPlaceholder")}
                      autoComplete="email"
                      {...loginForm.register("email")}
                    />
                  </Field>
                  <Field id="log-pass" label={t("auth.password")} error={loginForm.formState.errors.password?.message}>
                    <Input
                      id="log-pass"
                      type="password"
                      dir="ltr"
                      autoComplete="current-password"
                      {...loginForm.register("password")}
                    />
                  </Field>

                  {authError && (
                    <p className="rounded-lg bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">{authError}</p>
                  )}

                  <Button type="submit" className="w-full" disabled={pending !== null}>
                    {pending === "login" ? <Loader2 className="size-4 animate-spin" /> : null}
                    {t("auth.loginCta")}
                  </Button>
                </form>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-4 flex items-start gap-2 rounded-xl border bg-muted/40 px-4 py-3">
            <Info className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
            <p className="text-xs leading-relaxed text-muted-foreground">{t("auth.demoNotice")}</p>
          </div>

          <p className="mt-4 text-center text-xs text-muted-foreground">{t("auth.sampleDataHint")}</p>
        </motion.div>
      </main>
    </div>
  );
}
