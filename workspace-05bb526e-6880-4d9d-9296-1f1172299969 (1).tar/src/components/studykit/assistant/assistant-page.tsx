"use client";

/**
 * AI Study Assistant — three tools:
 *  1. Study plan generator (calls /api/ai/study-plan; the model runs
 *     server-side only; falls back to the built-in demo engine with a clear
 *     "Demo" badge).
 *  2. Subject priority organizer (deterministic scoring from real data).
 *  3. Spaced revision schedule builder.
 * Generated plans can be applied to the planner in one click.
 */

import { useEffect, useMemo, useState } from "react";
import {
  BrainCircuit,
  CalendarPlus,
  Check,
  ChevronRight,
  Info,
  ListOrdered,
  Loader2,
  RefreshCcw,
  Repeat2,
  Sparkles,
  Wand2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import { buildRevisionSchedule } from "@/lib/studykit/ai-engine";
import type { GeneratedPlan } from "@/lib/studykit/types";
import {
  daysBetween,
  formatDateMedium,
  formatDayShort,
  formatTime,
  minutesToLabel,
  todayISO,
} from "@/lib/studykit/utils";
import { PageHeader, SectionCard } from "@/components/studykit/shared/ui";

type Mode = "ai" | "demo";

export function AssistantPage() {
  const { t, locale } = useI18n();
  const subjects = useStudyKitStore((s) => s.subjects);
  const exams = useStudyKitStore((s) => s.exams);
  const tasks = useStudyKitStore((s) => s.tasks);
  const addPlanSessions = useStudyKitStore((s) => s.addPlanSessions);

  const [tab, setTab] = useState("plan");

  const today = todayISO();
  const upcomingExams = useMemo(
    () => exams.filter((e) => daysBetween(today, e.date) >= 0).sort((a, b) => a.date.localeCompare(b.date)),
    [exams, today]
  );
  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  /* ── Plan generator state ── */
  const [examId, setExamId] = useState<string>("");
  const [manualTitle, setManualTitle] = useState("");
  const [manualDate, setManualDate] = useState("");
  const [hours, setHours] = useState(2);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(
    subjects.slice(0, Math.min(3, subjects.length)).map((s) => s.name)
  );
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState<GeneratedPlan | null>(null);
  const [mode, setMode] = useState<Mode>("demo");

  /* ── Revision state ── */
  const [revExamId, setRevExamId] = useState("");
  const [revItems, setRevItems] = useState<{ date: string; title: string; durationMin: number }[] | null>(null);

  useEffect(() => {
    if (examId) {
      const exam = exams.find((e) => e.id === examId);
      if (exam && !selectedSubjects.length) {
        const name = subjectById.get(exam.subjectId)?.name;
        if (name) setSelectedSubjects([name]);
      }
    }
  }, [examId]);

  /* ── Priority organizer (deterministic, real data) ── */
  const priorities = useMemo(() => {
    const rows = subjects.map((sub) => {
      const exam = upcomingExams.find((e) => e.subjectId === sub.id);
      const d = exam ? daysBetween(today, exam.date) : null;
      const examPressure = d === null ? 0 : d <= 3 ? 100 : d <= 7 ? 82 : d <= 14 ? 62 : d <= 21 ? 42 : 25;
      const openTasks = tasks.filter((tk) => tk.subjectId === sub.id && tk.status !== "done").length;
      const taskScore = Math.min(100, openTasks * 30);
      const targetScore = Math.min(100, ((sub.weeklyTargetHours ?? 3) / 8) * 100);
      const score = Math.round(examPressure * 0.5 + taskScore * 0.3 + targetScore * 0.2);
      return { subject: sub, exam, daysLeft: d, openTasks, examPressure, taskScore, targetScore, score };
    });
    return rows.sort((a, b) => b.score - a.score);
  }, [subjects, upcomingExams, tasks, today]);

  const groupedPlan = useMemo(() => {
    if (!generated) return [];
    const map = new Map<string, GeneratedPlan["sessions"]>();
    for (const s of generated.sessions) {
      const arr = map.get(s.date) ?? [];
      arr.push(s);
      map.set(s.date, arr);
    }
    return [...map.entries()];
  }, [generated]);

  const generate = async () => {
    const chosen = exams.find((e) => e.id === examId);
    const examTitle = chosen?.title ?? manualTitle.trim();
    const examDate = chosen?.date ?? manualDate;

    if (!examTitle || !examDate) {
      toast.error(t("validation.titleRequired"));
      return;
    }
    if (chosen ? daysBetween(today, chosen.date) < 0 : examDate < today) {
      toast.error(t("validation.examDatePast"));
      return;
    }
    if (selectedSubjects.length === 0) {
      toast.error(t("assistant.formSubjects"));
      return;
    }

    setGenerating(true);
    setGenerated(null);
    try {
      const res = await fetch("/api/ai/study-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          examTitle,
          examDate,
          subjects: selectedSubjects,
          hoursPerDay: hours,
          startFrom: today,
          locale,
        }),
      });
      if (!res.ok) throw new Error(String(res.status));
      const data = (await res.json()) as { mode: Mode; plan: { summary: string; tips: string[]; sessions: GeneratedPlan["sessions"] } };
      setMode(data.mode);
      setGenerated({
        id: `plan_${Date.now()}`,
        createdAt: new Date().toISOString(),
        examId: chosen?.id,
        examTitle,
        examDate,
        mode: data.mode,
        summary: data.plan.summary,
        subjects: selectedSubjects,
        sessions: data.plan.sessions,
        tips: data.plan.tips,
      });
    } catch {
      toast.error(t("assistant.errorGenerating"));
    } finally {
      setGenerating(false);
    }
  };

  const applyPlan = () => {
    if (!generated) return;
    const res = addPlanSessions(generated.sessions);
    if (res.added > 0) {
      toast.success(t("assistant.resultApplied", { count: res.added }), {
        description: res.skipped > 0 ? `${res.skipped} skipped` : undefined,
      });
      navigate(ROUTES.planner);
    } else {
      toast.error(t("assistant.pastSkipped"));
    }
  };

  const buildRevision = () => {
    const exam = exams.find((e) => e.id === revExamId);
    if (!exam) {
      toast.error(t("assistant.revisionEmpty"));
      return;
    }
    const subjectName = subjectById.get(exam.subjectId)?.name ?? t("dashboard.noSubject");
    setRevItems(buildRevisionSchedule(exam.title, exam.date, subjectName, 1.5, locale));
  };

  const applyRevision = () => {
    if (!revItems) return;
    const res = addPlanSessions(
      revItems.map((r) => ({
        date: r.date,
        startTime: "18:00",
        durationMin: r.durationMin,
        subject: r.title.split(" — ")[0],
        title: r.title,
        kind: "revise" as const,
      }))
    );
    if (res.added > 0) {
      toast.success(t("assistant.revisionApplied"));
      navigate(ROUTES.planner);
    } else {
      toast.error(t("assistant.pastSkipped"));
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title={t("assistant.title")}
        subtitle={t("assistant.subtitle")}
        actions={
          <Badge variant="outline" className="gap-1.5 px-2.5 py-1">
            <Sparkles className={cn("size-3.5", mode === "ai" ? "text-primary" : "text-amber-500")} />
            {mode === "ai" ? t("assistant.badgeAI") : t("assistant.badgeDemo")}
          </Badge>
        }
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="plan" className="text-xs">
            <Wand2 className="me-1 size-3.5" />
            {t("assistant.tabPlan")}
          </TabsTrigger>
          <TabsTrigger value="priority" className="text-xs">
            <ListOrdered className="me-1 size-3.5" />
            {t("assistant.tabPriority")}
          </TabsTrigger>
          <TabsTrigger value="revision" className="text-xs">
            <Repeat2 className="me-1 size-3.5" />
            {t("assistant.tabRevision")}
          </TabsTrigger>
        </TabsList>

        {/* ── Study plan ── */}
        <TabsContent value="plan" className="mt-4 space-y-4">
          <SectionCard title={t("assistant.formGenerate")} icon={BrainCircuit}>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>{t("assistant.formExam")}</Label>
                <Select value={examId || "none"} onValueChange={(v) => setExamId(v === "none" ? "" : v)}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("assistant.formExamPlaceholder")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("common.none")}</SelectItem>
                    {upcomingExams.map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.title} · {formatDateMedium(e.date, locale)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {upcomingExams.length === 0 && (
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Info className="size-3" />
                    {t("assistant.formNoExam")}
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="ai-title">{t("assistant.formExamTitle")}</Label>
                  <Input
                    id="ai-title"
                    placeholder={t("assistant.formExamTitlePlaceholder")}
                    value={examId ? exams.find((e) => e.id === examId)?.title ?? "" : manualTitle}
                    disabled={!!examId}
                    onChange={(e) => setManualTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ai-date">{t("assistant.formExamDate")}</Label>
                  <Input
                    id="ai-date"
                    type="date"
                    dir="ltr"
                    min={today}
                    value={examId ? exams.find((e) => e.id === examId)?.date ?? "" : manualDate}
                    disabled={!!examId}
                    onChange={(e) => setManualDate(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-1.5">
              <Label>{t("assistant.formSubjects")}</Label>
              <div className="flex flex-wrap gap-2">
                {subjects.length === 0 && (
                  <Button variant="link" className="h-auto p-0 text-xs" onClick={() => navigate(ROUTES.planner)}>
                    {t("assistant.priorityEmpty")}
                  </Button>
                )}
                {subjects.map((s) => {
                  const checked = selectedSubjects.includes(s.name);
                  return (
                    <label
                      key={s.id}
                      className={cn(
                        "flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                        checked ? "border-primary bg-primary/10 text-primary" : "bg-card hover:bg-muted"
                      )}
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(v) =>
                          setSelectedSubjects((prev) => (v ? [...prev, s.name] : prev.filter((n) => n !== s.name)))
                        }
                        className="size-3.5"
                      />
                      <span className="size-2 rounded-full" style={{ backgroundColor: s.color }} />
                      {s.name}
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
              <div className="w-48 space-y-1.5">
                <Label htmlFor="ai-hours" className="num">
                  {t("assistant.formHours")}: {hours}h
                </Label>
                <input
                  id="ai-hours"
                  type="range"
                  min={0.5}
                  max={6}
                  step={0.5}
                  value={hours}
                  onChange={(e) => setHours(Number(e.target.value))}
                  className="w-full accent-[var(--primary)]"
                />
              </div>
              <Button onClick={generate} disabled={generating} className="min-w-44">
                {generating ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                {generating ? t("assistant.formGenerating") : t("assistant.formGenerate")}
              </Button>
            </div>
          </SectionCard>

          {/* Result */}
          {generating && (
            <div className="flex items-center justify-center gap-3 rounded-xl border bg-card py-10 text-sm text-muted-foreground">
              <Loader2 className="size-5 animate-spin text-primary" />
              {t("assistant.formGenerating")}
            </div>
          )}

          {!generating && !generated && (
            <div className="rounded-xl border border-dashed px-6 py-10 text-center text-sm text-muted-foreground">
              {t("assistant.resultEmpty")}
            </div>
          )}

          {!generating && generated && (
            <SectionCard
              title={t("assistant.resultTitle")}
              icon={Wand2}
              action={
                <div className="flex items-center gap-2">
                  <Badge
                    variant="outline"
                    className={cn(
                      "gap-1 text-[10px]",
                      generated.mode === "ai" ? "border-primary/40 text-primary" : "border-amber-500/40 text-amber-600 dark:text-amber-500"
                    )}
                  >
                    <Sparkles className="size-3" />
                    {generated.mode === "ai" ? t("assistant.modeAI") : t("assistant.modeDemo")}
                  </Badge>
                  <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={generate}>
                    <RefreshCcw className="size-3.5" />
                    {t("assistant.resultRegenerate")}
                  </Button>
                </div>
              }
            >
              <p className="text-xs text-muted-foreground">
                {generated.mode === "ai" ? t("assistant.modeHintAI") : t("assistant.modeHintDemo")}
              </p>

              <div className="mt-3 rounded-lg bg-muted/50 p-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t("assistant.resultSummary")}</p>
                <p className="mt-1 text-sm leading-relaxed">{generated.summary}</p>
                <p className="num mt-2 text-xs text-muted-foreground">
                  {t("assistant.resultSessions", {
                    count: generated.sessions.length,
                    hours: minutesToLabel(generated.sessions.reduce((a, s) => a + s.durationMin, 0), locale),
                  })}
                </p>
              </div>

              <div className="mt-4 max-h-96 space-y-4 overflow-y-auto pe-1 scrollbar-slim">
                {groupedPlan.map(([date, list]) => (
                  <div key={date}>
                    <h4 className="mb-1.5 text-xs font-bold text-muted-foreground">
                      {formatDayShort(date, locale)} · {formatDateMedium(date, locale)}
                    </h4>
                    <div className="space-y-1.5">
                      {list.map((s, i) => (
                        <div key={i} className="flex items-center gap-3 rounded-lg border bg-background/50 px-3 py-2">
                          <span className="num w-14 shrink-0 text-xs font-semibold text-primary">{formatTime(s.startTime, locale)}</span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-medium">{s.title}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {s.subject} · {minutesToLabel(s.durationMin, locale)} · {s.kind}
                            </p>
                          </div>
                          <Badge variant="secondary" className="shrink-0 text-[9px] uppercase">
                            {s.kind}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {generated.tips.length > 0 && (
                <div className="mt-4 rounded-lg border border-primary/25 bg-primary/5 p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary">{t("assistant.resultTips")}</p>
                  <ul className="mt-2 space-y-1.5">
                    {generated.tips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs leading-relaxed">
                        <Check className="mt-0.5 size-3.5 shrink-0 text-primary" />
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <Button className="mt-4 w-full" onClick={applyPlan}>
                <CalendarPlus className="size-4" />
                {t("assistant.resultApply")}
              </Button>
            </SectionCard>
          )}
        </TabsContent>

        {/* ── Priority organizer ── */}
        <TabsContent value="priority" className="mt-4">
          <SectionCard title={t("assistant.priorityTitle")} icon={ListOrdered}>
            <p className="text-xs text-muted-foreground">{t("assistant.priorityDesc")}</p>
            {priorities.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">{t("assistant.priorityEmpty")}</p>
            ) : (
              <>
                <div className="mt-4 space-y-2.5">
                  {priorities.map((row, i) => (
                    <div key={row.subject.id} className="rounded-xl border p-3">
                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            "num flex size-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold",
                            i === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                          )}
                        >
                          {i + 1}
                        </span>
                        <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: row.subject.color }} />
                        <span className="min-w-0 flex-1 truncate text-sm font-semibold">{row.subject.name}</span>
                        <span className="num text-sm font-bold text-primary">{row.score}</span>
                      </div>
                      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${row.score}%` }} />
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] text-muted-foreground">
                        <Badge variant="outline" className="text-[10px]">
                          {t("assistant.priorityExamPressure")}: {row.examPressure}
                        </Badge>
                        <Badge variant="outline" className="num text-[10px]">
                          {t("assistant.priorityPendingTasks")}: {row.openTasks}
                        </Badge>
                        {row.exam && row.daysLeft !== null && (
                          <Badge variant="outline" className="num text-[10px]">
                            {row.exam.title} — {t("dashboard.daysLeft", { count: row.daysLeft })}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-[11px] text-muted-foreground">{t("assistant.priorityHow")}</p>
              </>
            )}
          </SectionCard>
        </TabsContent>

        {/* ── Revision schedule ── */}
        <TabsContent value="revision" className="mt-4">
          <SectionCard title={t("assistant.revisionTitle")} icon={Repeat2}>
            <p className="text-xs text-muted-foreground">{t("assistant.revisionDesc")}</p>
            <div className="mt-4 flex flex-wrap items-end gap-3">
              <div className="min-w-56 flex-1 space-y-1.5">
                <Label>{t("assistant.revisionExam")}</Label>
                <Select value={revExamId || "none"} onValueChange={(v) => setRevExamId(v === "none" ? "" : v)}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("assistant.formExamPlaceholder")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("common.none")}</SelectItem>
                    {upcomingExams.map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.title} · {formatDateMedium(e.date, locale)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={buildRevision}>{t("assistant.revisionGenerate")}</Button>
            </div>

            {revItems && (
              <div className="mt-5">
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t("assistant.revisionResult")}</h4>
                <div className="space-y-2">
                  {revItems.map((r, i) => (
                    <div key={i} className="flex items-center gap-3 rounded-lg border bg-background/50 px-3 py-2.5">
                      <span className="num flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-xs font-bold text-primary">
                        {r.date.slice(8, 10)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{r.title}</p>
                        <p className="num text-[11px] text-muted-foreground">
                          {formatDateMedium(r.date, locale)} · {minutesToLabel(r.durationMin, locale)}
                        </p>
                      </div>
                      <ChevronRight className="size-4 shrink-0 text-muted-foreground/50 rtl:rotate-180" />
                    </div>
                  ))}
                </div>
                <Button className="mt-4 w-full" onClick={applyRevision}>
                  <CalendarPlus className="size-4" />
                  {t("assistant.resultApply")}
                </Button>
              </div>
            )}
          </SectionCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}
