"use client";

/** Create / edit exam dialog with validation (future date required). */

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/lib/studykit/i18n";
import type { Exam, Subject } from "@/lib/studykit/types";
import { todayISO } from "@/lib/studykit/utils";

export interface ExamFormValues {
  title: string;
  subjectId: string;
  date: string;
  time: string;
  location?: string;
  notes?: string;
}

export function ExamDialog({
  open,
  onOpenChange,
  subjects,
  exam,
  defaultSubjectId,
  onSubmit,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subjects: Subject[];
  exam?: Exam | null;
  defaultSubjectId?: string;
  onSubmit: (values: ExamFormValues, id?: string) => void;
  onDelete?: () => void;
}) {
  const { t } = useI18n();
  const [submitting, setSubmitting] = useState(false);

  const schema = useMemo(
    () =>
      z.object({
        title: z.string().min(1, t("validation.titleRequired")).max(120),
        subjectId: z.string().min(1, t("validation.subjectRequired")),
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, t("validation.dateRequired")),
        time: z.string().regex(/^\d{2}:\d{2}$/, t("validation.timeRequired")),
        location: z.string().max(120).optional(),
        notes: z.string().max(500).optional(),
      }),
    [t]
  );

  const form = useForm<ExamFormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", subjectId: defaultSubjectId ?? subjects[0]?.id ?? "", date: "", time: "09:00" },
  });

  useEffect(() => {
    if (!open) return;
    if (exam) {
      form.reset({
        title: exam.title,
        subjectId: exam.subjectId,
        date: exam.date,
        time: exam.time,
        location: exam.location ?? "",
        notes: exam.notes ?? "",
      });
    } else {
      form.reset({
        title: "",
        subjectId: defaultSubjectId ?? subjects[0]?.id ?? "",
        date: "",
        time: "09:00",
        location: "",
        notes: "",
      });
    }
  }, [open, exam, defaultSubjectId, subjects, form]);

  const handle = form.handleSubmit((values) => {
    // Future-date check (date must be >= today; time validated loosely).
    const chosen = new Date(`${values.date}T${values.time}`);
    if (values.date < todayISO()) {
      form.setError("date", { message: t("validation.examDatePast") });
      return;
    }
    setSubmitting(true);
    onSubmit(
      { ...values, location: values.location || undefined, notes: values.notes || undefined },
      exam?.id
    );
    void chosen;
    setTimeout(() => setSubmitting(false), 250);
  });

  const err = form.formState.errors;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{exam ? t("exams.editExam") : t("exams.addExam")}</DialogTitle>
          <DialogDescription>{t("exams.subtitle")}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handle} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="exam-title">{t("exams.examTitle")}</Label>
            <Input id="exam-title" placeholder={t("exams.examTitlePlaceholder")} {...form.register("title")} />
            {err.title && <p className="text-xs font-medium text-destructive">{err.title.message}</p>}
          </div>

          <div className="space-y-1.5">
            <Label>{t("planner.subject")}</Label>
            <Select value={form.watch("subjectId")} onValueChange={(v) => form.setValue("subjectId", v, { shouldValidate: true })}>
              <SelectTrigger aria-label={t("planner.subject")}>
                <SelectValue placeholder={t("planner.selectSubject")} />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    <span className="flex items-center gap-2">
                      <span className="size-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                      {s.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {err.subjectId && <p className="text-xs font-medium text-destructive">{err.subjectId.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="exam-date">{t("exams.date")}</Label>
              <Input id="exam-date" type="date" dir="ltr" min={todayISO()} {...form.register("date")} />
              {err.date && <p className="text-xs font-medium text-destructive">{err.date.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="exam-time">{t("exams.time")}</Label>
              <Input id="exam-time" type="time" dir="ltr" {...form.register("time")} />
              {err.time && <p className="text-xs font-medium text-destructive">{err.time.message}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="exam-loc">
              {t("exams.location")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
            </Label>
            <Input id="exam-loc" placeholder={t("exams.locationPlaceholder")} {...form.register("location")} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="exam-notes">
              {t("exams.notes")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
            </Label>
            <Textarea id="exam-notes" rows={2} placeholder={t("exams.notesPlaceholder")} {...form.register("notes")} />
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {exam && onDelete ? (
              <Button
                type="button"
                variant="ghost"
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={onDelete}
              >
                <Trash2 className="size-4" />
                {t("common.delete")}
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                {exam ? t("common.saveChanges") : t("common.save")}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
