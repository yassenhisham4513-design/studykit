"use client";

/**
 * Exam Countdown — live countdown cards, next-up spotlight, grouped by
 * subject, CRUD.
 */

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CalendarClock, MapPin, Pencil, Plus, Sparkles, Timer, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES, useRouteQuery } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import type { Exam } from "@/lib/studykit/types";
import { daysBetween, examDateTimeISO, formatDateMedium, formatTime, todayISO } from "@/lib/studykit/utils";
import { EmptyState, PageHeader, SubjectChip } from "@/components/studykit/shared/ui";
import { ConfirmDialog } from "@/components/studykit/shared/confirm-dialog";
import { LiveCountdown } from "@/components/studykit/shared/live-countdown";
import { ExamDialog, type ExamFormValues } from "./exam-dialog";

export function ExamsPage() {
  const { t, locale } = useI18n();
  const subjects = useStudyKitStore((s) => s.subjects);
  const exams = useStudyKitStore((s) => s.exams);
  const addExam = useStudyKitStore((s) => s.addExam);
  const updateExam = useStudyKitStore((s) => s.updateExam);
  const deleteExam = useStudyKitStore((s) => s.deleteExam);

  const query = useRouteQuery();
  // Dashboard deep link (?add=1): open the dialog on first render, then
  // clean the URL.
  const [dialogOpen, setDialogOpen] = useState(() => query.get("add") === "1");
  const [editing, setEditing] = useState<Exam | null>(null);
  const [deleting, setDeleting] = useState<Exam | null>(null);

  useEffect(() => {
    if (query.get("add") === "1") {
      navigate(ROUTES.exams, { replace: true }); // clean the query
    }
    // Run once on mount.
  }, []);

  const today = todayISO();
  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  const openNew = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const withDays = useMemo(
    () =>
      exams
        .map((e) => ({ exam: e, days: daysBetween(today, e.date) }))
        .sort((a, b) => {
          if (a.days !== b.days) return a.days - b.days;
          return examDateTimeISO(a.exam.date, a.exam.time).getTime() - examDateTimeISO(b.exam.date, b.exam.time).getTime();
        }),
    [exams, today]
  );

  const upcoming = useMemo(() => withDays.filter((x) => x.days >= 0), [withDays]);
  const past = useMemo(() => withDays.filter((x) => x.days < 0), [withDays]);
  const nextUp = upcoming[0];

  const submit = (values: ExamFormValues, id?: string) => {
    if (id) {
      updateExam(id, values);
    } else {
      addExam(values);
    }
    toast.success(t("exams.examSaved"));
    setDialogOpen(false);
  };

  /* Group upcoming by subject */
  const grouped = useMemo(() => {
    const map = new Map<string, typeof upcoming>();
    for (const item of upcoming) {
      const key = item.exam.subjectId || "_none";
      const arr = map.get(key) ?? [];
      arr.push(item);
      map.set(key, arr);
    }
    return map;
  }, [upcoming]);

  const renderCard = (exam: Exam, days: number, highlight = false) => {
    const subject = subjectById.get(exam.subjectId);
    const isToday = days === 0;
    const soon = days <= 3;
    return (
      <motion.div
        key={exam.id}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className={cn(
          "rounded-xl border bg-card p-4 transition-colors",
          highlight && "border-primary/50 ring-1 ring-primary/15",
          days < 0 && "opacity-60"
        )}
      >
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate font-semibold">{exam.title}</h3>
              {isToday && (
                <Badge className="gap-1 bg-primary">
                  <TriangleAlert className="size-3" />
                  {t("exams.examToday")}
                </Badge>
              )}
              {days < 0 && <Badge variant="outline">{t("exams.pastExam")}</Badge>}
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <SubjectChip subject={subject} />
              <span className="num inline-flex items-center gap-1">
                <CalendarClock className="size-3" />
                {formatDateMedium(exam.date, locale)} · {formatTime(exam.time, locale)}
              </span>
              {exam.location && (
                <span className="inline-flex items-center gap-1">
                  <MapPin className="size-3" />
                  {exam.location}
                </span>
              )}
            </div>
            {exam.notes && <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{exam.notes}</p>}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              aria-label={t("exams.editExam")}
              onClick={() => {
                setEditing(exam);
                setDialogOpen(true);
              }}
            >
              <Pencil className="size-3.5" />
            </Button>
          </div>
        </div>

        {days >= 0 && (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t pt-3">
            {isToday ? (
              <span className="text-sm font-bold text-primary">{t("exams.examToday")}</span>
            ) : (
              <LiveCountdown dateISO={exam.date} time={exam.time} locale={locale} className={soon ? "animate-pulse" : ""} />
            )}
            <span className="num text-xs text-muted-foreground">
              {isToday ? "" : t("dashboard.daysLeft", { count: days })}
            </span>
          </div>
        )}
      </motion.div>
    );
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title={t("exams.title")}
        subtitle={t("exams.subtitle")}
        actions={
          <Button onClick={openNew}>
            <Plus className="size-4" />
            {t("exams.addExam")}
          </Button>
        }
      />

      {withDays.length === 0 ? (
        <EmptyState
          icon={Timer}
          title={t("exams.empty")}
          description={t("exams.emptyHint")}
          action={
            <Button size="sm" onClick={openNew}>
              <Plus className="size-4" />
              {t("exams.emptyCta")}
            </Button>
          }
        />
      ) : (
        <>
          {/* Next up spotlight */}
          {nextUp && (
            <div>
              <h2 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-primary">
                <Sparkles className="size-4" />
                {t("exams.nextUp")}
              </h2>
              {renderCard(nextUp.exam, nextUp.days, true)}
            </div>
          )}

          {/* Grouped by subject */}
          <div className="space-y-6">
            {[...grouped.entries()].map(([subjectId, items]) => {
              const subject = subjectById.get(subjectId);
              return (
                <section key={subjectId}>
                  <h2 className="mb-2 flex items-center gap-2 text-sm font-bold text-muted-foreground">
                    <span className="size-2.5 rounded-full" style={{ backgroundColor: subject?.color ?? "var(--muted)" }} />
                    {t("exams.groupedBySubject")} — {subject?.name ?? t("dashboard.noSubject")}
                    <span className="num">({items.length})</span>
                  </h2>
                  <div className="grid gap-3 lg:grid-cols-2">
                    {items.map(({ exam, days }) => renderCard(exam, days))}
                  </div>
                </section>
              );
            })}
          </div>

          {/* Past */}
          {past.length > 0 && (
            <section>
              <h2 className="mb-2 text-sm font-bold text-muted-foreground">{t("exams.pastExam")}</h2>
              <div className="grid gap-3 lg:grid-cols-2">
                {past.map(({ exam, days }) => renderCard(exam, days))}
              </div>
            </section>
          )}
        </>
      )}

      <ExamDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        subjects={subjects}
        exam={editing}
        onSubmit={submit}
        onDelete={
          editing
            ? () => {
                setDialogOpen(false);
                setDeleting(editing);
              }
            : undefined
        }
      />

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(v) => !v && setDeleting(null)}
        title={t("exams.deleteExamTitle")}
        description={deleting ? t("exams.deleteExamDesc", { title: deleting.title }) : undefined}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        onConfirm={() => {
          if (!deleting) return;
          deleteExam(deleting.id);
          toast.success(t("exams.examDeleted"));
          setDeleting(null);
        }}
      />
    </div>
  );
}
