"use client";

/**
 * Dashboard — the daily command center: greeting, stat cards, quick actions,
 * today's schedule, upcoming exam countdowns and pending tasks. All numbers
 * are computed from real store data.
 */

import { useMemo } from "react";
import {
  BrainCircuit,
  CalendarPlus,
  ChartColumn,
  CheckCircle2,
  ChevronRight,
  CircleDashed,
  Clock,
  Flame,
  ListChecks,
  Play,
  Plus,
  Timer,
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/studykit/i18n";
import type { TKey } from "@/lib/studykit/i18n/en";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import type { Exam, StudySession, Subject, Task } from "@/lib/studykit/types";
import {
  addDaysISO,
  daysBetween,
  examDateTimeISO,
  formatDateLong,
  formatTime,
  minutesToLabel,
  startOfWeekISO,
  todayISO,
  weekDatesISO,
} from "@/lib/studykit/utils";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatCard,
  StreakBadge,
  SubjectChip,
} from "@/components/studykit/shared/ui";
import { LiveCountdown } from "@/components/studykit/shared/live-countdown";

/* ── Derived helpers ───────────────────────────────────────────────────── */

function useDashboardData() {
  const sessions = useStudyKitStore((s) => s.sessions);
  const tasks = useStudyKitStore((s) => s.tasks);
  const exams = useStudyKitStore((s) => s.exams);
  const subjects = useStudyKitStore((s) => s.subjects);
  const user = useStudyKitStore((s) => s.user);

  return useMemo(() => {
    const today = todayISO();
    const now = new Date();

    const subjectById = new Map(subjects.map((s) => [s.id, s]));

    // Today's study minutes (completed sessions only).
    const todaySessions = sessions
      .filter((s) => s.date === today)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
    const minutesToday = todaySessions
      .filter((s) => s.completed)
      .reduce((acc, s) => acc + s.durationMin, 0);

    // Week completion (sessions scheduled so far this week).
    const weekStart = startOfWeekISO(today);
    const weekDates = weekDatesISO(weekStart);
    const weekSessions = sessions.filter((s) => s.date >= weekStart && s.date <= today);
    const weekDone = weekSessions.filter((s) => s.completed).length;
    const weekCompletion = weekSessions.length ? Math.round((weekDone / weekSessions.length) * 100) : 0;
    const weekMinutes = weekSessions.filter((s) => s.completed).reduce((a, s) => a + s.durationMin, 0);

    // Per-day minutes for the mini chart (last 7 days).
    const perDay = weekDates.map((d) => ({
      date: d,
      minutes: sessions.filter((s) => s.date === d && s.completed).reduce((a, s) => a + s.durationMin, 0),
    }));

    // Streak: consecutive days (ending today or yesterday) with ≥1 completed session.
    const completedDates = new Set(sessions.filter((s) => s.completed).map((s) => s.date));
    let streak = 0;
    let cursor = today;
    if (!completedDates.has(cursor)) cursor = addDaysISO(today, -1);
    while (completedDates.has(cursor)) {
      streak += 1;
      cursor = addDaysISO(cursor, -1);
    }

    // Pending tasks (open, sorted by due date then priority).
    const pending = tasks
      .filter((t) => t.status !== "done")
      .sort((a, b) => {
        const ad = a.dueDate ?? "9999-12-31";
        const bd = b.dueDate ?? "9999-12-31";
        if (ad !== bd) return ad.localeCompare(bd);
        const pr = { high: 0, medium: 1, low: 2 } as const;
        return pr[a.priority] - pr[b.priority];
      });
    const overdueCount = pending.filter((t) => t.dueDate && t.dueDate < today).length;

    // Upcoming exams.
    const upcoming = exams
      .map((e) => ({ exam: e, days: daysBetween(today, e.date) }))
      .filter((x) => x.days >= 0)
      .sort((a, b) => {
        if (a.days !== b.days) return a.days - b.days;
        return examDateTimeISO(a.exam.date, a.exam.time).getTime() - examDateTimeISO(b.exam.date, b.exam.time).getTime();
      });

    const hour = now.getHours();
    const greetingKey: TKey =
      hour < 12 ? "dashboard.goodMorning" : hour < 18 ? "dashboard.goodAfternoon" : "dashboard.goodEvening";

    return {
      today,
      greetingKey,
      displayName: user?.name.split(" ")[0] ?? "",
      todaySessions,
      minutesToday,
      pending,
      overdueCount,
      upcoming,
      weekCompletion,
      weekDone,
      weekTotal: weekSessions.length,
      weekMinutes,
      perDay,
      streak,
      subjectById,
    };
  }, [sessions, tasks, exams, subjects, user]);
}

/* ── Sub-views ─────────────────────────────────────────────────────────── */

function SessionRow({
  session,
  subject,
  onToggle,
}: {
  session: StudySession;
  subject?: Subject;
  onToggle: () => void;
}) {
  const { locale, t } = useI18n();
  const past = session.date < todayISO() && !session.completed;
  return (
    <div className="flex items-center gap-3 rounded-lg border bg-background/50 px-3 py-2.5">
      <Checkbox
        checked={session.completed}
        onCheckedChange={onToggle}
        aria-label={session.completed ? t("planner.markIncomplete") : t("planner.markComplete")}
        className="shrink-0"
      />
      <span className="h-8 w-1 shrink-0 rounded-full" style={{ backgroundColor: subject?.color ?? "var(--muted)" }} />
      <div className="min-w-0 flex-1">
        <p className={`truncate text-sm font-medium ${session.completed ? "text-muted-foreground line-through" : ""}`}>
          {session.title}
        </p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
          <span>{subject?.name ?? t("dashboard.noSubject")}</span>
          <span>·</span>
          <span className="num">{formatTime(session.startTime, locale)}</span>
          <span>·</span>
          <span className="num">{minutesToLabel(session.durationMin, locale)}</span>
          {session.source === "ai" && (
            <Badge variant="secondary" className="h-4 px-1.5 text-[9px] font-bold">
              {t("planner.aiSource")}
            </Badge>
          )}
        </div>
      </div>
      {session.completed ? (
        <CheckCircle2 className="size-4 shrink-0 text-emerald-500" />
      ) : past ? (
        <span className="shrink-0 text-[11px] font-semibold text-destructive">{t("planner.pastSession")}</span>
      ) : (
        <Clock className="size-4 shrink-0 text-muted-foreground/60" />
      )}
    </div>
  );
}

function ExamRow({ exam, subject, daysLeft }: { exam: Exam; subject?: Subject; daysLeft: number }) {
  const { locale, t } = useI18n();
  const isToday = daysLeft === 0;
  return (
    <button
      onClick={() => navigate(ROUTES.exams)}
      className="flex w-full items-center gap-3 rounded-lg border bg-background/50 px-3 py-2.5 text-start transition-colors hover:bg-muted/60"
    >
      <span className="h-8 w-1 shrink-0 rounded-full" style={{ backgroundColor: subject?.color ?? "var(--muted)" }} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{exam.title}</p>
        <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
          {subject?.name ?? t("dashboard.noSubject")} · {formatTime(exam.time, locale)}
          {exam.location ? ` · ${exam.location}` : ""}
        </p>
      </div>
      {isToday ? (
        <Badge className="shrink-0 bg-primary">{t("dashboard.todayDay")}</Badge>
      ) : (
        <Badge variant="outline" className="num shrink-0">
          {t("dashboard.daysLeft", { count: daysLeft })}
        </Badge>
      )}
    </button>
  );
}

function TaskRow({ task, subject }: { task: Task; subject?: Subject }) {
  const { locale, t } = useI18n();
  const setTaskStatus = useStudyKitStore((s) => s.setTaskStatus);
  const today = todayISO();
  const overdue = task.dueDate && task.dueDate < today;
  return (
    <div className="flex items-center gap-3 rounded-lg border bg-background/50 px-3 py-2.5">
      <Checkbox
        checked={false}
        onCheckedChange={() => setTaskStatus(task.id, "done")}
        aria-label={t("dashboard.markDone")}
        className="shrink-0"
      />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{task.title}</p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
          <SubjectChip subject={subject} />
          {task.dueDate && (
            <span className={overdue ? "font-semibold text-destructive" : "num"}>
              {overdue ? t("dashboard.overdue") : t("dashboard.dueIn", { date: task.dueDate })}
            </span>
          )}
        </div>
      </div>
      {task.priority === "high" && (
        <span className="size-2 shrink-0 rounded-full bg-red-500" aria-label={t("tasks.priorityHigh")} />
      )}
    </div>
  );
}

function MiniWeekChart({ perDay }: { perDay: { date: string; minutes: number }[] }) {
  const { locale, t } = useI18n();
  const max = Math.max(60, ...perDay.map((d) => d.minutes));
  const today = todayISO();
  return (
    <div className="flex h-32 items-stretch justify-between gap-1.5 sm:gap-2" dir="ltr">
      {perDay.map((d) => {
        const h = Math.round((d.minutes / max) * 100);
        const isToday = d.date === today;
        return (
          <div key={d.date} className="flex min-w-0 flex-1 flex-col items-center">
            <span className="num h-4 text-[9px] leading-none text-muted-foreground">
              {d.minutes > 0 ? minutesToLabel(d.minutes, locale) : ""}
            </span>
            <div className="flex w-full flex-1 items-end px-1">
              <motion.div
                initial={{ height: 4 }}
                animate={{ height: `${Math.max(h, 5)}%` }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className={`w-full rounded-t-md ${isToday ? "bg-primary" : "bg-primary/35"}`}
                style={{ minHeight: 5 }}
              />
            </div>
            <span className={`mt-1.5 text-[9px] ${isToday ? "font-bold text-primary" : "text-muted-foreground"}`}>
              {new Intl.DateTimeFormat(locale === "ar" ? "ar-AE-u-nu-latn" : "en", { weekday: "narrow" }).format(
                new Date(d.date)
              )}
            </span>
            <span className="sr-only">{`${d.date}: ${minutesToLabel(d.minutes, locale)} — ${t("progress.chartWeekHint")}`}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ── Page ──────────────────────────────────────────────────────────────── */

export function DashboardPage() {
  const { t, locale, intlLocale } = useI18n();
  const toggleSessionComplete = useStudyKitStore((s) => s.toggleSessionComplete);
  const data = useDashboardData();

  const todayLabel = formatDateLong(data.today, locale);
  const nextExam = data.upcoming[0];

  const quickActions = [
    { label: t("dashboard.qaAddSession"), icon: CalendarPlus, onClick: () => navigate(`${ROUTES.planner}?add=1`) },
    { label: t("dashboard.qaAddTask"), icon: ListChecks, onClick: () => navigate(`${ROUTES.tasks}?add=1`) },
    { label: t("dashboard.qaAddExam"), icon: Timer, onClick: () => navigate(`${ROUTES.exams}?add=1`) },
    {
      label: t("dashboard.qaAiPlan"),
      icon: BrainCircuit,
      onClick: () => navigate(ROUTES.assistant),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${t(data.greetingKey)}${data.displayName ? `, ${data.displayName}` : ""} 👋`}
        subtitle={`${t("dashboard.overview")} ${todayLabel}`}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard
          icon={Clock}
          label={t("dashboard.statStudyToday")}
          value={minutesToLabel(data.minutesToday, locale)}
          tone="primary"
        />
        <StatCard
          icon={CircleDashed}
          label={t("dashboard.statPendingTasks")}
          value={data.pending.length}
          hint={data.overdueCount > 0 ? `${data.overdueCount} ${t("dashboard.overdue")}` : undefined}
          tone={data.overdueCount > 0 ? "warning" : "default"}
        />
        <StatCard
          icon={Timer}
          label={t("dashboard.statNextExam")}
          value={
            nextExam ? (
              nextExam.days === 0 ? t("dashboard.todayDay") : t("dashboard.daysLeft", { count: nextExam.days })
            ) : (
              "—"
            )
          }
          hint={nextExam ? nextExam.exam.title : undefined}
          tone={nextExam && nextExam.days <= 3 ? "warning" : "default"}
        />
        <StatCard
          icon={CheckCircle2}
          label={t("dashboard.statWeekCompletion")}
          value={`${data.weekCompletion}%`}
          hint={t("dashboard.statWeekCompletionHint", { done: data.weekDone, total: data.weekTotal })}
          tone="success"
          delay={0.05}
        />
      </div>

      {/* Quick actions */}
      <section aria-label={t("dashboard.quickActions")}>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((qa) => (
            <button
              key={qa.label}
              onClick={qa.onClick}
              className="group flex min-h-[4rem] items-center gap-2.5 rounded-xl border bg-card px-3 py-3 text-start transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md hover:shadow-primary/5 sm:gap-3 sm:px-4"
            >
              <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 transition-colors group-hover:bg-primary/15">
                <qa.icon className="size-4 text-primary" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13px] font-semibold sm:text-sm">{qa.label}</span>
              </span>
              <ChevronRight className="hidden size-4 shrink-0 text-muted-foreground/50 transition-transform group-hover:translate-x-0.5 rtl:rotate-180 rtl:group-hover:-translate-x-0.5 sm:block" />
            </button>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Today's schedule */}
        <SectionCard
          title={t("dashboard.todaySchedule")}
          icon={CalendarPlus}
          action={
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => navigate(ROUTES.planner)}>
              {t("common.viewAll")}
              <ChevronRight className="size-3.5 rtl:rotate-180" />
            </Button>
          }
        >
          {data.todaySessions.length === 0 ? (
            <EmptyState
              icon={CalendarPlus}
              title={t("dashboard.todayScheduleEmpty")}
              action={
                <Button size="sm" variant="outline" onClick={() => navigate(`${ROUTES.planner}?add=1`)}>
                  <Plus className="size-4" />
                  {t("dashboard.todayScheduleEmptyCta")}
                </Button>
              }
            />
          ) : (
            <div className="max-h-80 space-y-2 overflow-y-auto pe-1 scrollbar-slim">
              {data.todaySessions.map((s) => (
                <SessionRow
                  key={s.id}
                  session={s}
                  subject={data.subjectById.get(s.subjectId)}
                  onToggle={() => toggleSessionComplete(s.id)}
                />
              ))}
            </div>
          )}
        </SectionCard>

        {/* Upcoming exams */}
        <SectionCard
          title={t("dashboard.upcomingExams")}
          icon={Timer}
          action={
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => navigate(ROUTES.exams)}>
              {t("common.viewAll")}
              <ChevronRight className="size-3.5 rtl:rotate-180" />
            </Button>
          }
        >
          {data.upcoming.length === 0 ? (
            <EmptyState
              icon={Timer}
              title={t("dashboard.examsEmpty")}
              action={
                <Button size="sm" variant="outline" onClick={() => navigate(`${ROUTES.exams}?add=1`)}>
                  <Plus className="size-4" />
                  {t("dashboard.examsEmptyCta")}
                </Button>
              }
            />
          ) : (
            <div className="space-y-2">
              {data.upcoming.slice(0, 3).map(({ exam, days }) => (
                <ExamRow key={exam.id} exam={exam} subject={data.subjectById.get(exam.subjectId)} daysLeft={days} />
              ))}
              {nextExam && (
                <div className="flex items-center justify-between rounded-lg border border-primary/30 bg-primary/5 px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-primary">{t("dashboard.statNextExam")}</p>
                    <p className="truncate text-sm font-medium">{nextExam.exam.title}</p>
                  </div>
                  <LiveCountdown dateISO={nextExam.exam.date} time={nextExam.exam.time} locale={locale} />
                </div>
              )}
            </div>
          )}
        </SectionCard>

        {/* Pending tasks */}
        <SectionCard
          title={t("dashboard.pendingTasks")}
          icon={ListChecks}
          action={
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => navigate(ROUTES.tasks)}>
              {t("common.viewAll")}
              <ChevronRight className="size-3.5 rtl:rotate-180" />
            </Button>
          }
        >
          {data.pending.length === 0 ? (
            <EmptyState
              icon={CheckCircle2}
              title={t("dashboard.tasksEmpty")}
              action={
                <Button size="sm" variant="outline" onClick={() => navigate(`${ROUTES.tasks}?add=1`)}>
                  <Plus className="size-4" />
                  {t("dashboard.tasksEmptyCta")}
                </Button>
              }
            />
          ) : (
            <div className="max-h-80 space-y-2 overflow-y-auto pe-1 scrollbar-slim">
              {data.pending.slice(0, 6).map((task) => (
                <TaskRow key={task.id} task={task} subject={task.subjectId ? data.subjectById.get(task.subjectId) : undefined} />
              ))}
            </div>
          )}
        </SectionCard>

        {/* Week progress */}
        <SectionCard
          title={t("dashboard.weekProgress")}
          icon={ChartColumn}
          action={<StreakBadge days={data.streak} />}
        >
          <MiniWeekChart perDay={data.perDay} />
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t pt-3">
            <p className="text-sm text-muted-foreground">
              {t("dashboard.weekProgressHint", { hours: minutesToLabel(data.weekMinutes, locale) })}
            </p>
            <Button variant="link" size="sm" className="h-7 px-0" onClick={() => navigate(ROUTES.progress)}>
              <Play className="size-3.5" />
              {t("nav.progress")}
            </Button>
          </div>
          {data.streak === 0 && (
            <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Flame className="size-3.5 text-orange-500" />
              {t("dashboard.streakEmpty")}
            </p>
          )}
        </SectionCard>
      </div>

      <p className="pb-2 text-center text-[11px] text-muted-foreground/70" dir="ltr">
        {new Intl.DateTimeFormat(intlLocale, { dateStyle: "full" }).format(new Date())}
      </p>
    </div>
  );
}
