"use client";

/**
 * Study Planner — week grid + list views, session CRUD, subject manager,
 * dashboard deep-link support (?add=1).
 */

import { useEffect, useMemo, useState } from "react";
import {
  CalendarPlus,
  ChevronLeft,
  ChevronRight,
  Check,
  Clock,
  LayoutList,
  ListChecks,
  Palette,
  Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES, useRouteQuery } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import type { StudySession } from "@/lib/studykit/types";
import {
  addDaysISO,
  formatDayNumber,
  formatDayShort,
  formatDateMedium,
  formatTime,
  minutesToLabel,
  startOfWeekISO,
  todayISO,
  weekDatesISO,
} from "@/lib/studykit/utils";
import { EmptyState, PageHeader, SubjectChip } from "@/components/studykit/shared/ui";
import { ConfirmDialog } from "@/components/studykit/shared/confirm-dialog";
import { SessionDialog, type SessionFormValues } from "./session-dialog";
import { SubjectManagerDialog } from "./subject-dialog";

export function PlannerPage() {
  const { t, locale } = useI18n();
  const subjects = useStudyKitStore((s) => s.subjects);
  const sessions = useStudyKitStore((s) => s.sessions);
  const addSession = useStudyKitStore((s) => s.addSession);
  const updateSession = useStudyKitStore((s) => s.updateSession);
  const deleteSession = useStudyKitStore((s) => s.deleteSession);
  const toggleSessionComplete = useStudyKitStore((s) => s.toggleSessionComplete);
  const defaultSessionMin = useStudyKitStore((s) => s.settings.defaultSessionMin);

  const today = todayISO();
  const [view, setView] = useState<"week" | "list">("week");
  const [weekStart, setWeekStart] = useState(() => startOfWeekISO(today));
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [listTab, setListTab] = useState<"upcoming" | "done">("upcoming");

  const [editing, setEditing] = useState<StudySession | null>(null);
  const [dialogDate, setDialogDate] = useState(today);
  const [dialogSubject, setDialogSubject] = useState<string | undefined>(undefined);
  const [subjectsOpen, setSubjectsOpen] = useState(false);
  const [deleting, setDeleting] = useState<StudySession | null>(null);

  const query = useRouteQuery();

  // Dashboard quick action deep link: /app/planner?add=1 — open the dialog
  // on first render, then clean the URL.
  const [addParam] = useState(() => query.get("add") === "1");
  const [dialogOpen, setDialogOpen] = useState(addParam);
  useEffect(() => {
    if (addParam) {
      navigate(ROUTES.planner, { replace: true }); // clear the query
    }
  }, []);

  function openNew(date?: string, subjectId?: string) {
    setEditing(null);
    setDialogDate(date ?? today);
    setDialogSubject(subjectId);
    setDialogOpen(true);
  }

  function openEdit(session: StudySession) {
    setEditing(session);
    setDialogOpen(true);
  }

  const submit = (values: SessionFormValues, id?: string) => {
    if (id) {
      updateSession(id, values);
    } else {
      addSession(values);
    }
    toast.success(t("planner.sessionSaved"));
    setDialogOpen(false);
  };

  const weekDates = weekDatesISO(weekStart);
  const filtered = (list: StudySession[]) =>
    subjectFilter === "all" ? list : list.filter((s) => s.subjectId === subjectFilter);

  const byDate = useMemo(() => {
    const map = new Map<string, StudySession[]>();
    for (const s of sessions) {
      const arr = map.get(s.date) ?? [];
      arr.push(s);
      map.set(s.date, arr);
    }
    for (const arr of map.values()) arr.sort((a, b) => a.startTime.localeCompare(b.startTime));
    return map;
  }, [sessions]);

  const weekSessions = filtered(
    sessions.filter((s) => s.date >= weekStart && s.date <= addDaysISO(weekStart, 6))
  );
  const weekMinutes = weekSessions.reduce((a, s) => a + s.durationMin, 0);
  const weekDone = weekSessions.filter((s) => s.completed).length;

  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  const upcomingList = filtered(
    sessions.filter((s) => !s.completed && s.date >= today)
  ).sort((a, b) => a.date.localeCompare(b.date) || a.startTime.localeCompare(b.startTime));
  const doneList = filtered(sessions.filter((s) => s.completed))
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 30);

  /* ── Session card ── */
  const renderSessionCard = (s: StudySession, compact = false) => {
    const subject = subjectById.get(s.subjectId);
    return (
      <div
        key={s.id}
        role="button"
        tabIndex={0}
        onClick={() => openEdit(s)}
        onKeyDown={(e) => e.key === "Enter" && openEdit(s)}
        className={cn(
          "group w-full cursor-pointer rounded-lg border bg-card p-2.5 text-start transition-all hover:border-primary/40 hover:shadow-sm",
          s.completed && "opacity-60"
        )}
      >
        <div className="flex items-start gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleSessionComplete(s.id);
            }}
            aria-label={s.completed ? t("planner.markIncomplete") : t("planner.markComplete")}
            className={cn(
              "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full border transition-colors",
              s.completed ? "border-emerald-500 bg-emerald-500 text-white" : "border-muted-foreground/40 hover:border-primary"
            )}
          >
            {s.completed && <Check className="size-3" />}
          </button>
          <div className="min-w-0 flex-1">
            <p className={cn("truncate text-xs font-semibold sm:text-[13px]", s.completed && "line-through")}>
              {s.title}
            </p>
            <div className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted-foreground">
              <span className="num">{formatTime(s.startTime, locale)}</span>
              <span>·</span>
              <span className="num">{minutesToLabel(s.durationMin, locale)}</span>
              {s.source === "ai" && (
                <Badge variant="secondary" className="h-3.5 px-1 text-[8px] font-bold">
                  {t("planner.aiSource")}
                </Badge>
              )}
            </div>
            {!compact && (
              <div className="mt-1.5">
                <SubjectChip subject={subject} />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title={t("planner.title")}
        subtitle={t("planner.subtitle")}
        actions={
          <>
            <Button variant="outline" onClick={() => setSubjectsOpen(true)}>
              <Palette className="size-4" />
              {t("planner.manageSubjects")}
            </Button>
            <Button onClick={() => openNew()}>
              <Plus className="size-4" />
              {t("planner.addSession")}
            </Button>
          </>
        }
      />

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="icon"
            className="size-8"
            aria-label="Previous week"
            onClick={() => setWeekStart(addDaysISO(weekStart, -7))}
          >
            <ChevronLeft className="size-4 rtl:rotate-180" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs"
            onClick={() => setWeekStart(startOfWeekISO(todayISO()))}
          >
            {t("common.today")}
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="size-8"
            aria-label="Next week"
            onClick={() => setWeekStart(addDaysISO(weekStart, 7))}
          >
            <ChevronRight className="size-4 rtl:rotate-180" />
          </Button>
          <span className="ms-2 hidden text-sm font-medium text-muted-foreground sm:block" dir="ltr">
            {formatDateMedium(weekStart, locale)} – {formatDateMedium(addDaysISO(weekStart, 6), locale)}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="h-8 w-[150px] text-xs" aria-label={t("planner.subject")}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("common.all")}</SelectItem>
              {subjects.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  <span className="flex items-center gap-2">
                    <span className="size-2 rounded-full" style={{ backgroundColor: s.color }} />
                    {s.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Tabs value={view} onValueChange={(v) => setView(v as "week" | "list")}>
            <TabsList className="h-8">
              <TabsTrigger value="week" className="px-2.5 text-xs">
                <CalendarPlus className="me-1 size-3.5" />
                {t("planner.weekView")}
              </TabsTrigger>
              <TabsTrigger value="list" className="px-2.5 text-xs">
                <LayoutList className="me-1 size-3.5" />
                {t("planner.listView")}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Summary strip */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <Badge variant="outline" className="num">
          {t("planner.thisWeekTotal", { hours: minutesToLabel(weekMinutes, locale) })}
        </Badge>
        <Badge variant="outline" className="num">
          {t("planner.completedOf", { done: weekDone, total: weekSessions.length })}
        </Badge>
      </div>

      {view === "week" ? (
        <div className="-mx-4 overflow-x-auto px-4 pb-2 scrollbar-slim sm:mx-0 sm:px-0">
          <div className="grid min-w-[760px] grid-cols-7 gap-2">
            {weekDates.map((date) => {
              const daySessions = filtered(byDate.get(date) ?? []);
              const isToday = date === today;
              const dayMinutes = daySessions.reduce((a, s) => a + s.durationMin, 0);
              return (
                <div
                  key={date}
                  className={cn(
                    "flex min-h-[220px] flex-col rounded-xl border bg-card",
                    isToday && "border-primary/50 ring-1 ring-primary/20"
                  )}
                >
                  <div
                    className={cn(
                      "flex items-center justify-between rounded-t-xl border-b px-2.5 py-2",
                      isToday ? "bg-primary/10" : "bg-muted/40"
                    )}
                  >
                    <span className={cn("text-xs font-semibold", isToday && "text-primary")}>
                      {formatDayShort(date, locale)}
                    </span>
                    <span className={cn("num text-xs", isToday ? "font-bold text-primary" : "text-muted-foreground")}>
                      {formatDayNumber(date, locale)}
                    </span>
                  </div>
                  <div className="flex-1 space-y-1.5 p-1.5">
                    {daySessions.length === 0 ? (
                      <p className="py-4 text-center text-[10px] text-muted-foreground/60">—</p>
                    ) : (
                      daySessions.map((s) => renderSessionCard(s, true))
                    )}
                  </div>
                  <div className="flex items-center justify-between border-t px-2 py-1.5">
                    <span className="num text-[10px] text-muted-foreground">
                      {dayMinutes > 0 ? minutesToLabel(dayMinutes, locale) : ""}
                    </span>
                    <button
                      onClick={() => openNew(date)}
                      aria-label={t("planner.addSession")}
                      className="flex size-5 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-primary"
                    >
                      <Plus className="size-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <Tabs value={listTab} onValueChange={(v) => setListTab(v as "upcoming" | "done")}>
          <TabsList>
            <TabsTrigger value="upcoming" className="text-xs">
              <Clock className="me-1 size-3.5" />
              {t("planner.upcoming")} ({upcomingList.length})
            </TabsTrigger>
            <TabsTrigger value="done" className="text-xs">
              <ListChecks className="me-1 size-3.5" />
              {t("planner.completedSessions")} ({doneList.length})
            </TabsTrigger>
          </TabsList>

          <div className="mt-4">
            {listTab === "upcoming" ? (
              upcomingList.length === 0 ? (
                <EmptyState
                  icon={CalendarPlus}
                  title={t("planner.emptyWeek")}
                  action={
                    <Button size="sm" onClick={() => openNew()}>
                      <Plus className="size-4" />
                      {t("planner.emptyWeekCta")}
                    </Button>
                  }
                />
              ) : (
                <div className="space-y-4">
                  {Object.entries(
                    upcomingList.reduce<Record<string, StudySession[]>>((acc, s) => {
                      (acc[s.date] = acc[s.date] ?? []).push(s);
                      return acc;
                    }, {})
                  ).map(([date, list]) => (
                    <div key={date}>
                      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        {date === today ? t("planner.todayLabel") : formatDateMedium(date, locale)}
                      </h3>
                      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{list.map((s) => renderSessionCard(s))}</div>
                    </div>
                  ))}
                </div>
              )
            ) : doneList.length === 0 ? (
              <EmptyState icon={ListChecks} title={t("progress.historyEmpty")} />
            ) : (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {doneList.map((s) => renderSessionCard(s))}
              </div>
            )}
          </div>
        </Tabs>
      )}

      {view === "week" && weekSessions.length === 0 && (
        <EmptyState
          icon={CalendarPlus}
          title={t("planner.emptyWeek")}
          description={t("planner.subtitle")}
          action={
            <Button size="sm" onClick={() => openNew()}>
              <Plus className="size-4" />
              {t("planner.emptyWeekCta")}
            </Button>
          }
        />
      )}

      <SessionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        subjects={subjects}
        defaultDate={dialogDate}
        defaultSubjectId={dialogSubject}
        session={editing}
        defaultDuration={defaultSessionMin}
        onSubmit={submit}
        onDelete={
          editing
            ? () => {
                setDialogOpen(false);
                setDeleting(editing);
              }
            : undefined
        }
      />

      <SubjectManagerDialog open={subjectsOpen} onOpenChange={setSubjectsOpen} />

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(v) => !v && setDeleting(null)}
        title={t("planner.deleteSessionTitle")}
        description={deleting ? t("planner.deleteSessionDesc", { title: deleting.title, date: formatDateMedium(deleting.date, locale) }) : undefined}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        onConfirm={() => {
          if (!deleting) return;
          deleteSession(deleting.id);
          toast.success(t("planner.sessionDeleted"));
          setDeleting(null);
        }}
      />
    </div>
  );
}
