"use client";

/** Subject manager dialog — list, add, edit, delete subjects. */

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Pencil, Plus, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/lib/studykit/i18n";
import { useStudyKitStore } from "@/lib/studykit/store";
import type { Subject } from "@/lib/studykit/types";
import { SUBJECT_COLORS, pickSubjectColor } from "@/lib/studykit/utils";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

function SubjectForm({
  open,
  onOpenChange,
  subject,
  nextColorIndex,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subject?: Subject | null;
  nextColorIndex: number;
  onSubmit: (values: { name: string; color: string; weeklyTargetHours?: number }, id?: string) => void;
}) {
  const { t } = useI18n();
  const [submitting, setSubmitting] = useState(false);

  const schema = useMemo(
    () =>
      z.object({
        name: z.string().min(1, t("validation.titleRequired")).max(60),
        color: z.string(),
        weeklyTargetHours: z.number().min(0).max(60).optional(),
      }),
    [t]
  );

  const form = useForm<{ name: string; color: string; weeklyTargetHours?: number }>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", color: pickSubjectColor(nextColorIndex), weeklyTargetHours: undefined },
  });

  useEffect(() => {
    if (!open) return;
    form.reset(
      subject
        ? { name: subject.name, color: subject.color, weeklyTargetHours: subject.weeklyTargetHours }
        : { name: "", color: pickSubjectColor(nextColorIndex), weeklyTargetHours: undefined }
    );
  }, [open, subject, nextColorIndex, form]);

  const selectedColor = form.watch("color");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>{subject ? t("planner.editSubject") : t("planner.addSubject")}</DialogTitle>
          <DialogDescription>{t("planner.manageSubjectsDesc")}</DialogDescription>
        </DialogHeader>
        <form
          onSubmit={form.handleSubmit((values) => {
            setSubmitting(true);
            onSubmit(values, subject?.id);
            setTimeout(() => setSubmitting(false), 250);
          })}
          className="space-y-4"
          noValidate
        >
          <div className="space-y-1.5">
            <Label htmlFor="sub-name">{t("planner.subjectName")}</Label>
            <Input id="sub-name" placeholder={t("planner.subjectNamePlaceholder")} {...form.register("name")} />
            {form.formState.errors.name && (
              <p className="text-xs font-medium text-destructive">{form.formState.errors.name.message}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sub-target">{t("planner.weeklyTarget")}</Label>
            <Input
              id="sub-target"
              type="number"
              dir="ltr"
              min={0}
              max={60}
              placeholder="4"
              {...form.register("weeklyTargetHours", {
                setValueAs: (v) => (v === "" || v == null ? undefined : Number(v)),
              })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>{t("planner.color")}</Label>
            <div className="flex flex-wrap gap-2">
              {SUBJECT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-label={c}
                  onClick={() => form.setValue("color", c)}
                  className={cn(
                    "size-7 rounded-full transition-transform hover:scale-110",
                    selectedColor === c && "ring-2 ring-offset-2 ring-offset-background"
                  )}
                  style={{ backgroundColor: c, boxShadow: selectedColor === c ? `0 0 0 2px ${c}` : undefined }}
                />
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              {t("common.save")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function SubjectManagerDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { t } = useI18n();
  const subjects = useStudyKitStore((s) => s.subjects);
  const upsertSubject = useStudyKitStore((s) => s.upsertSubject);
  const deleteSubject = useStudyKitStore((s) => s.deleteSubject);
  const [editing, setEditing] = useState<Subject | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [deleting, setDeleting] = useState<Subject | null>(null);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("planner.manageSubjects")}</DialogTitle>
            <DialogDescription>{t("planner.manageSubjectsDesc")}</DialogDescription>
          </DialogHeader>

          <div className="max-h-72 space-y-2 overflow-y-auto pe-1 scrollbar-slim">
            {subjects.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">{t("assistant.priorityEmpty")}</p>
            )}
            {subjects.map((s) => (
              <div key={s.id} className="flex items-center gap-3 rounded-lg border px-3 py-2">
                <span className="size-3 shrink-0 rounded-full" style={{ backgroundColor: s.color }} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{s.name}</p>
                  {s.weeklyTargetHours ? (
                    <p className="num text-[11px] text-muted-foreground">{s.weeklyTargetHours}h · {t("planner.weeklyTarget")}</p>
                  ) : null}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  aria-label={t("planner.editSubject")}
                  onClick={() => {
                    setEditing(s);
                    setFormOpen(true);
                  }}
                >
                  <Pencil className="size-3.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8 text-destructive hover:text-destructive"
                  aria-label={t("common.delete")}
                  onClick={() => setDeleting(s)}
                >
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            ))}
          </div>

          <Button
            className="w-full"
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            <Plus className="size-4" />
            {t("planner.addSubject")}
          </Button>
        </DialogContent>
      </Dialog>

      <SubjectForm
        open={formOpen}
        onOpenChange={setFormOpen}
        subject={editing}
        nextColorIndex={subjects.length}
        onSubmit={(values, id) => {
          const res = upsertSubject({
            id,
            name: values.name,
            color: values.color,
            weeklyTargetHours: values.weeklyTargetHours || undefined,
          });
          if (res.ok) {
            toast.success(t("planner.subjectSaved"));
            setFormOpen(false);
          } else if (res.reason === "duplicate") {
            toast.error(t("planner.subjectExists"));
          }
        }}
      />

      <DeleteConfirm
        subject={deleting}
        onOpenChange={(v) => !v && setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          const res = deleteSubject(deleting.id);
          if (res.ok) {
            toast.success(t("planner.subjectDeleted"));
          } else {
            toast.error(t("planner.deleteSubjectLocked"));
          }
          setDeleting(null);
        }}
      />
    </>
  );
}

function DeleteConfirm({
  subject,
  onOpenChange,
  onConfirm,
}: {
  subject: Subject | null;
  onOpenChange: (v: boolean) => void;
  onConfirm: () => void;
}) {
  const { t } = useI18n();
  return (
    <Dialog open={!!subject} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>{t("planner.deleteSubjectTitle")}</DialogTitle>
          <DialogDescription>{t("planner.deleteSubjectDesc", { name: subject?.name ?? "" })}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t("common.cancel")}
          </Button>
          <Button variant="destructive" onClick={onConfirm}>
            <Trash2 className="size-4" />
            {t("common.delete")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
