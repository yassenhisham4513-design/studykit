"use client";

/** Create / edit study session dialog with validation. */

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/lib/studykit/i18n";
import type { Subject, StudySession } from "@/lib/studykit/types";
import { todayISO } from "@/lib/studykit/utils";

const DURATIONS = [15, 30, 45, 60, 90, 120, 180];

export function SessionDialog({
  open,
  onOpenChange,
  subjects,
  defaultDate,
  defaultSubjectId,
  session,
  defaultDuration,
  onSubmit,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subjects: Subject[];
  defaultDate?: string;
  defaultSubjectId?: string;
  /** When present the dialog edits an existing session. */
  session?: StudySession | null;
  defaultDuration: number;
  onSubmit: (values: SessionFormValues, id?: string) => void;
  onDelete?: () => void;
}) {
  const { t } = useI18n();
  const [submitting, setSubmitting] = useState(false);

  const schema = useMemo(
    () =>
      z.object({
        title: z.string().min(1, t("validation.titleRequired")).max(120),
        subjectId: z.string().min(1, t("validation.subjectRequired")),
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, t("validation.dateRequired")),
        startTime: z.string().regex(/^\d{2}:\d{2}$/, t("validation.timeRequired")),
        durationMin: z.number().min(5, t("validation.durationRange")).max(480, t("validation.durationRange")),
        notes: z.string().max(500).optional(),
      }),
    [t]
  );

  const form = useForm<SessionFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "",
      subjectId: defaultSubjectId ?? subjects[0]?.id ?? "",
      date: defaultDate ?? todayISO(),
      startTime: "16:00",
      durationMin: defaultDuration,
      notes: "",
    },
  });

  useEffect(() => {
    if (!open) return;
    if (session) {
      form.reset({
        title: session.title,
        subjectId: session.subjectId,
        date: session.date,
        startTime: session.startTime,
        durationMin: session.durationMin,
        notes: session.notes ?? "",
      });
    } else {
      form.reset({
        title: "",
        subjectId: defaultSubjectId ?? subjects[0]?.id ?? "",
        date: defaultDate ?? todayISO(),
        startTime: "16:00",
        durationMin: defaultDuration,
        notes: "",
      });
    }
  }, [open, session, defaultDate, defaultSubjectId, defaultDuration, subjects, form]);

  const handle = form.handleSubmit((values) => {
    setSubmitting(true);
    onSubmit(values, session?.id);
    // parent closes the dialog; brief delay shows pending state
    setTimeout(() => setSubmitting(false), 250);
  });

  const err = form.formState.errors;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{session ? t("planner.editSession") : t("planner.addSession")}</DialogTitle>
          <DialogDescription>{t("planner.subtitle")}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handle} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="ses-title">{t("planner.sessionTitle")}</Label>
            <Input id="ses-title" placeholder={t("planner.sessionTitlePlaceholder")} {...form.register("title")} />
            {err.title && <p className="text-xs font-medium text-destructive">{err.title.message}</p>}
          </div>

          <div className="space-y-1.5">
            <Label>{t("planner.subject")}</Label>
            <Select value={form.watch("subjectId")} onValueChange={(v) => form.setValue("subjectId", v, { shouldValidate: true })}>
              <SelectTrigger aria-label={t("planner.subject")}>
                <SelectValue placeholder={t("planner.selectSubject")} />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    <span className="flex items-center gap-2">
                      <span className="size-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                      {s.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {err.subjectId && <p className="text-xs font-medium text-destructive">{err.subjectId.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ses-date">{t("planner.date")}</Label>
              <Input id="ses-date" type="date" dir="ltr" min="2000-01-01" {...form.register("date")} />
              {err.date && <p className="text-xs font-medium text-destructive">{err.date.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ses-time">{t("planner.startTime")}</Label>
              <Input id="ses-time" type="time" dir="ltr" {...form.register("startTime")} />
              {err.startTime && <p className="text-xs font-medium text-destructive">{err.startTime.message}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>
              {t("planner.duration")} ({t("planner.durationMin")})
            </Label>
            <Select
              value={String(form.watch("durationMin"))}
              onValueChange={(v) => form.setValue("durationMin", Number(v), { shouldValidate: true })}
            >
              <SelectTrigger aria-label={t("planner.duration")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DURATIONS.map((d) => (
                  <SelectItem key={d} value={String(d)} className="num">
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {err.durationMin && <p className="text-xs font-medium text-destructive">{err.durationMin.message}</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ses-notes">
              {t("planner.notes")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
            </Label>
            <Textarea id="ses-notes" rows={2} placeholder={t("planner.notesPlaceholder")} {...form.register("notes")} />
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {session && onDelete ? (
              <Button
                type="button"
                variant="ghost"
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={onDelete}
              >
                <Trash2 className="size-4" />
                {t("common.delete")}
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                {session ? t("common.saveChanges") : t("common.save")}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export interface SessionFormValues {
  title: string;
  subjectId: string;
  date: string;
  startTime: string;
  durationMin: number;
  notes?: string;
}
