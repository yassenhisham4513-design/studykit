"use client";

/**
 * Progress Tracker — all statistics computed from real activity data.
 * Weekly view plus advanced insights (monthly trends, subject breakdown,
 * insights, reports).
 */

import { useMemo, useState } from "react";
import {
  Award,
  CalendarCheck,
  ChartColumn,
  ChartPie,
  CheckCircle2,
  Clock,
  FileText,
  Flame,
  Lightbulb,
  TrendingUp,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from "recharts";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import {
  addDaysISO,
  formatDayShort,
  formatDateMedium,
  minutesToLabel,
  startOfWeekISO,
  todayISO,
  weekDatesISO,
} from "@/lib/studykit/utils";

import { EmptyState, PageHeader, SectionCard, StatCard, SubjectChip } from "@/components/studykit/shared/ui";

export function ProgressPage() {
  const { t, locale } = useI18n();
  const sessions = useStudyKitStore((s) => s.sessions);
  const tasks = useStudyKitStore((s) => s.tasks);
  const subjects = useStudyKitStore((s) => s.subjects);
  const [report, setReport] = useState<string | null>(null);

  const today = todayISO();
  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  const completed = useMemo(() => sessions.filter((s) => s.completed), [sessions]);
  const doneTasks = tasks.filter((t) => t.status === "done").length;

  /* Last 7 days */
  const last7 = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const date = addDaysISO(today, -6 + i);
      const minutes = completed.filter((s) => s.date === date).reduce((a, s) => a + s.durationMin, 0);
      return { date, label: formatDayShort(date, locale), minutes };
    });
  }, [completed, today, locale]);

  const minutes7 = last7.reduce((a, d) => a + d.minutes, 0);
  const sessions7 = completed.filter((s) => s.date >= addDaysISO(today, -6)).length;

  /* Completion rate this week (Mon–Sun, up to today) */
  const weekStart = startOfWeekISO(today);
  const weekSessions = sessions.filter((s) => s.date >= weekStart && s.date <= today);
  const weekDone = weekSessions.filter((s) => s.completed).length;
  const completion = weekSessions.length ? Math.round((weekDone / weekSessions.length) * 100) : 0;

  /* Streak */
  const completedDates = useMemo(() => new Set(completed.map((s) => s.date)), [completed]);
  const streak = useMemo(() => {
    let n = 0;
    let cursor = today;
    if (!completedDates.has(cursor)) cursor = addDaysISO(today, -1);
    while (completedDates.has(cursor)) {
      n += 1;
      cursor = addDaysISO(cursor, -1);
    }
    return n;
  }, [completedDates, today]);

  /* 8-week trend */
  const trend8 = useMemo(() => {
    const weeks: { label: string; minutes: number; start: string }[] = [];
    const thisWeekStart = startOfWeekISO(today);
    for (let w = 7; w >= 0; w--) {
      const start = addDaysISO(thisWeekStart, -7 * w);
      const dates = weekDatesISO(start);
      const minutes = completed.filter((s) => dates.includes(s.date)).reduce((a, s) => a + s.durationMin, 0);
      weeks.push({ start, minutes, label: `${start.slice(8, 10)}/${start.slice(5, 7)}` });
    }
    return weeks;
  }, [completed, today]);

  /* Subject distribution last 30 days */
  const bySubject30 = useMemo(() => {
    const since = addDaysISO(today, -29);
    const map = new Map<string, number>();
    for (const s of completed) {
      if (s.date < since) continue;
      const key = s.subjectId || "_none";
      map.set(key, (map.get(key) ?? 0) + s.durationMin);
    }
    const palette = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)", "#94a3b8"];
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([id, minutes], i) => ({
        id,
        name: subjectById.get(id)?.name ?? t("dashboard.noSubject"),
        color: subjectById.get(id)?.color ?? palette[i % palette.length],
        minutes,
      }));
  }, [completed, today, subjectById, t]);

  const total30 = bySubject30.reduce((a, d) => a + d.minutes, 0);

  /* Insights */
  const insights = useMemo(() => {
    // Most productive weekday (avg minutes over last 28 days).
    const perWeekday = new Map<number, { total: number; count: number }>();
    for (let i = 0; i < 28; i++) {
      const date = addDaysISO(today, -i);
      const wd = new Date(date).getDay();
      const minutes = completed.filter((s) => s.date === date).reduce((a, s) => a + s.durationMin, 0);
      const cur = perWeekday.get(wd) ?? { total: 0, count: 0 };
      cur.total += minutes;
      cur.count += 1;
      perWeekday.set(wd, cur);
    }
    let bestWd = 0;
    let bestAvg = 0;
    for (const [wd, v] of perWeekday) {
      const avg = v.total / Math.max(1, v.count);
      if (avg > bestAvg) {
        bestAvg = avg;
        bestWd = wd;
      }
    }
    const dayNames = Array.from({ length: 7 }, (_, i) =>
      new Intl.DateTimeFormat(locale === "ar" ? "ar-AE-u-nu-latn" : "en", { weekday: "long" }).format(new Date(2024, 0, 7 + i))
    );
    // JS getDay: 0=Sunday. dayNames built from 2024-01-07 (a Sunday).

    // Average session length (all completed).
    const avgSession = completed.length
      ? Math.round(completed.reduce((a, s) => a + s.durationMin, 0) / completed.length)
      : 0;

    // Neglected subject: longest gap since last completed session.
    let neglected: { name: string; days: number } | null = null;
    for (const sub of subjects) {
      const last = completed
        .filter((s) => s.subjectId === sub.id)
        .map((s) => s.date)
        .sort()
        .at(-1);
      const gap = last ? Math.round((new Date(today).getTime() - new Date(last).getTime()) / 86_400_000) : 30;
      if (gap >= 5 && (!neglected || gap > neglected.days)) {
        neglected = { name: sub.name, days: gap };
      }
    }

    return {
      bestDay: dayNames[bestWd],
      bestAvg: Math.round(bestAvg),
      avgSession,
      neglected,
    };
  }, [completed, subjects, today, locale]);

  const hasAnyData = sessions.length > 0 || tasks.length > 0;

  const generateReport = () => {
    const since30 = addDaysISO(today, -29);
    const m30 = completed.filter((s) => s.date >= since30);
    const minutes30 = m30.reduce((a, s) => a + s.durationMin, 0);
    const top = [...bySubject30].sort((a, b) => b.minutes - a.minutes)[0];
    const lines = [
      `StudyKit — ${t("progress.reportTitle")} (${formatDateMedium(since30, locale)} → ${formatDateMedium(today, locale)})`,
      "",
      `• ${t("progress.statTotalHours")}: ${minutesToLabel(minutes30, locale)}`,
      `• ${t("progress.statSessionsDone")}: ${m30.length}`,
      `• ${t("progress.statTasksDone")}: ${doneTasks}/${tasks.length}`,
      `• ${t("progress.statStreak")}: ${streak} ${t("progress.daysUnit")}`,
      `• ${t("progress.insightFocusSubject")}: ${top ? `${subjectById.get(top.id)?.name ?? "—"} (${minutesToLabel(top.minutes, locale)})` : "—"}`,
      `• ${t("progress.insightAvgSession")}: ${minutesToLabel(insights.avgSession, locale)}`,
      `• ${t("progress.statCompletion")} (${t("progress.tabWeekly")}): ${completion}%`,
    ];
    setReport(lines.join("\n"));
  };

  if (!hasAnyData) {
    return (
      <div className="space-y-5">
        <PageHeader title={t("progress.title")} subtitle={t("progress.subtitle")} />
        <EmptyState
          icon={ChartColumn}
          title={t("progress.emptyWeek")}
          description={t("progress.subtitle")}
          action={
            <Button size="sm" onClick={() => navigate(`${ROUTES.planner}?add=1`)}>
              {t("progress.emptyWeekCta")}
            </Button>
          }
        />
      </div>
    );
  }

  const tooltipStyle = {
    background: "var(--popover)",
    border: "1px solid var(--border)",
    borderRadius: 12,
    fontSize: 12,
    color: "var(--popover-foreground)",
  };

  return (
    <div className="space-y-5">
      <PageHeader title={t("progress.title")} subtitle={t("progress.subtitle")} />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-5">
        <StatCard icon={Clock} label={t("progress.statTotalHours")} value={minutesToLabel(minutes7, locale)} tone="primary" />
        <StatCard icon={CalendarCheck} label={t("progress.statSessionsDone")} value={sessions7} />
        <StatCard icon={Award} label={t("progress.statTasksDone")} value={doneTasks} />
        <StatCard icon={Flame} label={t("progress.statStreak")} value={`${streak}`} tone={streak > 0 ? "warning" : "default"} />
        <StatCard icon={TrendingUp} label={t("progress.statCompletion")} value={`${completion}%`} tone="success" />
      </div>

      <Tabs defaultValue="weekly">
        <TabsList>
          <TabsTrigger value="weekly" className="text-xs sm:text-sm">
            {t("progress.tabWeekly")}
          </TabsTrigger>
          <TabsTrigger value="advanced" className="text-xs sm:text-sm">
            {t("progress.tabAdvanced")}
          </TabsTrigger>
        </TabsList>

        {/* ── Weekly ── */}
        <TabsContent value="weekly" className="mt-4 space-y-4">
          <SectionCard title={t("progress.chartWeek")} icon={ChartColumn}>
            <p className="mb-3 text-xs text-muted-foreground">{t("progress.chartWeekHint")}</p>
            <div className="h-64" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={last7} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={tooltipStyle}
                    formatter={(value: number) => [minutesToLabel(value, locale), t("progress.chartWeek")]}
                    cursor={{ fill: "var(--muted)", opacity: 0.5 }}
                  />
                  <Bar dataKey="minutes" fill="var(--chart-1)" radius={[6, 6, 0, 0]} maxBarSize={42} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </SectionCard>

          <SectionCard title={t("progress.history")} icon={CalendarCheck}>
            {completed.length === 0 ? (
              <EmptyState icon={CalendarCheck} title={t("progress.historyEmpty")} className="border-0" />
            ) : (
              <div className="max-h-96 space-y-2 overflow-y-auto pe-1 scrollbar-slim">
                {[...completed]
                  .sort((a, b) => b.date.localeCompare(a.date) || b.startTime.localeCompare(a.startTime))
                  .slice(0, 40)
                  .map((s) => (
                    <div key={s.id} className="flex items-center gap-3 rounded-lg border bg-background/50 px-3 py-2">
                      <CheckCircle2 className="size-4 shrink-0 text-emerald-500" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{s.title}</p>
                        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-muted-foreground">
                          <SubjectChip subject={s.subjectId ? subjectById.get(s.subjectId) : undefined} />
                          <span>{formatDateMedium(s.date, locale)}</span>
                          <span className="num">{minutesToLabel(s.durationMin, locale)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </SectionCard>
        </TabsContent>

        {/* ── Advanced insights ── */}
        <TabsContent value="advanced" className="mt-4">
          <div className="space-y-4">
              <div className="grid gap-4 lg:grid-cols-2">
                <SectionCard title={t("progress.chartTrend")} icon={TrendingUp}>
                  <p className="mb-3 text-xs text-muted-foreground">{t("progress.chartTrendHint")}</p>
                  <div className="h-56" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trend8} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                        <defs>
                          <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                            <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                        <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                        <Tooltip
                          contentStyle={tooltipStyle}
                          formatter={(value: number) => [minutesToLabel(value, locale), t("progress.chartTrend")]}
                        />
                        <Area type="monotone" dataKey="minutes" stroke="var(--chart-1)" strokeWidth={2.5} fill="url(#trendFill)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </SectionCard>

                <SectionCard title={t("progress.chartSubjects")} icon={ChartPie}>
                  <p className="mb-3 text-xs text-muted-foreground">{t("progress.chartSubjectsHint")}</p>
                  {total30 === 0 ? (
                    <EmptyState icon={ChartPie} title={t("progress.emptyWeek")} className="border-0" />
                  ) : (
                    <div className="flex h-56 flex-col items-center gap-3 sm:flex-row" dir="ltr">
                      <ResponsiveContainer width="55%" height="100%">
                        <PieChart>
                          <Pie
                            data={bySubject30}
                            dataKey="minutes"
                            nameKey="name"
                            innerRadius="58%"
                            outerRadius="88%"
                            paddingAngle={3}
                            strokeWidth={0}
                          >
                            {bySubject30.map((d) => (
                              <Cell key={d.id} fill={d.color} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={tooltipStyle}
                            formatter={(value: number, name: string) => [minutesToLabel(value, locale), name]}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                      <ul className="w-full flex-1 space-y-1.5 overflow-y-auto pe-1 text-xs scrollbar-slim">
                        {bySubject30.map((d) => (
                          <li key={d.id} className="flex items-center gap-2">
                            <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: d.color }} />
                            <span className="min-w-0 flex-1 truncate">{d.name}</span>
                            <span className="num shrink-0 text-muted-foreground">
                              {total30 ? Math.round((d.minutes / total30) * 100) : 0}%
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </SectionCard>
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <SectionCard title={t("progress.insightTitle")} icon={Lightbulb}>
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-start gap-2.5">
                      <TrendingUp className="mt-0.5 size-4 shrink-0 text-primary" />
                      <span>
                        <b>{t("progress.insightBestDay")}:</b>{" "}
                        {t("progress.insightBestDayValue", { day: insights.bestDay, minutes: insights.bestAvg })}
                      </span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <Clock className="mt-0.5 size-4 shrink-0 text-primary" />
                      <span>
                        <b>{t("progress.insightAvgSession")}:</b> {minutesToLabel(insights.avgSession, locale)}
                      </span>
                    </li>
                    {insights.neglected && (
                      <li className="flex items-start gap-2.5">
                        <Badge variant="outline" className="mt-0.5 border-amber-500/40 text-amber-600 dark:text-amber-500">
                          {t("progress.insightNeglect")}
                        </Badge>
                        <span className="text-muted-foreground">
                          <b>{insights.neglected.name}</b> — {t("progress.insightNeglectDesc", { days: insights.neglected.days })}
                        </span>
                      </li>
                    )}
                    <li className="flex items-start gap-2.5">
                      <Flame className="mt-0.5 size-4 shrink-0 text-orange-500" />
                      <span>
                        <b>{t("progress.statStreak")}:</b> {streak > 0 ? t("dashboard.streak", { days: streak }) : t("dashboard.streakEmpty")}
                      </span>
                    </li>
                  </ul>
                </SectionCard>

                <SectionCard title={t("progress.reportTitle")} icon={FileText}>
                  <p className="text-xs text-muted-foreground">{t("progress.reportHint")}</p>
                  <Button size="sm" className="mt-3" onClick={generateReport}>
                    <FileText className="size-4" />
                    {t("progress.reportCta")}
                  </Button>
                  {report && (
                    <pre className="mt-4 max-h-64 overflow-auto whitespace-pre-wrap rounded-lg border bg-muted/40 p-3 text-xs leading-relaxed scrollbar-slim" dir="ltr">
                      {report}
                    </pre>
                  )}
                </SectionCard>
              </div>
            </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
