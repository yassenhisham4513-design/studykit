"use client";

/** Shared hooks for StudyKit components. */

import { useEffect, useState, useSyncExternalStore } from "react";

/** Re-renders every `intervalMs` (default 30s) with the current Date. */
export function useNow(intervalMs = 30_000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** True after first client mount — the standard SSR-hydration gate. */
export function useMounted(): boolean {
  // useSyncExternalStore: false during SSR + hydration render, true after mount.
  // (Avoids setState-in-effect cascades entirely.)
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

export interface CountdownParts {
  days: number;
  hours: number;
  minutes: number;
  past: boolean;
}

export function countdownParts(target: Date, now: Date): CountdownParts {
  const diff = target.getTime() - now.getTime();
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, past: true };
  const days = Math.floor(diff / 86_400_000);
  const hours = Math.floor((diff % 86_400_000) / 3_600_000);
  const minutes = Math.floor((diff % 3_600_000) / 60_000);
  return { days, hours, minutes, past: false };
}
