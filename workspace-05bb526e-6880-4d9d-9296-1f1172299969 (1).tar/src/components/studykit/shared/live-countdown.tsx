"use client";

/** Live ticking countdown used on exam cards and the dashboard. */

import { examDateTimeISO } from "@/lib/studykit/utils";
import type { Locale } from "@/lib/studykit/types";
import { countdownParts, useNow } from "./hooks";
import { cn } from "@/lib/utils";

function unit(value: number, label: string, emphasize = false) {
  return (
    <div
      className={cn(
        "flex min-w-[3rem] flex-col items-center rounded-lg px-2 py-1.5 num",
        emphasize ? "bg-primary text-primary-foreground" : "bg-muted/70"
      )}
    >
      <span className={cn("font-display text-lg font-bold leading-none sm:text-xl", emphasize && "text-white")}>
        {String(value).padStart(2, "0")}
      </span>
      <span className={cn("mt-1 text-[10px] font-medium uppercase tracking-wide", emphasize ? "text-white/80" : "text-muted-foreground")}>
        {label}
      </span>
    </div>
  );
}

export function LiveCountdown({
  dateISO,
  time,
  locale,
  className,
}: {
  dateISO: string;
  time: string;
  locale: Locale;
  className?: string;
}) {
  const now = useNow(30_000);
  const target = examDateTimeISO(dateISO, time);
  const { days, hours, minutes, past } = countdownParts(target, now);
  const t = (k: string) => (locale === "ar" ? { days: "يوم", hours: "ساعة", minutes: "دقيقة" }[k]! : { days: "days", hours: "hrs", minutes: "min" }[k]!);

  if (past) {
    return (
      <div className={cn("num text-sm font-semibold text-muted-foreground", className)}>—</div>
    );
  }

  return (
    <div className={cn("flex items-center gap-1.5", className)} dir="ltr">
      {unit(days, t("days"), days <= 3)}
      {unit(hours, t("hours"))}
      {unit(minutes, t("minutes"))}
    </div>
  );
}
