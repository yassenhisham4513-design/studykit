"use client";

/** StudyKit shared UI primitives. */

import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, Flame, Loader2 } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import type { Subject, TaskPriority } from "@/lib/studykit/types";

/* ── Logo ──────────────────────────────────────────────────────────────── */

export function LogoMark({ className }: { className?: string }) {
  // Fixed gradient id: every instance defines an identical gradient, and a
  // constant keeps SSR/client markup byte-identical (useId() values differ
  // between the server and client trees and trigger hydration mismatches).
  const gid = "sk-logo-grad";
  return (
    <svg viewBox="0 0 64 64" className={cn("size-8", className)} aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" className="[stop-color:var(--primary)]" />
          <stop offset="1" className="[stop-color:var(--chart-5)]" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill={`url(#${gid})`} />
      <path d="M32 14 8 25l24 11 20-9.17V40h4V25L32 14z" fill="#fff" />
      <path
        d="M17 33.5V42c0 4.42 6.71 8 15 8s15-3.58 15-8v-8.5l-13 5.96a4 4 0 0 1-4 0l-13-5.96z"
        fill="#fff"
        opacity=".82"
      />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  const { t } = useI18n();
  return (
    <span className="inline-flex items-center gap-2.5">
      <LogoMark />
      {!compact && (
        <span className="font-display text-lg font-bold tracking-tight">{t("common.appName")}</span>
      )}
    </span>
  );
}

/* ── Page header ───────────────────────────────────────────────────────── */

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div className="min-w-0">
        <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground sm:text-base">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

/* ── Stat card ─────────────────────────────────────────────────────────── */

export function StatCard({
  icon: Icon,
  label,
  value,
  hint,
  tone = "default",
  delay = 0,
}: {
  icon: LucideIcon;
  label: string;
  value: React.ReactNode;
  hint?: string;
  tone?: "default" | "primary" | "warning" | "success";
  delay?: number;
}) {
  const toneClass = {
    default: "bg-muted text-muted-foreground",
    primary: "bg-primary/10 text-primary",
    warning: "bg-amber-500/15 text-amber-600 dark:text-amber-500",
    success: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-500",
  }[tone];
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: "easeOut" }}
      className="rounded-xl border bg-card p-4 sm:p-5"
    >
      <div className="flex items-center gap-2">
        <span className={cn("flex size-8 items-center justify-center rounded-lg", toneClass)}>
          <Icon className="size-4" />
        </span>
        <span className="text-xs font-medium text-muted-foreground sm:text-sm">{label}</span>
      </div>
      <div className="mt-3 num font-display text-2xl font-bold tracking-tight sm:text-3xl">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </motion.div>
  );
}

/* ── Empty state ───────────────────────────────────────────────────────── */

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-xl border border-dashed px-6 py-10 text-center",
        className
      )}
    >
      <span className="flex size-12 items-center justify-center rounded-full bg-muted">
        <Icon className="size-6 text-muted-foreground" />
      </span>
      <h3 className="mt-4 font-semibold">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ── Subject bits ──────────────────────────────────────────────────────── */

export function SubjectDot({ color, className }: { color: string; className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn("inline-block size-2.5 shrink-0 rounded-full", className)}
      style={{ backgroundColor: color }}
    />
  );
}

export function SubjectChip({
  subject,
  fallback,
  className,
}: {
  subject?: Subject;
  fallback?: string;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <span
      className={cn(
        "inline-flex max-w-full items-center gap-1.5 rounded-full border bg-muted/50 px-2 py-0.5 text-xs font-medium",
        className
      )}
    >
      {subject ? (
        <>
          <SubjectDot color={subject.color} />
          <span className="truncate">{subject.name}</span>
        </>
      ) : (
        <span className="truncate text-muted-foreground">{fallback ?? t("dashboard.noSubject")}</span>
      )}
    </span>
  );
}

/* ── Priority badge ────────────────────────────────────────────────────── */

export function PriorityBadge({ priority }: { priority: TaskPriority }) {
  const { t } = useI18n();
  const map = {
    high: "bg-red-500/12 text-red-600 dark:text-red-400 border-red-500/25",
    medium: "bg-amber-500/12 text-amber-600 dark:text-amber-500 border-amber-500/25",
    low: "bg-teal-500/12 text-teal-600 dark:text-teal-400 border-teal-500/25",
  } as const;
  const label = {
    high: t("tasks.priorityHigh"),
    medium: t("tasks.priorityMedium"),
    low: t("tasks.priorityLow"),
  }[priority];
  return (
    <span className={cn("inline-flex items-center rounded-md border px-1.5 py-0.5 text-[11px] font-semibold", map[priority])}>
      {label}
    </span>
  );
}

/* ── Streak badge ──────────────────────────────────────────────────────── */

export function StreakBadge({ days }: { days: number }) {
  const { t } = useI18n();
  if (days <= 0) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-orange-500/12 px-2 py-0.5 text-xs font-semibold text-orange-600 dark:text-orange-400">
      <Flame className="size-3.5" />
      {t("dashboard.streak", { days })}
    </span>
  );
}

/* ── States ────────────────────────────────────────────────────────────── */

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("size-4 animate-spin", className)} aria-label="loading" />;
}

export function ErrorBanner({ onRetry }: { onRetry?: () => void }) {
  const { t } = useI18n();
  return (
    <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4">
      <AlertTriangle className="mt-0.5 size-4 text-destructive" />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-destructive">{t("common.error")}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">{t("common.errorHint")}</p>
      </div>
      {onRetry && (
        <button onClick={onRetry} className="rounded-md border px-2.5 py-1 text-xs font-medium hover:bg-muted">
          {t("common.retry")}
        </button>
      )}
    </div>
  );
}

export function SectionCard({
  title,
  icon: Icon,
  action,
  children,
  className,
}: {
  title: string;
  icon?: LucideIcon;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-xl border bg-card", className)}>
      <header className="flex items-center justify-between gap-2 border-b px-4 py-3 sm:px-5">
        <h2 className="flex items-center gap-2 font-display text-sm font-bold sm:text-base">
          {Icon && <Icon className="size-4 text-primary" />}
          {title}
        </h2>
        {action}
      </header>
      <div className="p-4 sm:p-5">{children}</div>
    </section>
  );
}

export function SuccessDot({ className }: { className?: string }) {
  return <CheckCircle2 className={cn("size-4 text-emerald-500", className)} />;
}
