"use client";

/**
 * Task Manager — CRUD with deadlines, priorities, status filters, sorting,
 * overdue highlighting and dashboard deep-link support (?add=1).
 */

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  CalendarClock,
  CircleCheckBig,
  CircleDashed,
  Clock3,
  ListChecks,
  Pencil,
  Plus,
  TimerReset,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES, useRouteQuery } from "@/lib/studykit/router";
import { useStudyKitStore } from "@/lib/studykit/store";
import type { Task, TaskStatus } from "@/lib/studykit/types";
import { addDaysISO, formatDateMedium, relativeDayLabel, todayISO } from "@/lib/studykit/utils";
import { EmptyState, PageHeader, PriorityBadge, SubjectChip } from "@/components/studykit/shared/ui";
import { ConfirmDialog } from "@/components/studykit/shared/confirm-dialog";
import { TaskDialog, type TaskFormValues } from "./task-dialog";

type Filter = "all" | TaskStatus;
type Sort = "due" | "priority" | "created";

export function TasksPage() {
  const { t, locale } = useI18n();
  const subjects = useStudyKitStore((s) => s.subjects);
  const tasks = useStudyKitStore((s) => s.tasks);
  const addTask = useStudyKitStore((s) => s.addTask);
  const updateTask = useStudyKitStore((s) => s.updateTask);
  const deleteTask = useStudyKitStore((s) => s.deleteTask);
  const setTaskStatus = useStudyKitStore((s) => s.setTaskStatus);

  const [filter, setFilter] = useState<Filter>("all");
  const [sort, setSort] = useState<Sort>("due");
  const query = useRouteQuery();
  // Dashboard deep link (?add=1): open the dialog on first render, then clean the URL.
  const [dialogOpen, setDialogOpen] = useState(() => query.get("add") === "1");
  const [editing, setEditing] = useState<Task | null>(null);
  const [deleting, setDeleting] = useState<Task | null>(null);

  useEffect(() => {
    if (query.get("add") === "1") navigate(ROUTES.tasks, { replace: true });
  }, []);

  const today = todayISO();
  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  const openCount = tasks.filter((t) => t.status !== "done").length;
  const doneCount = tasks.length - openCount;
  const highOpen = tasks.filter((t) => t.status !== "done" && t.priority === "high").length;

  const sorted = useMemo(() => {
    const pr = { high: 0, medium: 1, low: 2 } as const;
    const list = [...tasks];
    switch (sort) {
      case "due":
        list.sort((a, b) => {
          const ad = a.dueDate ?? "9999-12-31";
          const bd = b.dueDate ?? "9999-12-31";
          if (ad !== bd) return ad.localeCompare(bd);
          return pr[a.priority] - pr[b.priority];
        });
        break;
      case "priority":
        list.sort((a, b) => pr[a.priority] - pr[b.priority] || a.title.localeCompare(b.title));
        break;
      case "created":
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        break;
    }
    return list;
  }, [tasks, sort]);

  const visible = sorted.filter((t) => (filter === "all" ? true : t.status === filter));

  const submit = (values: TaskFormValues, id?: string) => {
    if (id) {
      updateTask(id, values);
      toast.success(t("tasks.taskSaved"));
    } else {
      addTask(values);
      toast.success(t("tasks.taskSaved"));
    }
    setDialogOpen(false);
  };

  const dueLabel = (task: Task) => {
    if (!task.dueDate) return { text: t("tasks.noDueDate"), tone: "muted" as const };
    if (task.status === "done") return { text: t("tasks.completedOn", { date: formatDateMedium(task.dueDate, locale) }), tone: "muted" as const };
    if (task.dueDate < today) return { text: t("tasks.overdue"), tone: "bad" as const };
    if (task.dueDate === today) return { text: t("tasks.dueToday"), tone: "warn" as const };
    if (task.dueDate === addDaysISO(today, 1)) return { text: t("tasks.dueTomorrow"), tone: "ok" as const };
    return { text: relativeDayLabel(task.dueDate, today, locale), tone: "ok" as const };
  };

  const dueTone = {
    bad: "text-destructive font-semibold",
    warn: "text-amber-600 dark:text-amber-500 font-semibold",
    ok: "text-muted-foreground",
    muted: "text-muted-foreground/70",
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title={t("tasks.title")}
        subtitle={t("tasks.subtitle")}
        actions={
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="size-4" />
            {t("tasks.addTask")}
          </Button>
        }
      />

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
          <TabsList>
            <TabsTrigger value="all" className="text-xs">
              {t("tasks.filterAll")} ({tasks.length})
            </TabsTrigger>
            <TabsTrigger value="todo" className="text-xs">
              <CircleDashed className="me-1 size-3.5" />
              {t("tasks.filterTodo")} ({tasks.filter((x) => x.status === "todo").length})
            </TabsTrigger>
            <TabsTrigger value="in_progress" className="text-xs">
              <Clock3 className="me-1 size-3.5" />
              {t("tasks.filterInProgress")} ({tasks.filter((x) => x.status === "in_progress").length})
            </TabsTrigger>
            <TabsTrigger value="done" className="text-xs">
              <CircleCheckBig className="me-1 size-3.5" />
              {t("tasks.filterDone")} ({doneCount})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2">
          <Select value={sort} onValueChange={(v) => setSort(v as Sort)}>
            <SelectTrigger className="h-9 w-[150px] text-xs" aria-label={t("tasks.sort")}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="due">{t("tasks.sortDue")}</SelectItem>
              <SelectItem value="priority">{t("tasks.sortPriority")}</SelectItem>
              <SelectItem value="created">{t("tasks.sortCreated")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Summary */}
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="outline" className="num">
          {t("tasks.summary", { open: openCount, done: doneCount })}
        </Badge>
        {highOpen > 0 && (
          <Badge variant="outline" className="num border-red-500/30 text-red-600 dark:text-red-400">
            {t("tasks.priorityHighCount", { count: highOpen })}
          </Badge>
        )}
      </div>

      {/* List */}
      {visible.length === 0 ? (
        filter === "all" ? (
          <EmptyState
            icon={ListChecks}
            title={t("tasks.emptyAll")}
            action={
              <Button
                size="sm"
                onClick={() => {
                  setEditing(null);
                  setDialogOpen(true);
                }}
              >
                <Plus className="size-4" />
                {t("tasks.emptyAllCta")}
              </Button>
            }
          />
        ) : (
          <EmptyState icon={CircleDashed} title={t("tasks.emptyFiltered")} description={t("tasks.emptyFilteredHint")} />
        )
      ) : (
        <div className="space-y-2">
          {visible.map((task) => {
            const due = dueLabel(task);
            const subject = task.subjectId ? subjectById.get(task.subjectId) : undefined;
            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={cn(
                  "group flex items-start gap-3 rounded-xl border bg-card px-4 py-3 transition-colors hover:border-primary/30",
                  task.status === "done" && "opacity-65"
                )}
              >
                <Checkbox
                  checked={task.status === "done"}
                  onCheckedChange={(checked) => {
                    setTaskStatus(task.id, checked ? "done" : "todo");
                    if (checked) toast.success(t("tasks.taskCompleted"));
                  }}
                  aria-label={task.status === "done" ? t("tasks.markTodo") : t("tasks.markDone")}
                  className="mt-0.5"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className={cn("text-sm font-semibold", task.status === "done" && "line-through")}>{task.title}</p>
                    <PriorityBadge priority={task.priority} />
                    {task.status === "in_progress" && (
                      <Badge variant="secondary" className="text-[10px]">
                        <Clock3 className="me-1 size-2.5" />
                        {t("tasks.filterInProgress")}
                      </Badge>
                    )}
                  </div>
                  {task.description && (
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{task.description}</p>
                  )}
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[11px]">
                    <SubjectChip subject={subject} />
                    <span className={cn("inline-flex items-center gap-1", dueTone[due.tone])}>
                      <CalendarClock className="size-3" />
                      {due.text}
                    </span>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  {task.status !== "done" && task.status !== "in_progress" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8"
                      aria-label={t("tasks.startProgress")}
                      title={t("tasks.startProgress")}
                      onClick={() => setTaskStatus(task.id, "in_progress")}
                    >
                      <TimerReset className="size-3.5" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    aria-label={t("tasks.editTask")}
                    title={t("tasks.editTask")}
                    onClick={() => {
                      setEditing(task);
                      setDialogOpen(true);
                    }}
                  >
                    <Pencil className="size-3.5" />
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <TaskDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        subjects={subjects}
        task={editing}
        onSubmit={submit}
        onDelete={
          editing
            ? () => {
                setDialogOpen(false);
                setDeleting(editing);
              }
            : undefined
        }
      />

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(v) => !v && setDeleting(null)}
        title={t("tasks.deleteTaskTitle")}
        description={deleting ? t("tasks.deleteTaskDesc", { title: deleting.title }) : undefined}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        onConfirm={() => {
          if (!deleting) return;
          deleteTask(deleting.id);
          toast.success(t("tasks.taskDeleted"));
          setDeleting(null);
        }}
      />
    </div>
  );
}
