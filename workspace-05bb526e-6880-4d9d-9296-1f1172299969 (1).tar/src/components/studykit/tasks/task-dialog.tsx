"use client";

/** Create / edit task dialog with validation. */

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/lib/studykit/i18n";
import type { Subject, Task, TaskPriority, TaskStatus } from "@/lib/studykit/types";

export interface TaskFormValues {
  title: string;
  description?: string;
  subjectId?: string;
  dueDate?: string;
  priority: TaskPriority;
  status: TaskStatus;
}

export function TaskDialog({
  open,
  onOpenChange,
  subjects,
  task,
  onSubmit,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subjects: Subject[];
  task?: Task | null;
  onSubmit: (values: TaskFormValues, id?: string) => void;
  onDelete?: () => void;
}) {
  const { t } = useI18n();
  const [submitting, setSubmitting] = useState(false);

  const schema = useMemo(
    () =>
      z.object({
        title: z.string().min(1, t("validation.titleRequired")).max(140),
        description: z.string().max(1000).optional(),
        subjectId: z.string().optional(),
        dueDate: z.string().optional(),
        priority: z.enum(["low", "medium", "high"]),
        status: z.enum(["todo", "in_progress", "done"]),
      }),
    [t]
  );

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", description: "", subjectId: "", dueDate: "", priority: "medium", status: "todo" },
  });

  useEffect(() => {
    if (!open) return;
    form.reset(
      task
        ? {
            title: task.title,
            description: task.description ?? "",
            subjectId: task.subjectId ?? "",
            dueDate: task.dueDate ?? "",
            priority: task.priority,
            status: task.status,
          }
        : { title: "", description: "", subjectId: "", dueDate: "", priority: "medium", status: "todo" }
    );
  }, [open, task, form]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{task ? t("tasks.editTask") : t("tasks.addTask")}</DialogTitle>
          <DialogDescription>{t("tasks.subtitle")}</DialogDescription>
        </DialogHeader>

        <form
          onSubmit={form.handleSubmit((values) => {
            setSubmitting(true);
            onSubmit(
              {
                ...values,
                subjectId: values.subjectId || undefined,
                dueDate: values.dueDate || undefined,
                description: values.description || undefined,
              },
              task?.id
            );
            setTimeout(() => setSubmitting(false), 250);
          })}
          className="space-y-4"
          noValidate
        >
          <div className="space-y-1.5">
            <Label htmlFor="task-title">{t("tasks.taskTitle")}</Label>
            <Input id="task-title" placeholder={t("tasks.taskTitlePlaceholder")} {...form.register("title")} />
            {form.formState.errors.title && (
              <p className="text-xs font-medium text-destructive">{form.formState.errors.title.message}</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="task-desc">
              {t("tasks.description")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
            </Label>
            <Textarea id="task-desc" rows={2} placeholder={t("tasks.descriptionPlaceholder")} {...form.register("description")} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>
                {t("planner.subject")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
              </Label>
              <Select value={form.watch("subjectId") || "none"} onValueChange={(v) => form.setValue("subjectId", v === "none" ? "" : v)}>
                <SelectTrigger aria-label={t("planner.subject")}>
                  <SelectValue placeholder={t("planner.selectSubject")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">{t("common.none")}</SelectItem>
                  {subjects.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      <span className="flex items-center gap-2">
                        <span className="size-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                        {s.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="task-due">
                {t("tasks.dueDate")} <span className="text-xs font-normal text-muted-foreground">({t("common.optional")})</span>
              </Label>
              <Input id="task-due" type="date" dir="ltr" {...form.register("dueDate")} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>{t("tasks.priority")}</Label>
              <Select value={form.watch("priority")} onValueChange={(v) => form.setValue("priority", v as TaskPriority)}>
                <SelectTrigger aria-label={t("tasks.priority")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">{t("tasks.priorityLow")}</SelectItem>
                  <SelectItem value="medium">{t("tasks.priorityMedium")}</SelectItem>
                  <SelectItem value="high">{t("tasks.priorityHigh")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("tasks.status")}</Label>
              <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v as TaskStatus)}>
                <SelectTrigger aria-label={t("tasks.status")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todo">{t("tasks.filterTodo")}</SelectItem>
                  <SelectItem value="in_progress">{t("tasks.filterInProgress")}</SelectItem>
                  <SelectItem value="done">{t("tasks.filterDone")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {task && onDelete ? (
              <Button
                type="button"
                variant="ghost"
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={onDelete}
              >
                <Trash2 className="size-4" />
                {t("common.delete")}
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                {task ? t("common.saveChanges") : t("common.save")}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
