"use client";

/**
 * StudyKit application root.
 * Wires providers (theme, i18n, store hydration), the hash router, the
 * auth guard and a top-level error boundary. Everything renders under the
 * single `/` route by design of this preview environment.
 */

import { Component, useEffect, type ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { AnimatePresence, motion } from "framer-motion";
import { Compass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { I18nProvider, useI18n } from "@/lib/studykit/i18n";
import { useStudyKitStore, useSettings, useUser } from "@/lib/studykit/store";
import { navigate, useHashRoute, useScrollTopOnRoute, ROUTES, stripQuery } from "@/lib/studykit/router";
import { useMounted } from "@/components/studykit/shared/hooks";
import { LogoMark } from "@/components/studykit/shared/ui";
import { LandingPage } from "@/components/studykit/landing/landing-page";
import { AuthPage } from "@/components/studykit/auth/auth-page";
import { AppShell } from "@/components/studykit/shell/app-shell";
import { DashboardPage } from "@/components/studykit/dashboard/dashboard-page";
import { PlannerPage } from "@/components/studykit/planner/planner-page";
import { TasksPage } from "@/components/studykit/tasks/tasks-page";
import { ExamsPage } from "@/components/studykit/exams/exams-page";
import { ProgressPage } from "@/components/studykit/progress/progress-page";
import { AssistantPage } from "@/components/studykit/assistant/assistant-page";
import { SettingsPage } from "@/components/studykit/settings/settings-page";

/* ── Splash ────────────────────────────────────────────────────────────── */

function Splash() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        <LogoMark className="size-14" />
      </motion.div>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center gap-1.5"
      >
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="size-2 rounded-full bg-primary"
            animate={{ opacity: [0.25, 1, 0.25] }}
            transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
          />
        ))}
      </motion.div>
    </div>
  );
}

/* ── Error boundary ────────────────────────────────────────────────────── */

class AppErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.error("[StudyKit] render error:", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-6 text-center">
          <LogoMark className="size-12 opacity-70" />
          <h1 className="font-display text-xl font-bold">Something went wrong</h1>
          <p className="max-w-sm text-sm text-muted-foreground">
            An unexpected error occurred while rendering StudyKit.
          </p>
          <Button onClick={() => window.location.reload()}>Reload StudyKit</Button>
        </div>
      );
    }
    return this.props.children;
  }
}

/* ── 404 ───────────────────────────────────────────────────────────────── */

function NotFound() {
  const { t } = useI18n();
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-6 text-center">
      <span className="flex size-14 items-center justify-center rounded-2xl bg-muted">
        <Compass className="size-7 text-muted-foreground" />
      </span>
      <h1 className="font-display text-2xl font-bold">{t("common.error")}</h1>
      <p className="text-sm text-muted-foreground">404 — {t("landing.footerTagline")}</p>
      <Button onClick={() => navigate(ROUTES.landing)}>{t("nav.home")}</Button>
    </div>
  );
}

/* ── Router switch ─────────────────────────────────────────────────────── */

function AppView({ path }: { path: string }) {
  switch (path) {
    case ROUTES.dashboard:
      return <DashboardPage />;
    case ROUTES.planner:
      return <PlannerPage />;
    case ROUTES.tasks:
      return <TasksPage />;
    case ROUTES.exams:
      return <ExamsPage />;
    case ROUTES.progress:
      return <ProgressPage />;
    case ROUTES.assistant:
      return <AssistantPage />;
    case ROUTES.settings:
      return <SettingsPage />;
    default:
      return <NotFound />;
  }
}

function Router() {
  const rawPath = useHashRoute();
  const path = stripQuery(rawPath);
  useScrollTopOnRoute(path);
  const user = useUser();

  const isAppRoute = path.startsWith("/app");

  // Auth guard: /app/* requires a user; /auth redirects away when logged in.
  useEffect(() => {
    if (isAppRoute && !user) navigate(ROUTES.auth, { replace: true });
    if (path === ROUTES.auth && user) navigate(ROUTES.dashboard, { replace: true });
  }, [isAppRoute, path, user]);

  if (path === ROUTES.landing) return <LandingPage />;
  if (path === ROUTES.auth) return <AuthPage />;
  if (isAppRoute) {
    if (!user) return <Splash />; // brief flash while redirecting
    return (
      <AppShell>
        <AnimatePresence mode="wait">
          <motion.div
            key={path}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          >
            <AppView path={path} />
          </motion.div>
        </AnimatePresence>
      </AppShell>
    );
  }
  return <NotFound />;
}

/* ── Root ──────────────────────────────────────────────────────────────── */

function HydrationGate({ children }: { children: ReactNode }) {
  const mounted = useMounted();
  const hydrated = useStudyKitStore((s) => s._hydrated);
  if (!mounted || !hydrated) return <Splash />;
  return <>{children}</>;
}

function LocaleBridge({ children }: { children: ReactNode }) {
  const settings = useSettings();
  return (
    <I18nProvider locale={settings.locale} setLocale={(l) => useStudyKitStore.getState().setLocale(l)}>
      {children}
    </I18nProvider>
  );
}

export function StudyKitApp() {
  return (
    <AppErrorBoundary>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
        <HydrationGate>
          <LocaleBridge>
            <Router />
          </LocaleBridge>
        </HydrationGate>
      </ThemeProvider>
    </AppErrorBoundary>
  );
}
