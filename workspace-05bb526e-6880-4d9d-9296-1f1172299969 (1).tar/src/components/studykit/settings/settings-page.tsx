"use client";

/**
 * Settings — profile, appearance (theme + accent), language,
 * data export/import/reset and account actions.
 */

import { useRef, useState } from "react";
import {
  Check,
  CloudCheck,
  CloudOff,
  CloudUpload,
  Database,
  Download,
  Globe,
  LogOut,
  Monitor,
  Moon,
  Palette,
  Save,
  Sun,
  Trash2,
  Upload,
  UserRound,
} from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { useStudyKitStore, useSyncState, useUser } from "@/lib/studykit/store";
import type { AccentTheme } from "@/lib/studykit/types";
import { PageHeader } from "@/components/studykit/shared/ui";
import { ConfirmDialog } from "@/components/studykit/shared/confirm-dialog";

const ACCENTS: { id: AccentTheme; color: string }[] = [
  { id: "emerald", color: "#059669" },
  { id: "violet", color: "#7c3aed" },
  { id: "rose", color: "#e11d48" },
  { id: "amber", color: "#d97706" },
  { id: "teal", color: "#0d9488" },
];

function Section({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-xl border bg-card">
      <header className="flex items-center gap-2 border-b px-4 py-3 sm:px-5">
        <Icon className="size-4 text-primary" />
        <h2 className="font-display text-sm font-bold sm:text-base">{title}</h2>
      </header>
      <div className="p-4 sm:p-5">{children}</div>
    </section>
  );
}

export function SettingsPage() {
  const { t, locale, setLocale } = useI18n();
  const user = useUser();
  const { theme, setTheme } = useTheme();
  const store = useStudyKitStore;
  const settings = store((s) => s.settings);
  const syncState = useSyncState();

  const [name, setName] = useState(user?.name ?? "");
  const [university, setUniversity] = useState(user?.university ?? "");
  const [level, setLevel] = useState(user?.level ?? "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [sampleOpen, setSampleOpen] = useState(false);
  const [clearOpen, setClearOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  if (!user) return null;

  const saveProfile = () => {
    setSavingProfile(true);
    store.getState().updateProfile({ name: name.trim() || user.name, university, level });
    setTimeout(() => {
      setSavingProfile(false);
      toast.success(t("settings.saved"));
    }, 300);
  };

  const exportData = () => {
    const json = store.getState().exportData();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `studykit-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("settings.dataExported"));
  };

  const onImportFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = store.getState().importData(String(reader.result));
      if (res.ok) {
        toast.success(t("settings.importSuccess"));
      } else {
        toast.error(t("settings.importInvalid"));
      }
    };
    reader.readAsText(file);
  };

  const changeAccent = (accent: AccentTheme) => {
    store.getState().setAccent(accent);
  };

  return (
    <div className="space-y-5">
      <PageHeader title={t("settings.title")} subtitle={t("settings.subtitle")} />

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Profile */}
        <Section title={t("settings.profile")} icon={UserRound}>
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label htmlFor="set-name">{t("settings.name")}</Label>
              <Input id="set-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="set-email">{t("settings.email")}</Label>
              <Input id="set-email" value={user.email} dir="ltr" readOnly className="opacity-70" />
              <p className="text-[11px] text-muted-foreground">{t("settings.emailHint")}</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="set-uni">{t("settings.university")}</Label>
                <Input id="set-uni" value={university} placeholder={t("auth.universityPlaceholder")} onChange={(e) => setUniversity(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="set-level">{t("settings.level")}</Label>
                <Input id="set-level" value={level} placeholder={t("auth.levelPlaceholder")} onChange={(e) => setLevel(e.target.value)} />
              </div>
            </div>
            <Button onClick={saveProfile} disabled={savingProfile}>
              {savingProfile ? <Save className="size-4 animate-pulse" /> : <Save className="size-4" />}
              {t("common.saveChanges")}
            </Button>
          </div>
        </Section>

        {/* Appearance + language */}
        <div className="space-y-5">
          <Section title={t("settings.appearance")} icon={Palette}>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>{t("settings.theme")}</Label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: "light", icon: Sun, label: t("common.themeLight") },
                      { id: "dark", icon: Moon, label: t("common.themeDark") },
                      { id: "system", icon: Monitor, label: t("common.themeSystem") },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setTheme(opt.id)}
                      aria-pressed={theme === opt.id}
                      className={cn(
                        "flex min-h-11 items-center justify-center gap-1.5 rounded-lg border text-xs font-medium transition-colors",
                        theme === opt.id ? "border-primary bg-primary/10 text-primary" : "hover:bg-muted"
                      )}
                    >
                      <opt.icon className="size-4" />
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>{t("settings.accent")}</Label>
                <div className="flex flex-wrap gap-2.5">
                  {ACCENTS.map((a) => {
                    const selected = settings.accent === a.id;
                    return (
                      <button
                        key={a.id}
                        onClick={() => changeAccent(a.id)}
                        aria-label={a.id}
                        title={a.id}
                        className={cn(
                          "relative flex size-10 items-center justify-center rounded-full transition-transform hover:scale-105",
                          selected && "ring-2 ring-primary ring-offset-2 ring-offset-background"
                        )}
                        style={{ backgroundColor: a.color }}
                      >
                        {selected && <Check className="size-4 text-white" />}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[11px] text-muted-foreground">{t("settings.accentHint")}</p>
              </div>
            </div>
          </Section>

          <Section title={t("settings.language")} icon={Globe}>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: "en" as const, label: "English" },
                  { id: "ar" as const, label: "العربية" },
                ]
              ).map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setLocale(opt.id)}
                  aria-pressed={locale === opt.id}
                  className={cn(
                    "flex min-h-11 items-center justify-center gap-1.5 rounded-lg border text-sm font-medium transition-colors",
                    locale === opt.id ? "border-primary bg-primary/10 text-primary" : "hover:bg-muted"
                  )}
                >
                  {locale === opt.id && <Check className="size-4" />}
                  {opt.label}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">{t("settings.languageDesc")}</p>
          </Section>
        </div>

        {/* Data */}
        <Section
          title={t("settings.data")}
          icon={Database}
        >
          <div className="mb-3 flex items-center gap-2">
            {user.id === "guest" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                <CloudOff className="size-3" />
                {t("sync.guest")}
              </span>
            ) : syncState === "saving" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-medium text-primary">
                <CloudUpload className="size-3 animate-pulse" />
                {t("sync.saving")}
              </span>
            ) : syncState === "error" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-2.5 py-1 text-[11px] font-medium text-destructive">
                <CloudOff className="size-3" />
                {t("sync.error")}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-500">
                <CloudCheck className="size-3" />
                {t("sync.saved")}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground">{t("settings.dataDesc")}</p>
          <div className="mt-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">{t("settings.export")}</p>
                <p className="text-[11px] text-muted-foreground">{t("settings.exportHint")}</p>
              </div>
              <Button variant="outline" size="sm" onClick={exportData}>
                <Download className="size-4" />
                {t("settings.export")}
              </Button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">{t("settings.import")}</p>
                <p className="text-[11px] text-muted-foreground">{t("settings.importHint")}</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => fileInput.current?.click()}>
                <Upload className="size-4" />
                {t("settings.import")}
              </Button>
              <input
                ref={fileInput}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onImportFile(f);
                  e.target.value = "";
                }}
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">{t("settings.sample")}</p>
                <p className="text-[11px] text-muted-foreground">{t("settings.sampleHint")}</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => setSampleOpen(true)}>
                <Database className="size-4" />
                {t("settings.sample")}
              </Button>
            </div>
          </div>

          <Separator className="my-4" />
          <p className="text-xs font-semibold text-destructive">{t("settings.dangerZone")}</p>
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3">
            <div>
              <p className="text-sm font-medium">{t("settings.clearAll")}</p>
              <p className="text-[11px] text-muted-foreground">{t("settings.clearAllHint")}</p>
            </div>
            <Button variant="destructive" size="sm" onClick={() => setClearOpen(true)}>
              <Trash2 className="size-4" />
              {t("settings.clearAll")}
            </Button>
          </div>
        </Section>

        {/* Account */}
        <Section title={t("settings.account")} icon={UserRound}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium">{t("nav.logout")}</p>
              <p className="text-[11px] text-muted-foreground">{t("settings.logoutHint")}</p>
            </div>
            <Button
              variant="outline"
              onClick={() => {
                store.getState().logout();
                toast.success(t("auth.loggedOut"));
                navigate(ROUTES.landing);
              }}
            >
              <LogOut className="size-4" />
              {t("nav.logout")}
            </Button>
          </div>

          <Separator className="my-4" />

          <div className="space-y-1.5">
            <Label htmlFor="set-dur">{t("settings.defaultSession")}</Label>
            <Select
              value={String(settings.defaultSessionMin)}
              onValueChange={(v) => store.getState().setDefaultSessionMin(Number(v))}
            >
              <SelectTrigger id="set-dur" className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[15, 30, 45, 60, 90, 120].map((m) => (
                  <SelectItem key={m} value={String(m)} className="num">
                    {m} {t("common.minutes")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </Section>
      </div>

      <ConfirmDialog
        open={sampleOpen}
        onOpenChange={setSampleOpen}
        title={t("settings.sampleConfirmTitle")}
        description={t("settings.sampleConfirmDesc")}
        confirmLabel={t("settings.sample")}
        cancelLabel={t("common.cancel")}
        destructive={false}
        onConfirm={() => {
          store.getState().loadSampleData();
          setSampleOpen(false);
          toast.success(t("settings.sampleLoaded"));
        }}
      />

      <ConfirmDialog
        open={clearOpen}
        onOpenChange={setClearOpen}
        title={t("settings.clearAllTitle")}
        description={t("settings.clearAllDesc")}
        confirmLabel={t("settings.clearAll")}
        cancelLabel={t("common.cancel")}
        onConfirm={() => {
          store.getState().clearAllData();
          setClearOpen(false);
          toast.success(t("settings.dataCleared"));
        }}
      />
    </div>
  );
}
