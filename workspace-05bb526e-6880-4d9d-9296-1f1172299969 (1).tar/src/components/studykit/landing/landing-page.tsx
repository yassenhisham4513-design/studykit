"use client";

/**
 * StudyKit landing page — hero, features, why, FAQ, CTA, footer.
 * Marketing-only surface: all CTAs route to /auth.
 */

import { motion } from "framer-motion";
import {
  BrainCircuit,
  CalendarRange,
  Check,
  ChartColumn,
  ClipboardList,
  Globe,
  ListChecks,
  LogIn,
  MoonStar,
  Sparkles,
  Timer,
  TrendingUp,
  Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useI18n } from "@/lib/studykit/i18n";
import { navigate, ROUTES } from "@/lib/studykit/router";
import { Logo } from "@/components/studykit/shared/ui";

const fadeUp = {
  initial: { opacity: 0, y: 18 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.5, ease: "easeOut" as const },
};

/* ── Navbar ────────────────────────────────────────────────────────────── */

function Navbar() {
  const { t } = useI18n();
  const links = [
    { href: "#features", label: t("landing.navFeatures") },
    { href: "#why", label: t("landing.navWhy") },
    { href: "#faq", label: t("landing.navFaq") },
  ];
  return (
    <header className="fixed inset-x-0 top-0 z-40 glass border-b">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <button onClick={() => navigate(ROUTES.landing)} className="shrink-0" aria-label="StudyKit home">
          <Logo />
        </button>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => navigate(ROUTES.auth)}>
            <LogIn className="size-4" />
            <span className="hidden sm:inline">{t("nav.login")}</span>
          </Button>
          <Button size="sm" onClick={() => navigate(ROUTES.auth)}>
            {t("nav.register")}
          </Button>
        </div>
      </div>
    </header>
  );
}

/* ── Hero ──────────────────────────────────────────────────────────────── */

function HeroMockCard() {
  const { t } = useI18n();
  return (
    <motion.div
      initial={{ opacity: 0, y: 24, rotate: -2 }}
      animate={{ opacity: 1, y: 0, rotate: 0 }}
      transition={{ duration: 0.7, delay: 0.25, ease: "easeOut" }}
      className="relative mx-auto w-full max-w-md"
    >
      <div className="absolute -inset-6 rounded-3xl bg-gradient-to-tr from-primary/20 via-chart-2/10 to-chart-5/20 blur-2xl" aria-hidden />
      <div className="relative rounded-2xl border bg-card/90 p-5 shadow-2xl backdrop-blur">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10">
              <Timer className="size-4 text-primary" />
            </span>
            <div>
              <p className="text-xs text-muted-foreground">{t("dashboard.statNextExam")}</p>
              <p className="num font-display text-lg font-bold leading-tight">9d 04h</p>
            </div>
          </div>
          <Badge variant="secondary" className="gap-1">
            <Sparkles className="size-3 text-primary" />
            {t("assistant.modeAI")}
          </Badge>
        </div>

        <div className="mt-4 space-y-2">
          {[
            { name: "Mathematics", color: "#059669", time: "16:00", done: true },
            { name: "Physics", color: "#d97706", time: "18:00", done: true },
            { name: "Chemistry", color: "#7c3aed", time: "19:30", done: false },
          ].map((s, i) => (
            <motion.div
              key={s.name}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + i * 0.15 }}
              className="flex items-center gap-3 rounded-lg border bg-background/60 px-3 py-2.5"
            >
              <span className="flex size-5 items-center justify-center rounded-full" style={{ backgroundColor: s.color }}>
                {s.done ? <Check className="size-3 text-white" /> : <span className="size-1.5 rounded-full bg-white/80" />}
              </span>
              <span className="flex-1 text-sm font-medium">{s.name}</span>
              <span className="num text-xs text-muted-foreground">{s.time}</span>
            </motion.div>
          ))}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[
            { v: "12", l: t("progress.statSessionsDone") },
            { v: "84%", l: t("progress.statCompletion") },
            { v: "5", l: t("progress.statStreak") },
          ].map((stat, i) => (
            <div key={i} className="rounded-lg bg-muted/60 px-2 py-2">
              <p className="num font-display text-base font-bold">{stat.v}</p>
              <p className="truncate text-[10px] text-muted-foreground">{stat.l}</p>
            </div>
          ))}
        </div>
      </div>

      <motion.div
        className="absolute -bottom-5 -start-6 hidden rounded-xl border bg-card px-3 py-2 shadow-lg sm:block"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1, y: [0, -8, 0] }}
        transition={{
          opacity: { delay: 1, duration: 0.4 },
          scale: { delay: 1, duration: 0.4 },
          y: { delay: 1.4, duration: 4, repeat: Infinity, ease: "easeInOut" },
        }}
      >
        <div className="flex items-center gap-2">
          <span className="flex size-7 items-center justify-center rounded-lg bg-primary/10">
            <Sparkles className="size-3.5 text-primary" />
          </span>
          <div>
            <p className="text-[11px] font-semibold">{t("assistant.modeAI")}</p>
            <p className="text-[10px] text-muted-foreground">{t("assistant.formGenerate")}</p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Hero() {
  const { t } = useI18n();
  return (
    <section className="relative overflow-hidden pt-28 sm:pt-32">
      <div className="absolute inset-0 bg-grid" aria-hidden />
      <div className="absolute -top-24 start-1/4 size-72 rounded-full bg-primary/15 blur-3xl" aria-hidden />
      <div className="absolute top-32 end-0 size-64 rounded-full bg-chart-2/10 blur-3xl" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 pb-16 sm:px-6 lg:grid-cols-2 lg:pb-24">
        <div>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }}>
            <Badge variant="secondary" className="gap-1.5 px-3 py-1 text-xs">
              <Sparkles className="size-3.5 text-primary" />
              {t("landing.heroBadge")}
            </Badge>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.08 }}
            className="mt-5 font-display text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl"
          >
            {t("landing.heroTitleA")}
            <br />
            <span className="bg-gradient-to-r from-primary to-chart-5 bg-clip-text text-transparent">
              {t("landing.heroTitleB")}
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.16 }}
            className="mt-5 max-w-xl text-balance text-base text-muted-foreground sm:text-lg"
          >
            {t("landing.heroSubtitle")}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.24 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <Button size="lg" className="h-12 px-6 text-base" onClick={() => navigate(ROUTES.auth)}>
              <Zap className="size-4" />
              {t("landing.heroCtaPrimary")}
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-6 text-base" onClick={() => navigate(ROUTES.auth)}>
              {t("landing.heroCtaSecondary")}
            </Button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-8 grid max-w-lg grid-cols-3 gap-3"
          >
            {[
              { v: "6", l: t("landing.heroStat1") },
              { v: "2×", l: t("landing.heroStat2") },
              { v: "0", l: t("landing.heroStat3") },
            ].map((s) => (
              <div key={s.l} className="rounded-xl border bg-card/70 px-3 py-3 backdrop-blur">
                <p className="num font-display text-xl font-bold text-primary">{s.v}</p>
                <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">{s.l}</p>
              </div>
            ))}
          </motion.div>
        </div>
        <HeroMockCard />
      </div>
    </section>
  );
}

/* ── Features ──────────────────────────────────────────────────────────── */

const FEATURES: { icon: LucideIcon; titleKey: string; descKey: string }[] = [
  { icon: CalendarRange, titleKey: "landing.feature1Title", descKey: "landing.feature1Desc" },
  { icon: ListChecks, titleKey: "landing.feature2Title", descKey: "landing.feature2Desc" },
  { icon: Timer, titleKey: "landing.feature3Title", descKey: "landing.feature3Desc" },
  { icon: ChartColumn, titleKey: "landing.feature4Title", descKey: "landing.feature4Desc" },
  { icon: BrainCircuit, titleKey: "landing.feature5Title", descKey: "landing.feature5Desc" },
  { icon: Globe, titleKey: "landing.feature6Title", descKey: "landing.feature6Desc" },
];

function Features() {
  const { t } = useI18n();
  return (
    <section id="features" className="scroll-mt-20 py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">{t("landing.featuresTitle")}</h2>
          <p className="mt-3 text-muted-foreground">{t("landing.featuresSubtitle")}</p>
        </motion.div>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.titleKey}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: (i % 3) * 0.08 }}
              className="group rounded-xl border bg-card p-5 transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5"
            >
              <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/15">
                <f.icon className="size-5 text-primary" />
              </span>
              <h3 className="mt-4 font-display text-lg font-semibold">{t(f.titleKey as never)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t(f.descKey as never)}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Why ───────────────────────────────────────────────────────────────── */

const WHY: { icon: LucideIcon; titleKey: string; descKey: string }[] = [
  { icon: TrendingUp, titleKey: "landing.why1Title", descKey: "landing.why1Desc" },
  { icon: ClipboardList, titleKey: "landing.why2Title", descKey: "landing.why2Desc" },
  { icon: ChartColumn, titleKey: "landing.why3Title", descKey: "landing.why3Desc" },
  { icon: MoonStar, titleKey: "landing.why4Title", descKey: "landing.why4Desc" },
];

function Why() {
  const { t } = useI18n();
  return (
    <section id="why" className="scroll-mt-20 border-y bg-muted/40 py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">{t("landing.whyTitle")}</h2>
          <p className="mt-3 text-muted-foreground">{t("landing.whySubtitle")}</p>
        </motion.div>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {WHY.map((w, i) => (
            <motion.div
              key={w.titleKey}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: i * 0.08 }}
              className="relative rounded-xl border bg-card p-5"
            >
              <span className="num absolute end-4 top-4 font-display text-4xl font-bold text-muted-foreground/15">
                {i + 1}
              </span>
              <w.icon className="size-6 text-primary" />
              <h3 className="mt-3 font-semibold">{t(w.titleKey as never)}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t(w.descKey as never)}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── FAQ ───────────────────────────────────────────────────────────────── */

function FAQ() {
  const { t } = useI18n();
  const items = [1, 2, 3, 4, 5].map((n) => ({ q: t(`landing.faq${n}Q` as never), a: t(`landing.faq${n}A` as never) }));
  return (
    <section id="faq" className="scroll-mt-20 border-t bg-muted/40 py-16 sm:py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <motion.h2 {...fadeUp} className="text-center font-display text-3xl font-bold tracking-tight sm:text-4xl">
          {t("landing.faqTitle")}
        </motion.h2>
        <motion.div {...fadeUp} className="mt-10">
          <Accordion type="single" collapsible className="w-full">
            {items.map((item, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger className="text-start text-base font-medium">{item.q}</AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">{item.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}

/* ── CTA + footer ──────────────────────────────────────────────────────── */

function FinalCta() {
  const { t } = useI18n();
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <motion.div
          {...fadeUp}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-chart-5 px-6 py-14 text-center text-white sm:px-12"
        >
          <div className="absolute inset-0 bg-grid opacity-20" aria-hidden />
          <div className="relative">
            <h2 className="mx-auto max-w-2xl text-balance font-display text-3xl font-bold tracking-tight sm:text-4xl">
              {t("landing.ctaTitle")}
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-white/85">{t("landing.ctaSubtitle")}</p>
            <Button
              size="lg"
              variant="secondary"
              className="mt-8 h-12 px-8 text-base"
              onClick={() => navigate(ROUTES.auth)}
            >
              {t("landing.ctaButton")}
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  const { t } = useI18n();
  const year = new Date().getFullYear();
  return (
    <footer className="border-t bg-card">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">{t("landing.footerTagline")}</p>
            <p className="mt-4 max-w-sm text-xs leading-relaxed text-muted-foreground/80">
              {t("landing.footerDisclaimer")}
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold">{t("landing.footerProduct")}</h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li><a href="#features" className="hover:text-foreground">{t("landing.navFeatures")}</a></li>
              <li><a href="#why" className="hover:text-foreground">{t("landing.navWhy")}</a></li>
              <li><a href="#faq" className="hover:text-foreground">{t("landing.navFaq")}</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold">{t("landing.footerCompany")}</h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li><span className="cursor-default">{t("landing.footerPrivacy")} — {t("common.comingSoon")}</span></li>
              <li><span className="cursor-default">{t("landing.footerTerms")} — {t("common.comingSoon")}</span></li>
              <li><span className="cursor-default">{t("landing.footerContact")} — {t("common.comingSoon")}</span></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-6 text-center text-xs text-muted-foreground">
          {t("landing.footerRights", { year })}
        </div>
      </div>
    </footer>
  );
}

/* ── Page ──────────────────────────────────────────────────────────────── */

export function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Features />
        <Why />
        <FAQ />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}
