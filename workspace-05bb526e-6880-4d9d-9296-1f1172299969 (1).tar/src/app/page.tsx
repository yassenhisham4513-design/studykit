import { StudyKitApp } from "@/components/studykit/studykit-app";

export default function Home() {
  return <StudyKitApp />;
}
