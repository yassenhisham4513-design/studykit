import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk, Cairo } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "StudyKit — Student Productivity Platform",
    template: "%s · StudyKit",
  },
  description:
    "StudyKit helps students organize study schedules, manage assignments, prepare for exams and track academic progress — all in one beautiful workspace.",
  keywords: [
    "StudyKit",
    "student productivity",
    "study planner",
    "exam countdown",
    "task manager",
    "study tracker",
  ],
  authors: [{ name: "StudyKit" }],
  icons: {
    icon: "/studykit-icon.svg",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f7faf8" },
    { media: "(prefers-color-scheme: dark)", color: "#101715" },
  ],
};

/**
 * Applies the persisted language/direction before first paint to avoid an
 * RTL flash. The zustand store mirrors `locale` to `studykit-locale`.
 */
const noFlashScript = `
try {
  var l = localStorage.getItem("studykit-locale");
  if (l === "ar") {
    document.documentElement.dir = "rtl";
    document.documentElement.lang = "ar";
  }
} catch (e) {}
`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: noFlashScript }} />
      </head>
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} ${cairo.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster position="top-center" richColors closeButton />
      </body>
    </html>
  );
}
