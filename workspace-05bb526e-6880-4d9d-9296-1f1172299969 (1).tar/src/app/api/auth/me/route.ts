import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getSessionUser, publicUser } from "@/lib/server/auth";

/**
 * GET  /api/auth/me — current session user (null when signed out).
 * PATCH /api/auth/me — update profile fields (name / university / level).
 */

export const runtime = "nodejs";

const PatchSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  university: z.string().trim().max(120).optional(),
  level: z.string().trim().max(80).optional(),
});

export async function GET() {
  const user = await getSessionUser();
  return NextResponse.json({ user: user ? publicUser(user) : null });
}

export async function PATCH(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let body: z.infer<typeof PatchSchema>;
  try {
    body = PatchSchema.parse(await req.json());
  } catch {
    return NextResponse.json({ error: "invalidBody" }, { status: 400 });
  }

  const updated = await db.user.update({
    where: { id: user.id },
    data: {
      ...(body.name ? { name: body.name } : {}),
      ...(body.university !== undefined ? { university: body.university || null } : {}),
      ...(body.level !== undefined ? { level: body.level || null } : {}),
    },
    select: {
      id: true,
      email: true,
      name: true,
      university: true,
      level: true,
      createdAt: true,
    },
  });
  return NextResponse.json({ user: publicUser(updated) });
}
