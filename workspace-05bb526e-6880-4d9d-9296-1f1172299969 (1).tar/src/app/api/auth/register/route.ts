import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, setSessionCookie, publicUser } from "@/lib/server/auth";

/**
 * POST /api/auth/register — creates a real server-side account.
 * Rate-limit-friendly: cheap scrypt cost is intentionally moderate.
 */

export const runtime = "nodejs";

const BodySchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().toLowerCase().email().max(200),
  password: z.string().min(6).max(200),
  university: z.string().trim().max(120).optional(),
  level: z.string().trim().max(80).optional(),
});

export async function POST(req: NextRequest) {
  let body: z.infer<typeof BodySchema>;
  try {
    body = BodySchema.parse(await req.json());
  } catch {
    return NextResponse.json({ error: "invalidBody" }, { status: 400 });
  }

  const existing = await db.user.findUnique({ where: { email: body.email }, select: { id: true } });
  if (existing) {
    return NextResponse.json({ error: "emailTaken" }, { status: 409 });
  }

  const user = await db.user.create({
    data: {
      name: body.name,
      email: body.email,
      passwordHash: hashPassword(body.password),
      university: body.university || null,
      level: body.level || null,
    },
  });

  await setSessionCookie(user.id);
  return NextResponse.json({ user: publicUser(user) }, { status: 201 });
}
