import { NextResponse } from "next/server";
import { clearSessionCookie } from "@/lib/server/auth";

/** POST /api/auth/logout — clears the session cookie. */
export const runtime = "nodejs";

export async function POST() {
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
