import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { verifyPassword, setSessionCookie, publicUser } from "@/lib/server/auth";

/**
 * POST /api/auth/login — verifies credentials against the server database
 * and issues an HTTP-only session cookie.
 */

export const runtime = "nodejs";

const BodySchema = z.object({
  email: z.string().trim().toLowerCase().email().max(200),
  password: z.string().min(1).max(200),
});

export async function POST(req: NextRequest) {
  let body: z.infer<typeof BodySchema>;
  try {
    body = BodySchema.parse(await req.json());
  } catch {
    return NextResponse.json({ error: "invalidBody" }, { status: 400 });
  }

  const user = await db.user.findUnique({ where: { email: body.email } });
  // Same message for unknown email and wrong password (no account probing).
  if (!user || !verifyPassword(body.password, user.passwordHash)) {
    return NextResponse.json({ error: "invalidCredentials" }, { status: 401 });
  }

  await setSessionCookie(user.id);
  return NextResponse.json({ user: publicUser(user) });
}
