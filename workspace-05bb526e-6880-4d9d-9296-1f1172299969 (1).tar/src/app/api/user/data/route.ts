import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/server/auth";

/**
 * GET /api/user/data — returns the signed-in user's study workspace.
 * PUT /api/user/data — replaces it (called by the client's debounced sync).
 *
 * The payload is a validated JSON blob: subjects, sessions, tasks, exams,
 * settings.
 */

export const runtime = "nodejs";

const MAX_BYTES = 1_000_000; // 1 MB — generous for a study workspace

const PayloadSchema = z.object({
  subjects: z.array(z.any()).max(500),
  sessions: z.array(z.any()).max(5000),
  tasks: z.array(z.any()).max(5000),
  exams: z.array(z.any()).max(500),
  settings: z
    .object({
      locale: z.enum(["en", "ar"]).optional(),
      accent: z.string().max(20).optional(),
      defaultSessionMin: z.number().min(5).max(480).optional(),
      onboardingDone: z.boolean().optional(),
    })
    .optional(),
});

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const row = await db.userData.findUnique({ where: { userId: user.id } });
  if (!row) return NextResponse.json({ data: null, updatedAt: null });

  let parsed: unknown = null;
  try {
    parsed = JSON.parse(row.payload);
  } catch {
    parsed = null;
  }
  return NextResponse.json({ data: parsed, updatedAt: row.updatedAt.toISOString() });
}

export async function PUT(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const raw = await req.text();
  if (raw.length > MAX_BYTES) {
    return NextResponse.json({ error: "payloadTooLarge" }, { status: 413 });
  }

  let json: unknown;
  try {
    json = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "invalidBody" }, { status: 400 });
  }

  const parsed = PayloadSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalidBody" }, { status: 400 });
  }

  await db.userData.upsert({
    where: { userId: user.id },
    update: { payload: raw },
    create: { userId: user.id, payload: raw },
  });

  return NextResponse.json({ ok: true, updatedAt: new Date().toISOString() });
}
