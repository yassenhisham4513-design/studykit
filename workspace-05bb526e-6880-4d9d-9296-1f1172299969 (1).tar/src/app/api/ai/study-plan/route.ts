import { NextResponse } from "next/server";
import { z } from "zod";
import ZAI from "z-ai-web-dev-sdk";
import { buildStudyPlan, normalizePlanSessions } from "@/lib/studykit/ai-engine";

/**
 * POST /api/ai/study-plan
 *
 * Generates a personalized study plan. The AI model is called SERVER-SIDE
 * only — no API key ever reaches the browser. If the live model is
 * unavailable (no key, network, timeout, bad output), the route degrades to
 * the built-in demo engine and clearly reports `mode: "demo"` so the UI can
 * badge the result honestly.
 */

export const runtime = "nodejs";
export const maxDuration = 60;

const BodySchema = z.object({
  examTitle: z.string().min(1).max(120),
  examDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  subjects: z.array(z.string().min(1).max(60)).min(1).max(10),
  hoursPerDay: z.number().min(0.5).max(8),
  startFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  locale: z.enum(["en", "ar"]).default("en"),
});

function buildPrompt(input: z.infer<typeof BodySchema>): { system: string; user: string } {
  const { examTitle, examDate, subjects, hoursPerDay, startFrom, locale } = input;
  const languageNote =
    locale === "ar"
      ? "Write every string (summary, titles, tips) in Arabic."
      : "Write every string in English.";
  return {
    system: [
      "You are StudyKit's study-planning engine for students.",
      "You design realistic, balanced study plans using spaced learning: deep study first, then revision, then past-paper practice, ending with a timed mock 1 day before the exam.",
      languageNote,
      'Respond with STRICT JSON only, no markdown fences, matching exactly:',
      '{"summary": string (1-2 sentences), "tips": string[] (3 short tips), "sessions": [{"date": "YYYY-MM-DD", "startTime": "HH:MM" (24h, between 07:00 and 21:30), "durationMin": number (30-120, multiple of 5), "subject": string, "title": string (concise), "kind": "learn"|"revise"|"practice"|"mock"}]}',
      "Rules: at most 4 sessions per day; every session date must be between startFrom (inclusive) and examDate (exclusive); balance subjects; do not invent subjects outside the provided list (except 'Mixed review' for mocks).",
    ].join(" "),
    user: JSON.stringify({ examTitle, examDate, startFrom: startFrom ?? undefined, subjects, hoursPerDay }),
  };
}

async function tryLiveAI(input: z.infer<typeof BodySchema>): Promise<{
  summary: string;
  tips: string[];
  sessions: ReturnType<typeof normalizePlanSessions>;
} | null> {
  try {
    const zai = await ZAI.create();
    const { system, user } = buildPrompt(input);
    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          { role: "assistant", content: system },
          { role: "user", content: user },
        ],
        thinking: { type: "disabled" },
      }),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error("ai timeout")), 45_000)),
    ]);

    const raw: string = completion.choices[0]?.message?.content ?? "";
    const cleaned = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(cleaned) as { summary?: unknown; tips?: unknown; sessions?: unknown };
    const sessions = normalizePlanSessions(parsed.sessions, {
      examTitle: input.examTitle,
      examDate: input.examDate,
      subjects: input.subjects,
      hoursPerDay: input.hoursPerDay,
      startFrom: input.startFrom,
      locale: input.locale,
    });
    if (sessions.length < 3) return null;
    const summary = typeof parsed.summary === "string" && parsed.summary.trim() ? parsed.summary.trim() : "";
    const tips = Array.isArray(parsed.tips)
      ? parsed.tips.filter((t): t is string => typeof t === "string" && t.trim().length > 0).slice(0, 4)
      : [];
    return { summary, tips, sessions };
  } catch {
    return null;
  }
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  const parsed = BodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_input", details: parsed.error.flatten() }, { status: 400 });
  }
  const input = parsed.data;

  // Always build the deterministic plan first — it doubles as the fallback.
  const fallback = buildStudyPlan({
    examTitle: input.examTitle,
    examDate: input.examDate,
    subjects: input.subjects,
    hoursPerDay: input.hoursPerDay,
    startFrom: input.startFrom,
    locale: input.locale,
  });

  const live = await tryLiveAI(input);
  if (live) {
    return NextResponse.json({
      mode: "ai",
      plan: {
        summary: live.summary || fallback.summary,
        tips: live.tips.length ? live.tips : fallback.tips,
        sessions: live.sessions,
      },
    });
  }

  return NextResponse.json({
    mode: "demo",
    plan: { summary: fallback.summary, tips: fallback.tips, sessions: fallback.sessions },
  });
}
